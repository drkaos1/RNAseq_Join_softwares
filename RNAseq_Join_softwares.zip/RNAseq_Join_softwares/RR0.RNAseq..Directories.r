
###########################################################################################################################################
########################################################################################################################################### 

############################################################################## errors
##############################################################################
##################
STOP..ERRORS.here= 0
if(ORG.fastq.bam.DIR..VEC[1]=="ERROR" ){ STOP..ERRORS.here= 1;  print("");   print(paste("ERROR --> Directory raw data    -->  not available --> dir  = ", ORG.fastq.bam.DIR..VEC   )) }
##################
#if(length(RNAseq..test_kaOs..SAVE)!=1 ){ STOP..ERRORS.here= 1;  print("");   print(paste(" ERROR ERROR --> length(RNAseq..test_kaOs..SAVE)!=1 --> ",length(RNAseq..test_kaOs..SAVE) )) }
if(length(RNAseq..test_run..VEC  )<=0 ){ STOP..ERRORS.here= 1;  print("");   print(paste(" ERROR ERROR --> length(RNAseq..test_run..VEC  )<=1 --> ",length(RNAseq..test_run..VEC  ) )) }	
##################
if(length(unique(RNAseq..Special.Genes..List.Names))!=length(unique(RNAseq..Special.Genes..Column.Name))) { STOP..ERRORS.here= 1;  print("");   print(paste("ERROR --> unique(RNAseq..Special.Genes..List.Names) != unique(RNAseq..Special.Genes..Column.Name) ", length(RNAseq..Special.Genes..List.Names),"!=", length(RNAseq..Special.Genes..Column.Name)  )) }
if(length(RNAseq..Special.Genes..PI)>0 & length(RNAseq..Special.Genes..PI..Column.Name)!=1               ){ STOP..ERRORS.here= 1;  print("");   print(paste("ERROR --> length(RNAseq..Special.Genes..PI)>0 & length(RNAseq..Special.Genes..PI..Column.Name)!=1 ", length(RNAseq..Special.Genes..PI),";  COL=",length(RNAseq..Special.Genes..PI..Column.Name)  )) }

####################################
if(STOP..ERRORS.here==1){ print("");   stop("kaOs is stopping") };  rm(STOP..ERRORS.here)

###########################################################################################################################################
###########################################################################################################################################
if(length(RNAseq..VOLCANO..COLOR.special..MAIN)>0) if(nrow(RNAseq..VOLCANO..COLOR.special..MAIN)>0)	{
	RNAseq..VOLCANO..COLOR.special..MAIN= as.data.frame(array(RNAseq..VOLCANO..COLOR.special..MAIN, c(nrow(RNAseq..VOLCANO..COLOR.special..MAIN),ncol(RNAseq..VOLCANO..COLOR.special..MAIN))), stringsFactors=F)
	colnames(RNAseq..VOLCANO..COLOR.special..MAIN)= c("Special.Genes","RED","BLUE") 
}

############################################################################## functions
##############################################################################
if(!exists("Testing.bam.vcf.files.names.Step1")) Testing.bam.vcf.files.names.Step1.x= 0 else Testing.bam.vcf.files.names.Step1.x= Testing.bam.vcf.files.names.Step1

if(!exists("FFF.RNAseq..Table..Annotation")) {
	##################
	source(paste(MAIN.MAIN.DIR...Pipeline..RNseq,"RR0.Function.RNAseq..Main.r",sep=""))
	#########
	##################
	if(Testing.bam.vcf.files.names.Step1.x==0){ library(limma);  library(edgeR);   library(Rsubread);	library(biomaRt)  }   #library("ggbiplot");  #
	#########
	if(exists("Running_Step_3_Models_Process.Data")) if(Running_Step_3_Models_Process.Data==1) {
		#########
		source(paste(MAIN.MAIN.DIR...Pipeline..RNseq,"RR0.Function.RNAseq..Join.Algorithms.r",sep=""))
		#########
		library(GO.db)
		if(DIR_Annotations.Organism=="Homo_sapiens"     ) require(org.Hs.eg.db)
		if(DIR_Annotations.Organism=="Mus_musculus"     ) require(org.Mm.eg.db) 
	    if(DIR_Annotations.Organism=="Rattus_norvegicus") require(org.Rn.eg.db)
		#########
		if(RNAseq..running.DESeq==1) {
			#########
			library("DESeq");   library("DESeq2");  library("RColorBrewer");  library("gplots");   library("pheatmap")   ##library("vsn");   
}	}	}

############################################################################## TXT_RNAseq..Version_File
##############################################################################
if(DIR_Annotations.Source.hg=="NONE" | DIR_Annotations.Source.hg=="RSEM" | DIR_Annotations.Source.hg=="Others") {
	#########
	if(DIR_Annotations.Source.hg=="RSEM"  ) RNAseq..XXX.Gene.ID.Version= RNAseq..RSEM.Gene.ID.Version
	if(DIR_Annotations.Source.hg=="Others") RNAseq..XXX.Gene.ID.Version= RNAseq..Other.Gene.ID.Version
	#########
	DIR_Annotations.Source=DIR_Annotations.Source.hg;		RNAseq..Global.hg19.hg38="NONE"
} else {
	#########
	RNAseq..XXX.Gene.ID.Version= RNAseq..Fastq.Gene.ID.Version
	#########
	AAA= unlist(strsplit(DIR_Annotations.Source.hg, ":", fixed=TRUE));  if(length(AAA)!=2) stop(paste("MAIN ERROR --> Annotations.Source.hg is not well defined -->",DIR_Annotations.Source.hg ))
	DIR_Annotations.Source= AAA[1];		RNAseq..Global.hg19.hg38=AAA[2]
}
##################
 if(DIR_Annotations.Organism=="Mus_musculus"     ) RNAseq..Global.hg19.hg38= gsub("hg19","mm9" ,RNAseq..Global.hg19.hg38,fixed=TRUE)
 if(DIR_Annotations.Organism=="Mus_musculus"     ) RNAseq..Global.hg19.hg38= gsub("hg38","mm10",RNAseq..Global.hg19.hg38,fixed=TRUE) 
#if(DIR_Annotations.Organism=="Mus_musculus"     ) RNAseq..Global.hg19.hg38= gsub("hg38","mm39",RNAseq..Global.hg19.hg38,fixed=TRUE)
 if(DIR_Annotations.Organism=="Rattus_norvegicus") RNAseq..Global.hg19.hg38= gsub("hg38","rn7" ,RNAseq..Global.hg19.hg38,fixed=TRUE)
############
TXT_RNAseq..Version_File= FFFF_Annotations.Files.Names(DIR_Annotations.Source, DIR_Annotations.Organism, RNAseq..Global.hg19.hg38)
TXT_RNAseq..Short.V_File= TXT_RNAseq..Short.V_File..FF;  rm(TXT_RNAseq..Short.V_File..FF)
############
if(DIR_RNAseq..from.FASTq.or.BAM.files==2){ TXT_RNAseq..Version_File= paste(TXT_RNAseq..Version_File,"-bam"                   ,sep="");      TXT_RNAseq..Short.V_File= paste(TXT_RNAseq..Short.V_File,        "-b"             ,sep="") }
if(     RNAseq..SEQ.ver.run!="1"         ){ TXT_RNAseq..Version_File= paste(TXT_RNAseq..Version_File,"..F",RNAseq..SEQ.ver.run,sep="");		 TXT_RNAseq..Short.V_File= paste(TXT_RNAseq..Short.V_File,".F", RNAseq..SEQ.ver.run,sep="") }
#################
TXT_RNAseq..Version_RSEM="";     TXT_RNAseq..Version_Others= "";        
if(RNAseq..RSEM.ver.run!="1") TXT_RNAseq..Version_RSEM= paste("..F", RNAseq..RSEM.ver.run, sep="");        if(RNAseq..Othe.ver.run!="1") TXT_RNAseq..Version_RSEM= paste("..F", RNAseq..Othe.ver.run, sep="")
#################
RNAseq..RUN.fastq...RSEM..Others=1;  if(DIR_Annotations.Source=="RSEM") RNAseq..RUN.fastq...RSEM..Others=2;  if(DIR_Annotations.Source=="Others") RNAseq..RUN.fastq...RSEM..Others=3

############################################################################## setup dir (Main) 
##############################################################################
TXT_RNAseq..COLUMN.GeneInfo.Org   = c("GeneID"  ,"chromosome","Symbol",              "dbXrefs"          , "Synonyms","type_of_gene","map_location","description","Symbol_from_nomenclature_authority","Full_name_from_nomenclature_authority","Other_designations")
TXT_RNAseq..COLUMN.GeneInfo.New   = c("GeneID"  ,"chromosome","Symbol",              "dbXrefs"          , "Synonyms","type_of_gene","map_location","description","Symbol_authority"                  ,                "description_authority","Other_designations")
TXT_RNAseq..ANNOTA.GeneInfo.Pipe  = c(           "chromosome","Symbol", "HGNC.ID","ensembl.ID","Vega.ID", "Synonyms","type_of_gene","map_location","description","Symbol_authority"                  ,                "description_authority","Other_designations")
TXT_RNAseq..COLUMN.GeneInfo.Counts= c("Synonyms","chromosome",          "HGNC.ID","ensembl.ID"          ,            "type_of_gene")

##################################### step1
RNAseq..Version..REF_REF  = c("11-4-18","14-Sep-20")[2];
######
if(RNAseq..Version..REF_REF=="14-Sep-20"){
	DIR_Annotations..fastq= "error"
	if(DIR_Annotations.Source.hg=="RSEM" | DIR_Annotations.Source.hg=="Others") DIR_Annotations..fastq= "NONE"
    ######
    if(DIR_Annotations.Organism[1]=="Homo_sapiens"      & DIR_Annotations.Source.hg=="UCSC:hg19"   ) DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Human/HG_REF_hg19_EXAC/_RNAseq/"          ,sep="")
    if(DIR_Annotations.Organism[1]=="Homo_sapiens"      & DIR_Annotations.Source.hg=="UCSC:hg38"   ) DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Human/HG_REF_hg38__GRC/_RNAseq/"          ,sep="")
    if(DIR_Annotations.Organism[1]=="Mus_musculus"      & DIR_Annotations.Source.hg=="UCSC:hg38"   ) DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Mouse/HG_REF_mm10_UCSC/_RNAseq/"          ,sep="")
	############ 2023
  ##if(DIR_Annotations.Organism[1]=="Mus_musculus"      & DIR_Annotations.Source.hg=="UCSC:hg38"   ) DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Mouse/HG_REF_mm39_UCSC/_RNAseq/"          ,sep="")
	if(DIR_Annotations.Organism[1]=="Rattus_norvegicus" & DIR_Annotations.Source.hg=="UCSC:hg38"   ) DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Rat/HG_REF_rn7_UCSC/_RNAseq/"             ,sep="")
	######
  ##if(DIR_Annotations.Organism[1]=="Homo_sapiens"      & DIR_Annotations.Source.hg=="Ensembl:Ch38") DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Human/HG_REF_GRCm38.R101_Ensambl/_RNAseq/",sep="")
  ##if(DIR_Annotations.Organism[1]=="Mus_musculus"      & DIR_Annotations.Source.hg=="Ensembl:Ch38") DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Mouse/HG_REF_GRCm38.R101_Ensambl/_RNAseq/",sep="")
	############ 2023
    if(DIR_Annotations.Organism[1]=="Homo_sapiens"      & DIR_Annotations.Source.hg=="Ensembl:Ch38") DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Human/HG_REF_GRCm38.R110_Ensambl/_RNAseq/",sep="")
    if(DIR_Annotations.Organism[1]=="Mus_musculus"      & DIR_Annotations.Source.hg=="Ensembl:Ch38") DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Mouse/HG_REF_GRCm39.R110_Ensambl/_RNAseq/",sep="")
	if(DIR_Annotations.Organism[1]=="Rattus_norvegicus" & DIR_Annotations.Source.hg=="Ensembl:Ch38") DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "XX..Reference_Genome/Rat/HG_REF_rat_n72_Ensambl/_RNAseq/"      ,sep="")
	######
	if(DIR_Annotations..fastq[1]=="error" & DIR_Annotations.Source.hg!="NONE") stop(paste("MAIN ERROR --->     DIR_Annotations..fastq in not defined or created      ---> Organism=", DIR_Annotations.Organism,"       Source.hg=", DIR_Annotations.Source.hg))

} else DIR_Annotations..fastq= paste(DIR_RNAseq..Annotations[1], "YY..RNAseq/_REF_REF.2019/Rsubread/", DIR_Annotations.Algoritm[1], "/", DIR_Annotations.Organism[1], "/", DIR_Annotations.Source[1], "/", RNAseq..REFERENCE.Version[1],"/WholeGenomeFasta/",sep="")

##########################################################################
DIR_Annotations..Gene = paste(DIR_RNAseq..Annot.Genes[1], DIR_Annotations.Organism[1], "/", RNAseq..Version..Gene.info[1],"/",sep="")

############################### RNAseq..Ensanbl.gene_inf..DIR
RNAseq..Ensanbl.gene_inf= "error"
if(DIR_Annotations.Organism=="Homo_sapiens"     ) RNAseq..Ensanbl.gene_inf= "Homo_sapiens.GRCh38.110.gtf.gz" 
if(DIR_Annotations.Organism=="Mus_musculus"     ) RNAseq..Ensanbl.gene_inf= "Mus_musculus.GRCm39.110.gtf.gz"
if(DIR_Annotations.Organism=="Rattus_norvegicus") RNAseq..Ensanbl.gene_inf= "Rattus_norvegicus.mRatBN7.2.110.gtf.gz"
if(RNAseq..Ensanbl.gene_inf=="error") stop(paste("MAIN ERROR --> no definition for RNAseq..Ensanbl.gene_inf --> DIR_Annotations.Organism=",DIR_Annotations.Organism ))
######
RNAseq..Ensanbl.gene_inf..DIR  = paste(DIR_Annotations..Gene , RNAseq..Ensanbl.gene_inf,sep="")

############################### RNAseq..Organism.gene_inf..DIR
RNAseq..Organism.gene_inf..DIR = paste(DIR_Annotations..Gene , RNAseq..Organism.gene_inf ,sep="")

##################################### step2
RNAseq..REFERENCE.BASENAME..DIR  = paste(DIR_Annotations..fastq, RNAseq..REFERENCE.BASENAME, sep="")
RNAseq..REFERENCE.BASENAME..reads= paste(RNAseq..REFERENCE.BASENAME..DIR,".reads",sep="")

############################################################################## setup files (Project)
##############################################################################
DIR_RNAseq..Results.Project= paste(DIR_RNAseq..Results        , TXT_RNAseq..PI.name,"/",Project.RNA..run,"/",sep="");
DIR_RNAseq..Results.RData  = paste(DIR_RNAseq..Results.Project, "_Rdata_Project"                                       ,"/",sep="");
######
DIR_RNAseq..Inputs.Project = paste(DIR_RNAseq..ORG.Inputs     , TXT_RNAseq..PI.name, "/", Project.RNA..run,"/",sep="");
######
txt..Trimmomatic="";   if(RUN..Trimmomatic..ONE=="Yes") txt..Trimmomatic="..Trim"
######
DIR_RNAseq..ORG.fastq.bam..DIR.VEC= paste(DIR_RNAseq..Inputs.Project, ORG.fastq.bam.DIR..VEC,sep="");     if(rm.files.Definitions==1) rm(ORG.fastq.bam.DIR..VEC)
DIR_RNAseq..KaOs.fastq.bam_files  = paste(DIR_RNAseq..ORG.fastq.bam..DIR.VEC[1], "_", TXT_RNAseq..Version_File, txt..Trimmomatic, "/" ,sep="")
######
FILE_RNAseq..KaOs.Counts.OUT.Rdata= paste("RNA.seq..Counts.."       , TXT_RNAseq..Version_File  , txt..Trimmomatic, ".Rdata",sep="")
######
FILE_RNAseq..Counts.Rdata..fastq  = paste("RNA.seq..Counts.fastq.." , TXT_RNAseq..Version_File  , txt..Trimmomatic, ".Rdata",sep="")
FILE_RNAseq..Counts.Rdata..RSEM_I = paste("RNA.seq..Counts.RSEM_Inp", TXT_RNAseq..Version_RSEM  , txt..Trimmomatic, ".Rdata",sep="")
FILE_RNAseq..Counts.Rdata..RSEM   = paste("RNA.seq..Counts.RSEM"    , TXT_RNAseq..Version_RSEM  , txt..Trimmomatic, ".Rdata",sep="")
FILE_RNAseq..Counts.Rdata..Othe   = paste("RNA.seq..Counts.Others"  , TXT_RNAseq..Version_Others, txt..Trimmomatic, ".Rdata",sep="");       if(rm.files.Definitions==1) rm(RNAseq..SEQ.ver.run)
######
if(RNAseq..RUN.fastq...RSEM..Others==1) FILE_RNAseq..Counts.Rdata..Step2= FILE_RNAseq..Counts.Rdata..fastq	
if(RNAseq..RUN.fastq...RSEM..Others==2) FILE_RNAseq..Counts.Rdata..Step2= FILE_RNAseq..Counts.Rdata..RSEM
if(RNAseq..RUN.fastq...RSEM..Others==3) FILE_RNAseq..Counts.Rdata..Step2= FILE_RNAseq..Counts.Rdata..Othe
######
FILE_RNAseq..QC.Plotting.PDF= sub(".Rdata",".pdf",FILE_RNAseq..Counts.Rdata..Step2,fixed=TRUE)

######
FILE_RNAseq..CSV_DATA.IDs.fatsq   = paste("_RNAseq_Samples_Info..",Project.RNA..run,".ToCHECK.csv",sep="")
DIR_RNAseq...CSV_DATA.IDs.fatsq   = paste(DIR_RNAseq..ORG.fastq.bam..DIR.VEC[1], "_", TXT_RNAseq..Version_File, "/" ,sep="")
######
DFILE_RNAseq..OTHERS.RSEM.files       = paste(DIR_RNAseq..Inputs.Project, DIR_RNAseq..OTHERS.RSEM.files        ,sep="")
DFILE_RNAseq..RSEM.external_to_compare= paste(DIR_RNAseq..Inputs.Project, FILE_RNAseq..RSEM.external_to_compare,sep="")

##############################################################################
############################################################################## step 3	
TXT_RNAseq..Version.USE= TXT_RNAseq..Version_File;   if(RNAseq..RUN.fastq...RSEM..Others==2) TXT_RNAseq..Version.USE= paste("RSEM",TXT_RNAseq..Version_RSEM,sep="");  if(RNAseq..RUN.fastq...RSEM..Others==3) TXT_RNAseq..Version.USE= paste("Others",TXT_RNAseq..Version_Others,sep="")
TXT_RNAseq..Short.V.USE= TXT_RNAseq..Short.V_File;   if(RNAseq..RUN.fastq...RSEM..Others==2) TXT_RNAseq..Short.V.USE= paste("RSEM",TXT_RNAseq..Version_RSEM,sep="");  if(RNAseq..RUN.fastq...RSEM..Others==3) TXT_RNAseq..Short.V.USE= paste("Others",TXT_RNAseq..Version_Others,sep="")
###########
txt..MIN.p.value="";  txt..MIN.Fil.FDR="";  txt..MIN.logFC=""
if(exists("RNAseq..Models..MIN.log2.fold")) if(RNAseq..Models..MIN.log2.fold!=1.2 ) txt..MIN.logFC  = paste("..log2fold-",RNAseq..Models..MIN.log2.fold,sep="")
if(exists("RNAseq..Models..MIN.p.value"  )) if(RNAseq..Models..MIN.p.value  !=0.05) txt..MIN.p.value= paste("..pvalue-"  ,RNAseq..Models..MIN.p.value  ,sep="")
if(exists("RNAseq..Models..MIN.Fil1.FDR" )) if(RNAseq..Models..MIN.Fil1.FDR !=0.05) txt..MIN.Fil.FDR= paste("..FDR-"     ,RNAseq..Models..MIN.Fil1.FDR ,sep="")
###########
txt..Table.SAVE="";   #if(RNAseq..test_kaOs..SAVE    ==  8 ) txt..Table.SAVE ="" else txt..Table.SAVE = paste("..Model-" ,RNAseq..test_kaOs..SAVE    ,sep="")
if(RNAseq..Project_num.Ver    =="AA") txt..Project.Ver="" else txt..Project.Ver= paste("..Ver-"   ,RNAseq..Project_num.Ver    ,sep="")
###########
txt..USE.diff="";   if(exists("RNAseq..FORCE_USE.only.one.libType")) if(RNAseq..FORCE_USE.only.one.libType!=0) txt..USE.diff= paste("__L",RNAseq..FORCE_USE.only.one.libType,sep="")
DIR_RNAseq..Results.Models..L0= paste(DIR_RNAseq..Results.Project,"Results",RNAseq..Result.Version,".",RNAseq..Project_num.Ver,"..",Project.RNA..run,"..",TXT_RNAseq..Version.USE,
                                  txt..MIN.logFC, txt..MIN.p.value, txt..MIN.Fil.FDR, txt..Table.SAVE, txt..USE.diff,sep="");
DIR_RNAseq..Results.Models..L1= paste(DIR_RNAseq..Results.Models..L0,"__L1",txt..Trimmomatic,"/",sep="")                                  
DIR_RNAseq..Results.Models    = paste(DIR_RNAseq..Results.Models..L0,       txt..Trimmomatic,"/",sep="")
###########                                                              
if(rm.files.Definitions==1) rm(txt..MIN.logFC, txt..MIN.p.value, txt..MIN.Fil.FDR, txt..Table.SAVE, txt..USE.diff, txt..Project.Ver, txt..Trimmomatic)
###########
DIR_RNAseq..Results.Models.Rdata= paste(DIR_RNAseq..Results.Models,"_Rdata_Models/",sep="")

##############################################################################
############################################################################## step 3 and 4	
if(exists("filtering.Boris1a.Boris1b.Boris1.Limma.none")) if(exists("RNAseq..Models..VOOM")) {
	###########
	TXT.filtering.VOOM..SVersion= paste(RNAseq..Project_num.Ver,".",DIR_Annotations.Algoritm,"-Test","XXX","..Fi-B",filtering.Boris1a.Boris1b.Boris1.Limma.none[1],".V", RNAseq..Models..VOOM[1], "..",TXT_RNAseq..Short.V.USE,sep="")
	TXT.filtering.VOOM..SVersion= paste(Project.RNA..run,"-Test","XXX",sep="");  
	if(exists("Project.RNA..Pipe.ID")) TXT.filtering.VOOM..SVersion= paste(Project.RNA..Pipe.ID,"-Test","XXX",sep="")
}

############################################################################## setup dirs {
############################################################################## 
if(!exists("Remove.DIR...Main.Results.Step1"    )) Remove.DIR...Main.Results.Step1   = 0;   
if(!exists("Remove.DIR...Results.Models.Step3"  )) Remove.DIR...Results.Models.Step3 = 0;   
if(!exists("Running_Step_1a_Sript_Process.Data" )) Running_Step_1a_Sript_Process.Data =0;
if(!exists("Running_Step_3_Models_Process.Data" )) Running_Step_3_Models_Process.Data =0;
if(!exists("Running_Step_1a..Remove.DIR.BAM.dir")) Running_Step_1a..Remove.DIR.BAM.dir=0;
#########
ERROR.DIR= c();   for(Dir in DIR_RNAseq..ORG.fastq.bam..DIR.VEC) if(!file.exists(Dir)) ERROR.DIR= c(ERROR.DIR, Dir)
if(length(ERROR.DIR)>0) if(Running_Step_1a_Sript_Process.Data==1) { print(paste(" ERROR ERROR --> main inputs directory does not exists --->", length(ERROR.DIR)));  print(ERROR.DIR);  print("");  stop("kaOs is stopping") }
if(rm.files.Definitions==1) rm(ERROR.DIR)
###########################
XX.RUn..Sleeping=1
if(DIR_Annotations.Source.hg!="NONE") if(Remove.DIR...Main.Results.Step1==1   & Running_Step_1a_Sript_Process.Data==1) for(DIR.RM in c( DIR_RNAseq..Results.Project )) if(file.exists(DIR.RM)) {
	if(XX.RUn..Sleeping==1){ print(""); print("sleeping time --> 15 seg") };  print(paste(" Warning --> removing Directory -->", DIR.RM));   if(XX.RUn..Sleeping==1){ Sys.sleep(15); XX.RUn..Sleeping=0 };  print("");  
	FFFX_Remove_DIR..Unlink(DIR.RM, 1, 1)
} 
if(DIR_Annotations.Source.hg!="NONE") if(Remove.DIR...Results.Models.Step3==1 & Running_Step_3_Models_Process.Data==1) for(DIR.RM in c( DIR_RNAseq..Results.Models, DIR_RNAseq..Results.Models..L1)) if(file.exists(DIR.RM)) {
	if(XX.RUn..Sleeping==1){ print(""); print("sleeping time --> 15 seg") };  print(paste(" Warning --> removing Directory -->", DIR.RM));   if(XX.RUn..Sleeping==1){ Sys.sleep(15); XX.RUn..Sleeping=0 };  print("");  
	FFFX_Remove_DIR..Unlink(DIR.RM, 1, 1)
}
#########
if(!exists("RUN.align.FASTQ..step1" )) RUN.align.FASTQ..step1= 0;     
if(Running_Step_1a_Sript_Process.Data==1) if(Running_Step_1a..Remove.DIR.BAM.dir==1) if(RUN.align.FASTQ..step1==1 | DIR_RNAseq..from.FASTq.or.BAM.files==2)
if(DIR_Annotations.Source.hg!="NONE") if(Testing.bam.vcf.files.names.Step1.x==0) if(file.exists(DIR_RNAseq..KaOs.fastq.bam_files)) {
	#########
	if(XX.RUn..Sleeping==1){ print("");  print("sleeping time --> 15 seg")};  print(paste(" Warning --> removing Directory -->", DIR_RNAseq..KaOs.fastq.bam_files));   if(XX.RUn..Sleeping==1){ Sys.sleep(15); XX.RUn..Sleeping=0 };  print("")
	FFFX_Remove_DIR..Unlink(DIR_RNAseq..KaOs.fastq.bam_files, 1)
};  
if(rm.files.Definitions==1){ rm(XX.RUn..Sleeping);  if(exists("DIR.RM")) rm(DIR.RM) }
#########
if(DIR_Annotations.Source.hg!="NONE") {
	#########
	if(!file.exists(DIR_RNAseq..Results.Project)) dir.create(DIR_RNAseq..Results.Project, showWarnings = FALSE, recursive = TRUE);
	if(!file.exists(DIR_RNAseq..Results.RData  )) dir.create(DIR_RNAseq..Results.RData  , showWarnings = FALSE, recursive = TRUE);
	#########
	if(Running_Step_1a_Sript_Process.Data==1) if(!file.exists(DIR_RNAseq..KaOs.fastq.bam_files)) dir.create(DIR_RNAseq..KaOs.fastq.bam_files, showWarnings = FALSE, recursive = TRUE);
	#if(Running_Step_3_Models_Process.Data==1) if(!file.exists(DIR_RNAseq..Results.Models.Rdata)) dir.create(DIR_RNAseq..Results.Models.Rdata, showWarnings = FALSE, recursive = TRUE);
}

######### 
rm(Testing.bam.vcf.files.names.Step1.x)

############################################################################## print 
############################################################################## 
if(print..RNAseq_results>0) {
	TXT.print= paste(DIR_Annotations.Source,"-",RNAseq..Global.hg19.hg38,sep="");    #if(DIR_Annotations.Source.hg=="RSEM") TXT.print="RSEM";	if(DIR_Annotations.Source.hg=="Others") TXT.print="Others"
	##########
	print("");  print(paste("#######################################################################################################", TXT.print))
	##########
	print(paste("#######################  Running for -->", FILE_RNAseq..KaOs.Counts.OUT.Rdata));     print(DIR_RNAseq..Results.RData)
}	

###########################################################################################################################################
########################################################################################################################################### 
###########################################################################################################################################

############################################################################## download annotations and gene fino
##############################################################################
### wget --timestamping ftp://igenome:G3nom3s4u@ussd-ftp.illumina.com/Mus_musculus/Ensembl/NCBIM37/Mus_musculus_Ensembl_NCBIM37.tar.gz
### https://ccb.jhu.edu/software/tophat/igenomes.shtml
### ### ### 
### wget --timestamping ftp://igenome:G3nom3s4u@ussd-ftp.illumina.com/Mus_musculus/UCSC/mm10/Mus_musculus_UCSC_mm10.tar.gz
### wget --timestamping ftp://igenome:G3nom3s4u@ussd-ftp.illumina.com/Mus_musculus/UCSC/mm9/Mus_musculus_UCSC_mm9.tar.gz
### wget --timestamping ftp://igenome:G3nom3s4u@ussd-ftp.illumina.com/Mus_musculus/Ensembl/NCBIM37/Mus_musculus_Ensembl_NCBIM37.tar.gz
### wget --timestamping ftp://igenome:G3nom3s4u@ussd-ftp.illumina.com/Mus_musculus/NCBI/build37.2/Mus_musculus_NCBI_build37.2.tar.gz
### wget --timestamping ftp://igenome:G3nom3s4u@ussd-ftp.illumina.com/Homo_sapiens/NCBI/build37.2/Homo_sapiens_NCBI_build37.2.tar.gz
### wget --timestamping ftp://igenome:G3nom3s4u@ussd-ftp.illumina.com/Homo_sapiens/UCSC/hg19/Homo_sapiens_UCSC_hg19.tar.gz
### wget --timestamping ftp://igenome:G3nom3s4u@ussd-ftp.illumina.com/Homo_sapiens/Ensembl/GRCh37/Homo_sapiens_Ensembl_GRCh37.tar.gz
### 
### wget --timestamping  http://hgdownload.soe.ucsc.edu/goldenPath/hg38/bigZips/hg38.fa.gz
###
### tar -zxvf Mus_musculus_UCSC_mm10.tar.gz
###
##############################################
### ftp://ftp.ncbi.nih.gov/gene/DATA/GENE_INFO/Mammalia/
###
### wget --timestamping ftp.ncbi.nih.gov:gene/DATA/GENE_INFO/Mammalia/Homo_sapiens.gene_info.gz
### wget --timestamping ftp.ncbi.nih.gov:gene/DATA/GENE_INFO/Mammalia/Mus_musculus.gene_info.gz
###
### gunzip Homo_sapiens.gene_info.gz;   gunzip Mus_musculus.gene_info.gz
###
##############################################################################
##############################################################################

##############################################################################
##############################################################################
### https://www.genenames.org/cgi-bin/statistics
###
### download "Complete HGNC dataset", "HGNC Gene Family dataset"
###
##### if(RNAseq..Version..Gene.info=="11-4-18")   COl.HGNC.USE= c("hgnc_id","symbol","entrez_id","ensembl_gene_id")
##### 
##### hgnc_id	symbol	name	locus_group	locus_type	status	location	location_sortable	alias_symbol	alias_name	prev_symbol	prev_name	gene_family	gene_family_id	date_approved_reserved	
##### date_symbol_changed	date_name_changed	date_modified	entrez_id	ensembl_gene_id	vega_id	ucsc_id	ena	refseq_accession	ccds_id	uniprot_ids	pubmed_id	mgd_id	rgd_id	lsdb	cosmic	omim_id	mirbase	homeodb	snornabase	bioparadigms_slc	
##### orphanet	pseudogene.org	horde_id	merops	imgt	iuphar	kznf_gene_catalog	mamit-trnadb	cd	lncrnadb	enzyme_id	intermediate_filament_db	rna_central_ids
##### 
##############################################################################
##############################################################################