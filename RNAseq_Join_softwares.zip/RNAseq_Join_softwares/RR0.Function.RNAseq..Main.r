
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################

## FFFF_Annotations.Files.Names

#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################

#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..ADD.GENE.LIST.TOGO= function(TABLE.TOGO..KK, TABLE.Models.SAVE.Com..KK, RNAseq..Data.Special.Genes.list..KK, print.ADD.Gene..KK=c(1,2,0)[2]) {

### TABLE.TOGO..KK=TABLE.SAVE.TOGO; RNAseq..Data.Special.Genes.list..KK= RNAseq..Data.Special.Genes.list;  print.ADD.Gene..KK=c(1,2,0)[2]

######################################################
Gene.Columns..KK= colnames(RNAseq..Data.Special.Genes.list..KK);   Gene.Columns..KK= Gene.Columns..KK[Gene.Columns..KK!="ROWS"]
######
if(print.ADD.Gene..KK>0){ print(paste("################ FFF.RNAseq..ADD.GENE.LIST.TOGO --> gene list=",length(Gene.Columns..KK),"      rows=",nrow(TABLE.TOGO..KK),"       ", date() )); print("") }

######################################################
COl.Script..KK= c("Selection","##G",Gene.Columns..KK)
######
if(length(Gene.Columns..KK)>0 & nrow(TABLE.TOGO..KK)>0) {
	########
	col..ORG.TOGO..KK= colnames(TABLE.TOGO..KK);   for(CC.del.k in COl.Script..KK) col..ORG.TOGO..KK= col..ORG.TOGO..KK[col..ORG.TOGO..KK!=CC.del.k];			COLNAMES.KK= colnames(TABLE.Models.SAVE.Com..KK);	
	TABLE.TOGO..KK= cbind(TABLE.TOGO..KK[,c(1:length(COl.Script..KK))], TABLE.TOGO..KK[,col..ORG.TOGO..KK]);  colnames(TABLE.TOGO..KK)[1:length(COl.Script..KK)]= COl.Script..KK;
	########
	TABLE.TOGO..KK[,Gene.Columns..KK]=0;	TABLE.TOGO..KK[,"Selection"]="";  TABLE.TOGO..KK[,"##G"]="##";    TABLE.TOGO..KK[,"genes.commas"]= tolower(gsub(" ","",paste(",",TABLE.TOGO..KK[,"genes.GoTo"],",",sep=""),fixed=TRUE))
	########
	for(Gene.L.kk in Gene.Columns..KK){
		########
		TABLE.TOGO..KK[,Gene.L.kk]=0;	
		########
		if(length(COLNAMES.KK[COLNAMES.KK==Gene.L.kk])>0){
			   GENE.search.VEC..KK= TABLE.Models.SAVE.Com..KK[TABLE.Models.SAVE.Com..KK[,Gene.L.kk]!="","gene.Raw"]
		} else GENE.search.VEC..KK= RNAseq..Data.Special.Genes.list..KK[,Gene.L.kk];  
		########
		GENE.search.VEC..KK= GENE.search.VEC..KK[!is.na(GENE.search.VEC..KK)];  GENE.search.VEC..KK= GENE.search.VEC..KK[GENE.search.VEC..KK!=""]
		########
		if(length(GENE.search.VEC..KK)>0) GENE.search.VEC..KK= unique(tolower(gsub(" ","",GENE.search.VEC..KK)))
		if(length(GENE.search.VEC..KK)>0) for(gene.S in paste(",",GENE.search.VEC..KK,",",sep=""))
			if(length(TABLE.TOGO..KK[grep(gene.S,TABLE.TOGO..KK[,"genes.commas"],fixed=TRUE),Gene.L.kk])>0)
					  TABLE.TOGO..KK[grep(gene.S,TABLE.TOGO..KK[,"genes.commas"],fixed=TRUE),Gene.L.kk]=
					  TABLE.TOGO..KK[grep(gene.S,TABLE.TOGO..KK[,"genes.commas"],fixed=TRUE),Gene.L.kk]+1
		########
		MAX.PRINT.GENE..KK= max(TABLE.TOGO..KK[,Gene.L.kk])
		if(print.ADD.Gene..KK>0) print(paste(" Table hit for -->",Gene.L.kk,"    genes=", length(GENE.search.VEC..KK),"      max hit=",MAX.PRINT.GENE..KK ));  if(print.ADD.Gene..KK>1){ print(table(TABLE.TOGO..KK[,Gene.L.kk]));  print("") }
	}	
	TABLE.TOGO..KK= TABLE.TOGO..KK[,c(COl.Script..KK,col..ORG.TOGO..KK)]
}
##################
return(TABLE.TOGO..KK)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################



#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFFF_Annotations.Files.Names= function(DIR_Annotations.Source..ff, DIR_Annotations.Organism..ff="Homo_sapiens", RNAseq..Global.hg19.hg38.ff= c("Ch37","hg19","hg38","mm9","mm10")[1] ) {

##################################################################################
BASENAME..ff= "genome";         REFERENCE..ff="genome.fa";      REFERENCE.UCSC..ff="error";      REFERENCE.featureCounts..ff="error";     TXT.NAME..ff= c();     TXT.SHORT..ff= c();	

###########################################
## RNAseq..Global.hg19.hg38.ff= RNAseq..Global.hg19.hg38.ff[1]
###########
hg19.hg38.ff= -10
if(RNAseq..Global.hg19.hg38.ff=="Ch37") hg19.hg38.ff= 1;		if(RNAseq..Global.hg19.hg38.ff=="Ch38") hg19.hg38.ff= 2
if(RNAseq..Global.hg19.hg38.ff=="hg19") hg19.hg38.ff= 1;	    if(RNAseq..Global.hg19.hg38.ff=="hg38") hg19.hg38.ff= 2;		if(RNAseq..Global.hg19.hg38.ff=="rn7" ) hg19.hg38.ff= 2;	
if(RNAseq..Global.hg19.hg38.ff=="mm9" ) hg19.hg38.ff= 1; 		if(RNAseq..Global.hg19.hg38.ff=="mm10") hg19.hg38.ff= 2; 		if(RNAseq..Global.hg19.hg38.ff=="mm39") hg19.hg38.ff= 2
###########
if(DIR_Annotations.Source..ff=="Ensembl") if(hg19.hg38.ff<=0 | hg19.hg38.ff>=3) stop(paste(" ERROR -->  Ensembl --> only have Ch37 or Ch38   --->  RNAseq..Global.hg19.hg38 =", RNAseq..Global.hg19.hg38.ff ))
if(DIR_Annotations.Source..ff=="NCBI"   ) if(hg19.hg38.ff<=0 | hg19.hg38.ff>=3) stop(paste(" ERROR -->  NCBI    --> only have Ch37 or Ch38   --->  RNAseq..Global.hg19.hg38 =", RNAseq..Global.hg19.hg38.fff))
if(DIR_Annotations.Organism..ff=="Homo_sapiens")
if(DIR_Annotations.Source..ff=="UCSC"   ) if(hg19.hg38.ff<=0 | hg19.hg38.ff>=3) stop(paste(" ERROR -->  UCSC    --> only have hg19 or hg38   --->  RNAseq..Global.hg19.hg38 =", RNAseq..Global.hg19.hg38.ff ))
if(DIR_Annotations.Organism..ff=="Mus_musculus")
if(DIR_Annotations.Source..ff=="UCSC"   ) if(hg19.hg38.ff<=0 | hg19.hg38.ff>=3) stop(paste(" ERROR -->  UCSC    --> only have mm9  or mm10   --->  RNAseq..Global.hg19.hg38 =", RNAseq..Global.hg19.hg38.ff ))
if(DIR_Annotations.Organism..ff=="Rattus_norvegicus")
if(DIR_Annotations.Source..ff=="UCSC"   ) if(hg19.hg38.ff<=0 | hg19.hg38.ff>=3) stop(paste(" ERROR -->  UCSC    --> only have rn7            --->  RNAseq..Global.hg19.hg38 =", RNAseq..Global.hg19.hg38.ff ))

########################################### 
if(DIR_Annotations.Organism..ff=="Homo_sapiens") {
	######
	RNAseq..Organism.gene_inf..ff= "Homo_sapiens.gene_info";		TXT.NAME..ff= c(TXT.NAME..ff,"Homo");     TXT.SHORT..ff= c(TXT.SHORT..ff,"H");	
	######
	if(DIR_Annotations.Source..ff=="Ensembl"){ REFERENCE.Version..ff= c("GRCh37","NCBIM38")[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("Ch37","Ch38")[hg19.hg38.ff];	  	TXT.NAME..ff= c(TXT.NAME..ff,"Ense");     TXT.SHORT..ff= c(TXT.SHORT..ff,"E") }
	if(DIR_Annotations.Source..ff=="NCBI"   ){ REFERENCE.Version..ff= c("build37.2"       )[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("Ch37"       )[hg19.hg38.ff];	  	TXT.NAME..ff= c(TXT.NAME..ff,"NCBI");     TXT.SHORT..ff= c(TXT.SHORT..ff,"N") }
	if(DIR_Annotations.Source..ff=="UCSC"   ){ REFERENCE.Version..ff= c("hg19","hg38"     )[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("hg19","hg38")[hg19.hg38.ff];	    TXT.NAME..ff= c(TXT.NAME..ff,"UCSC");     TXT.SHORT..ff= c(TXT.SHORT..ff,"U") }
	######
	#### annot.inbuilt: a character string specifying an in-built annotation used for read summarization. It has four possible values including ‘"mm10"’, ‘"mm9"’, ‘"hg38"’ and ‘"hg19"’, corresponding to the NCBI RefSeq annotations for genomes `mm10', `mm9', `hg38' and `hg19', respectively.
	######
	if(REFERENCE.UCSC..ff[1]=="Ch37") REFERENCE.featureCounts..ff= "hg19"
	if(REFERENCE.UCSC..ff[1]=="Ch38") REFERENCE.featureCounts..ff= "hg38"
	if(REFERENCE.UCSC..ff[1]=="hg19") REFERENCE.featureCounts..ff= "hg19";
	if(REFERENCE.UCSC..ff[1]=="hg38") REFERENCE.featureCounts..ff= "hg38";   
}
if(DIR_Annotations.Organism..ff=="Mus_musculus") {
	RNAseq..Organism.gene_inf..ff= "Mus_musculus.gene_info";		TXT.NAME..ff= c(TXT.NAME..ff,"Mus");     TXT.SHORT..ff= c(TXT.SHORT..ff,"M");
	######
	if(DIR_Annotations.Source..ff=="Ensembl"){ REFERENCE.Version..ff= c("NCBIM37","NCBIM38")[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("Ch37","Ch38")[hg19.hg38.ff];		TXT.NAME..ff= c(TXT.NAME..ff,"Ense");     TXT.SHORT..ff= c(TXT.SHORT..ff,"E") }
	if(DIR_Annotations.Source..ff=="NCBI"   ){ REFERENCE.Version..ff= c("build37.2"        )[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("Ch37"       )[hg19.hg38.ff];		TXT.NAME..ff= c(TXT.NAME..ff,"NCBI");     TXT.SHORT..ff= c(TXT.SHORT..ff,"N") }
    if(DIR_Annotations.Source..ff=="UCSC"   ){ REFERENCE.Version..ff= c("mm9","mm10"       )[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("mm9","mm10" )[hg19.hg38.ff];		TXT.NAME..ff= c(TXT.NAME..ff,"UCSC");     TXT.SHORT..ff= c(TXT.SHORT..ff,"U") }
  ##if(DIR_Annotations.Source..ff=="UCSC"   ){ REFERENCE.Version..ff= c("mm9","mm39"       )[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("mm9","mm39" )[hg19.hg38.ff];		TXT.NAME..ff= c(TXT.NAME..ff,"UCSC");     TXT.SHORT..ff= c(TXT.SHORT..ff,"U") }
	######
	if(REFERENCE.UCSC..ff[1]=="Ch37" | REFERENCE.UCSC..ff[1]=="mm9" ) REFERENCE.featureCounts..ff= "mm9"
	if(REFERENCE.UCSC..ff[1]=="Ch38" | REFERENCE.UCSC..ff[1]=="mm10") REFERENCE.featureCounts..ff= "mm10" 
  ##if(REFERENCE.UCSC..ff[1]=="Ch38" | REFERENCE.UCSC..ff[1]=="mm39") REFERENCE.featureCounts..ff= "mm39" 
}
if(DIR_Annotations.Organism..ff=="Rattus_norvegicus") {
	RNAseq..Organism.gene_inf..ff= "Rattus_norvegicus.gene_info";		TXT.NAME..ff= c(TXT.NAME..ff,"Rat");     TXT.SHORT..ff= c(TXT.SHORT..ff,"R");			if(hg19.hg38.ff==1) stop()
	######
	if(DIR_Annotations.Source..ff=="Ensembl"){ REFERENCE.Version..ff= c("rn??"   , "N72" )[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("rn??", "rn7")[hg19.hg38.ff];		TXT.NAME..ff= c(TXT.NAME..ff,"Ense");     TXT.SHORT..ff= c(TXT.SHORT..ff,"E") }
	if(DIR_Annotations.Source..ff=="UCSC"   ){ REFERENCE.Version..ff= c("rn??"   , "rn7" )[hg19.hg38.ff];	  REFERENCE.UCSC..ff= c("rn??", "rn7")[hg19.hg38.ff];		TXT.NAME..ff= c(TXT.NAME..ff,"UCSC");     TXT.SHORT..ff= c(TXT.SHORT..ff,"U") }
	######
	if(REFERENCE.UCSC..ff[1]=="Ch38" | REFERENCE.UCSC..ff[1]=="rn7" ) REFERENCE.featureCounts..ff= "rn7" 
}
######
if(DIR_Annotations.Algoritm=="Rsubread"   ){ TXT.NAME.Algoritm..ff= "Rsub";     TXT.SHORT.Algoritm..ff= "R" }
if(DIR_Annotations.Algoritm=="TopHat"     ){ TXT.NAME.Algoritm..ff= "TopH";     TXT.SHORT.Algoritm..ff= "T" }
if(DIR_Annotations.Algoritm=="_FIRST_kaos"){ TXT.NAME.Algoritm..ff= "XX";     	TXT.SHORT.Algoritm..ff= "X" }
######
if(RNAseq..Global.hg19.hg38.ff=="NONE"){ REFERENCE.UCSC..ff="NONE";  REFERENCE.featureCounts..ff="NONE";  REFERENCE.Version..ff="NONE" }
#####################
if(REFERENCE.UCSC..ff         =="error") stop(paste("ERROR ERROR  --> REFERENCE.UCSC          -->  do not have any value -->", REFERENCE.UCSC..ff         ))
if(REFERENCE.featureCounts..ff=="error") stop(paste("ERROR ERROR  --> REFERENCE.featureCounts -->  do not have any value -->", REFERENCE.featureCounts..ff))
if(TXT.NAME.Algoritm..ff      =="error") stop(paste("ERROR ERROR  --> TXT.NAME.Algoritm..ff   -->  do not have any value -->", TXT.NAME.Algoritm..ff      ))

#####################
REFERENCE.UCSC.Short..ff= REFERENCE.UCSC..ff;  for(DEL.kk in c("Ch","hg","mm")) REFERENCE.UCSC.Short..ff= gsub(DEL.kk,"",REFERENCE.UCSC.Short..ff,fixed=TRUE)
######
TXT.NAME..ff = c(TXT.NAME..ff , TXT.NAME.Algoritm..ff );     TXT_RNAseq..Version_File..ff= paste(paste(TXT.NAME..ff ,collapse="."),"-",REFERENCE.UCSC..ff      ,sep="")   
TXT.SHORT..ff= c(TXT.SHORT..ff, TXT.SHORT.Algoritm..ff);     TXT_RNAseq..Short.V_File..ff= paste(paste(TXT.SHORT..ff,collapse= ""), "",REFERENCE.UCSC.Short..ff,sep="")

##########################################
RNAseq..REFERENCE.BASENAME      <<- BASENAME..ff
RNAseq..REFERENCE.Name          <<- REFERENCE..ff
RNAseq..REFERENCE.Version       <<- REFERENCE.Version..ff
RNAseq..REFERENCE.featureCounts <<- REFERENCE.featureCounts..ff
RNAseq..Organism.gene_inf       <<- RNAseq..Organism.gene_inf..ff
TXT_RNAseq..Short.V_File..FF    <<- TXT_RNAseq..Short.V_File..ff
return(TXT_RNAseq..Version_File..ff)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################



#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..MATCH.table.vs.dataset= function(TABLE.INP.WW, Dataset.WW, COL_MATCH_dataset.WW= "Entrez.Gene.ID.supplied.by.NCBI.", COL_MATCH_Input.WW= "RawPro.gene", 
                                             COL.data1.MATCH.WW= "Approved.Symbol", COL.data2.MATCH.WW= c("HGNC.ID","")[1], print.Anno.WW=c(1,0)[1] ) {

### TABLE.INP.WW=TABLE.INP.NN;  Dataset.WW=getBM..NN;  COL_MATCH_dataset.WW= "ensembl_gene_id";		COL_MATCH_Input.WW= "gene.ensembl";		COL.data1.MATCH.WW= "external_gene_name";		COL.data2.MATCH.WW= "";   	print.Anno.WW=c(1,0)[1];
### TABLE.INP.WW=TABLE.INP.NN;  Dataset.WW=Gene.HGNC.database.NN;  COL_MATCH_dataset.WW= "Entrez.Gene.ID.supplied.by.NCBI.";		COL_MATCH_Input.WW= "RawPro.gene";		COL.data1.MATCH.WW= "Approved.Symbol";		COL.data2.MATCH.WW= "HGNC.ID";   	print.Anno.WW=c(1,0)[1];

### RES= FFF.RNAseq..MATCH.table.vs.dataset(TABLE.test.NEW, Database.FF, COL_MATCH_dataset.NN, COL_MATCH_Input.NN, COL.data1.MATCH.NN, COL.data2.MATCH.NN, print.Anno.NN)
### TABLE.INP.WW=TABLE.test.NEW;  Dataset.WW=Database.FF;  COL_MATCH_dataset.WW= COL_MATCH_dataset.NN;		COL_MATCH_Input.WW= COL_MATCH_Input.NN;		COL.data1.MATCH.WW= COL.data1.MATCH.NN;		COL.data2.MATCH.WW= COL.data2.MATCH.NN;   	print.Anno.WW=c(1,0)[1];

################################################################	
OUT.MATCH.WW= c()
if(nrow(TABLE.INP.WW)>0) {
	COL.new.TEST.WW= "TEST1.WW";    COL.new1.MATCH.WW= "gene_name3.WW";    if(COL.data2.MATCH.WW=="") COL.new2.MATCH.WW= "" else COL.new2.MATCH.WW= "HGNC.ID3.WW"    
	############
	ROW.ORG.WW= nrow(TABLE.INP.WW);     GENES.TO.ANNO.VEC..WW= unique(TABLE.INP.WW[,COL_MATCH_Input.WW]);  GENES.TO.ANNO.VEC..WW= GENES.TO.ANNO.VEC..WW[GENES.TO.ANNO.VEC..WW!=""]
	############
	if(length(TABLE.INP.WW[TABLE.INP.WW[,COL_MATCH_Input.WW]=="",COL_MATCH_Input.WW])>0)
	          TABLE.INP.WW[TABLE.INP.WW[,COL_MATCH_Input.WW]=="",COL_MATCH_Input.WW]= "NADA_NADA_space"
	############
	MATCH1.WW= match(TABLE.INP.WW[,COL_MATCH_Input.WW], Dataset.WW[,COL_MATCH_dataset.WW]);
	############
	if(COL.new2.MATCH.WW!="" & COL.data2.MATCH.WW!="") {
	TABLE.INP.WW[,COL.new2.MATCH.WW]="";  TABLE.INP.WW[,COL.new2.MATCH.WW]= as.character(Dataset.WW[MATCH1.WW,COL.data2.MATCH.WW  ]);  TABLE.INP.WW[is.na(TABLE.INP.WW[,COL.new2.MATCH.WW]),COL.new2.MATCH.WW]="" }
	TABLE.INP.WW[,COL.new1.MATCH.WW]="";  TABLE.INP.WW[,COL.new1.MATCH.WW]= as.character(Dataset.WW[MATCH1.WW,COL.data1.MATCH.WW  ]);  TABLE.INP.WW[is.na(TABLE.INP.WW[,COL.new1.MATCH.WW]),COL.new1.MATCH.WW]=""
	TABLE.INP.WW[,COL.new.TEST.WW  ]="";  TABLE.INP.WW[,COL.new.TEST.WW  ]= as.character(Dataset.WW[MATCH1.WW,COL_MATCH_dataset.WW]);  TABLE.INP.WW[is.na(TABLE.INP.WW[,COL.new.TEST.WW  ]),COL.new.TEST.WW  ]=""
	############
	if(length(TABLE.INP.WW[TABLE.INP.WW[,COL_MATCH_Input.WW]=="NADA_NADA_space",COL_MATCH_Input.WW])>0)
	          TABLE.INP.WW[TABLE.INP.WW[,COL_MATCH_Input.WW]=="NADA_NADA_space",COL_MATCH_Input.WW]= ""
	########################
	Perfect_match.WW = TABLE.INP.WW[TABLE.INP.WW[,COL.new.TEST.WW]==TABLE.INP.WW[,COL_MATCH_Input.WW] & TABLE.INP.WW[,COL.new.TEST.WW]!="",];
	ERROR_no_match.WW= TABLE.INP.WW[TABLE.INP.WW[,COL.new.TEST.WW]!=TABLE.INP.WW[,COL_MATCH_Input.WW],];
	ERROR_Gene.Uni.WW  = unique(ERROR_no_match.WW[,COL_MATCH_Input.WW])
	Perfect_Gene.Uni.WW= unique(Perfect_match.WW [,COL_MATCH_Input.WW])
	####### dim(TABLE.INP.WW);   dim(Perfect_match.WW); dim(ERROR_no_match.WW);   length(ERROR_Gene.Uni.WW);  length(Perfect_Gene.Uni.WW)
	############
	if(print.Anno.WW>0){ print(paste(" genes Annotated successfully (match) -->",nrow(Perfect_match.WW),"of",nrow(TABLE.INP.WW),"                  ", date() ))  }
	############
	ERROR_SUM.WW= length(Perfect_Gene.Uni.WW)+ length(ERROR_Gene.Uni.WW) - length(GENES.TO.ANNO.VEC..WW)
	ERROR_ERROR.WW= ERROR_no_match.WW[ERROR_no_match.WW[,COL.new.TEST.WW]!="",]
	if(nrow(ERROR_ERROR.WW)>0 | ROW.ORG.WW!=nrow(TABLE.INP.WW) | ERROR_SUM.WW!=0) {
		if(ERROR_SUM.WW!=0) print(paste(" ERROR in annotation --> sum -->", ERROR_SUM.WW))
		print("");  print(paste(" ERROR in annotation --> check it --> errors=", nrow(ERROR_ERROR.WW),"   error new rows=", ROW.ORG.WW )); if(nrow(ERROR_ERROR.WW)>0) print(ERROR_ERROR.WW);  print("");  stop("kaOs is stopping")
	}
	############
	COL.OUT.WW= c(COL.new1.MATCH.WW, COL.new2.MATCH.WW);	COL.OUT.WW= COL.OUT.WW[COL.OUT.WW!=""]
	OUT.MATCH.WW= TABLE.INP.WW[,COL.OUT.WW]
}
#########################################	
return(OUT.MATCH.WW)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..Table..Annotation= function(TABLE.ALL..AA, Annotation..AA=Annotation.ORG, Column.Match.ORG..AA= "RawPro.gene", Column.Match.Anno..AA= "RawPro.gene", Run..all.extras..AA= c(1,2)[1], Extra.columns..AA=c(COLUMNS.Genes.Anno,"gene.Synonyms"), print.Anno..AA=1) {

### TABLE.ALL..AA=TABLE.test.SAVE; Annotation..AA=Annotation.ORG; Column.Match.ORG..AA= "RawPro.gene"; Column.Match.Anno..AA= "RawPro.gene"; Extra.columns..AA=c("gene.Raw","gene.Ens","gene.HGNC","gene.Synonyms"); print.Anno..AA=1
### TABLE.ALL..AA=Counts;  Run..all.extras..AA= c(1,2)[2];    Annotation..AA=Annotation.ORG; Column.Match.ORG..AA= "RawPro.gene"; Column.Match.Anno..AA= "RawPro.gene"; Extra.columns..AA=c("gene.Raw","gene.Ens","gene.HGNC","gene.Synonyms"); print.Anno..AA=1

##########################################################
if(length(TABLE.ALL..AA)>0 & length(Annotation..AA)>0) {
	#########
	COl.Annotation..AA= colnames(Annotation..AA); 
	NN.Raw..AA= grep("##Raw",COl.Annotation..AA,fixed=TRUE);  if(length(NN.Raw..AA)!=1) stop(" FILE with no Raw Annotation ---> col.serach= ##Raw;   --> check it")
	NN.End..AA= grep("##End",COl.Annotation..AA,fixed=TRUE);  if(length(NN.End..AA)!=1) stop(" FILE with no End Annotation ---> col.serach= ##End;   --> check it")
	#########
	COl.Annotation.TABLE..AA= unique(Extra.columns..AA);
	if(Run..all.extras..AA==1) COl.Annotation.TABLE..AA= unique(c(Extra.columns..AA,COl.Annotation..AA[c(NN.Raw..AA:NN.End..AA)]));
	######### 
	COl.Annotation.TABLE..AA= COl.Annotation.TABLE..AA[COl.Annotation.TABLE..AA!=Column.Match.ORG..AA]
	#########
	COL.NOT.FIND= c();   for(Col..AA in COl.Annotation.TABLE..AA) if(length(COl.Annotation..AA[COl.Annotation..AA==Col..AA])<=0){ COL.NOT.FIND= c(COL.NOT.FIND, Col..AA) }
	if(length(COL.NOT.FIND)>0){
		print(paste(" Warning --. columns not find in original Annotation  -->", length(COL.NOT.FIND),"      -->", paste(COL.NOT.FIND, collapse="; ")))
		Annotation..AA[,COL.NOT.FIND]= NA
	}
	###########################
	Annotation..AA[(nrow(Annotation..AA)+1),]="###";    Annotation..AA[,"TESTXXX"]= Annotation..AA[,Column.Match.Anno..AA]
	#########
	RRR..AA = match(TABLE.ALL..AA[,Column.Match.ORG..AA], Annotation..AA[,Column.Match.Anno..AA]);    ## RRR..AA[is.na(RRR..AA)]
	if(length(RRR..AA)>0) {
		##################
		TABLE.ALL..AA[,COl.Annotation.TABLE..AA]= Annotation..AA[RRR..AA,COl.Annotation.TABLE..AA]; 
		#########  
		ERROR2= cbind(TABLE.ALL..AA[,c(Column.Match.ORG..AA,COl.Annotation.TABLE..AA[1])], Annotation..AA[RRR..AA,c("TESTXXX",COl.Annotation.TABLE..AA[2])]);   ERROR2= ERROR2[ERROR2[,Column.Match.ORG..AA]!="###",];
		#########
		ERROR2[,"ERROR"]=1;   ERROR2[ERROR2[,Column.Match.ORG..AA]==ERROR2[,"TESTXXX"],"ERROR"]=0;   ERROR2= ERROR2[ERROR2[,"ERROR"]==1,]
		if(nrow(ERROR2)!=0) stop(paste("ERROR ERROR --> main error -->  max(abs(TABLE.ALL..AA - Annotation.ORG[,TESTXXX])!=0  --> ",nrow(ERROR2) )) else if(print.Anno..AA>0) print(paste(" Perfect --> Raw annotation -->",nrow(TABLE.ALL..AA) ))
		### 
		### stop();  dim(Annotation..AA);  dim(TABLE.ALL..AA);  length(RRR..AA);  max(RRR..AA);  min(RRR..AA);  RRR..AA[is.na(RRR..AA)];  TABLE.ALL..AA[is.na(RRR..AA),];  TABLE.ALL.Lima[is.na(RRR..AA),];  dim(TABLE.ALL.Lima)
		##################
}	};   ## head(TABLE.ALL..AA)
##################
return(TABLE.ALL..AA)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


# --------------------------------------------------------------------------------------------------
########################################################################################### 
#### FFFX_Remove_DIR..Unlink ==> Remove direcotories   --> copy from Functions__UNIX.r
###########################################################################################
###########################################################################################
FFFX_Remove_DIR..Unlink= function(DIR_TO_remove, print.results=1, ignore.file.exists=0) {

## print.results =1;  DIR_TO_remove= "David.Paterson"
## FFFX_Remove_DIR..Unlink(DIR_TO_remove, print.results)

if(file.exists(DIR_TO_remove) | ignore.file.exists==1) {
	if(file.exists(DIR_TO_remove)) Exist.yes=1 else Exist.yes=0
	CMD.rm.dir= paste("rm -rf ", DIR_TO_remove, sep="")
	p= system(CMD.rm.dir, intern=T)
	if(print.results>0) {
		print(CMD.rm.dir) 
		if(Exist.yes>0) { print(paste(" Perfect -- Remove DIR =", DIR_TO_remove )) }
	}
} else {
	if(print.results>0){ print(paste("Warning ==> Directory do not exist -->", DIR_TO_remove)) }
};  if(print.results>0) print("")	

#####################
return("Perfect remove dir")
}
###########################################################################################  
###########################################################################################
###########################################################################################


	