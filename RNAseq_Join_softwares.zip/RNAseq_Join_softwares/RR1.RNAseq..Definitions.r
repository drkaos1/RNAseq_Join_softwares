
###########################################################################################################################################
###########################################################################################################################################  {
if(!exists("RNAseq..Project_num.Ver")) RNAseq..Project_num.Ver="AA";     if(!exists("print..RNAseq_results" )) print..RNAseq_results= c(1,0)[2]  
#########
if(!exists("Project.RNA..run"         )){ print(""); print(paste("ERROR --> Project.RNA..run           -->  not available" ));  print("");  stop("kaOs is stopping")  }
if(!exists("DIR_Annotations.Source.hg")){ print(""); print(paste("ERROR --> DIR_Annotations.Source.hg  -->  not available" ));  print("");  stop("kaOs is stopping")  }
if(!exists("RUN..Trimmomatic..ONE"    )){ print(""); print(paste("ERROR --> RUN..Trimmomatic..ONE      -->  not available" ));  print("");  stop("kaOs is stopping")  }
#########
RNAseq..Result.Version= c(1,2,3,4,5,6)[1];      RNAseq..SEQ.ver.run= "1";      RNAseq..RSEM.ver.run= "1";      RNAseq..Othe.ver.run= "1";      rm.files.Definitions=1

################################################################################################################  Main Directories
################################################################################################################  
if(!exists("Running_Step_0_BSUB_Process")) Running_Step_0_BSUB_Process=0
if(Running_Step_0_BSUB_Process==0){
	print(paste("#######################################################################################################",Project.RNA..run));
	print(paste("00) Setup directories and files:",sep=""))
}

################################################# 
DIR_RNAseq..Annotations= MAIN.MAIN.DIR...Inp.DataBases.ALL
DIR_RNAseq..Annot.Genes= paste(MAIN.MAIN.DIR...Inp.DataBases.ALL, "YY..RNAseq/_Gene.info/",sep="");
DIR_RNAseq..ORG.Inputs = MAIN.MAIN.DIR...INPUTS..RNseq
DIR_RNAseq..Results    = MAIN.MAIN.DIR...OUTPUT..RNseq 
####### Versions files 
RNAseq..Version..Gene.info= c("08-4-18", "11-4-18","14-Sep-20","20-July-21","21-Oct-23")[5];      #### you need to Change file as well (0_Function.RNAseq..Main.r;  FFF.RNAseq..Annotaion.gene.HGNC.database)

################################################################################################################ Mian inputs
################################################################################################################  

################################################# p.value values (gene differencial expresion matrix)
RNAseq..QC..Min.Sum.Counts..Sample  = c(200000)[1];					## sum(Counts) < Value               (QC test to see bad samples)
RNAseq..QC..Min.Samples..per_test   = c( 2, 5 )[1];					## MIn number of samples with Counts (QC test to see bad samples)		
RNAseq..Models..MAX.genes..per_test = c(1000,10000,100000)[3];		## maximum number of genes for each test
#########
RNAseq..Models..theta.DESeq         = c(0.4, 0.25)[2]				## quantile(ROW.SUMS.cds.FULL.DD, probs=theta..DESeq) filter counts with less than 40% reads
RNAseq..Heatplot..COLORS            = c(0,1)[1]						## plot heatplot using different palette colors
RNAseq..Heatplot..MAX.GENES         = c(10,50,100)[2]				## Max numebr of genes for heatplot
RNAseq..Heatplot..MAX.GENES.TXT     = c(10,15,20,40)[2]				## Max numebr of genes to write names in plots
RNAseq..running.DESeq               = c(1,0)[1]
#########
RNAseq..Heatmap..PLOT_GENES..VEC= c("Auto")[1];						## Plot heatplot specula genes (use Gene columns) 
#########
RNAseq..Plooting..Normal.Cases  = c(1,0)[1];						## Plot all cases, all plots
#########
RNAseq..Plooting..Special.Cases = c("barplot","boxplot","heatmap3","plotMDS","Volcano.Join","Volcano.Gene","heatmap2","Path.Analysis2");   				## Plot special cases for special projects
RNAseq..Plooting..Special.Cases = c("barplot","boxplot","heatmap4","plotMDS","Volcano.Join","Volcano.Gene","heatmap5","Path.Analysis2");   				## Plot special cases for special projects
#########
RNAseq..VOLCANO..COLOR.special..MAIN= rbind(c("Special.Genes","RED","BLUE"));    colnames(RNAseq..VOLCANO..COLOR.special..MAIN)= c("Special.Genes","RED","BLUE");  RNAseq..VOLCANO..COLOR.special..MAIN= RNAseq..VOLCANO..COLOR.special..MAIN[0,];  ## example Volcano plot Ye (2 colors)   
RNAseq..VOLCANO..Black_points.To.Red= c(0,1)[1]						## points black (FDR=orange,red, main points=navy)
#########
RNAseq..USE.Reverse.Targets.Model= c(0,1)[1]						## Invert the order in Aff vs control (Fold Change ratio)
#########
RNAseq..DESeq2..FORCE.Run.Filters..Heatplot= c(0,1)[1]				## DESeq2..FORCE.Run.Filters..Heatplot  (Heatplot4 and Heatplot5)

########################### 
RNAseq..Pathanalysis..PLOT.MAIN   = c("kegga","goana","both")[1:3]  ## Path.Analysis2
RNAseq..Pathanalysis..PLOT.Special= c("kegga","goana","both")[1:2]  ## Path.Analysis
RNAseq..Pathanalysis..Min.Pvalue = c(-1, 0.05, 0.01, 0.0001 )[2]
RNAseq..Pathanalysis..MAX.Ngenes = c(-1,  100,  150,    200 )[4]
RNAseq..Pathanalysis..MAX.NPaths = c(-1,   50,  100,    200 )[2]
#########
RNAseq..Path.saving..MAX.Ngenes  = c(-1, 200, 5000, 1000    )[1] 
RNAseq..Path.saving..MIN.Ngenes  = c(-1,   1,    2,    3    )[4]
#####
RNAseq..Pathanalysis..MultiTest.Plot= c(1e-03, 1e-05)
RNAseq..Path..DONT_STOP_ERROR_SUM..Test.VEC= c()
#####
RNAseq..Pathanalysis..ADD.Gene.list= c(0,1,2,3)[1]					## 0=none; 1=gene.list;  2:Patl.list;  3:both

################################################# general                  
DIR_Annotations.Organism  = c("Homo_sapiens","Mus_musculus","Rattus_norvegicus")[1];       FILE_RNAseq..S1..fastq.Bam_files_List= "__FASTQ_list.txt";        
DIR_Annotations.Algoritm  = c("Rsubread","TopHat","_FIRST_kaos")[1];       FILE_RNAseq..FILE.Counts.External    = "no_file";    	RNAseq..S1..Remove_FASTQ.BAM_FILES = c()  			                            
DIR_RNAseq..OTHERS.RSEM.files= "No_FILES";                                 FILE_RNAseq..RSEM.external_to_compare= "no_file";    	ORG.fastq.bam.DIR..VEC= "ERROR";   		 

################################################# step1 
RNAseq..REFERENCE.featureCount..BAM.files= c("ERROR","hg19","hg38")[1];		## if we use bam files from company, we need to specify the hg reference 
#####
DIR_RNAseq..from.FASTq.or.BAM.files      = c(1,2)[1]
#####
RUN.align.FASTQ..1.2.fastq= c(0,1)[1]
RUN.align.FASTQ..1.2.fastq...fastq.gz.VEC= c("R1_001.fastq.gz","R2_001.fastq.gz")[0]

##########
RNASeq..Trimmomatic.ADAPTERS= paste(MAIN.MAIN.DIR...Programs.ALL, "RNAseq/Trimmomatic/Version_0.39/Trimmomatic-0.39/adapters/" ,sep="")
RNAseq..trimmomatic..fa.gz..TXT   = ".fastq.gz"
RNAseq..trimmomatic..ILLUMINA.TYPE= c("TruSeq2","TruSeq3")[1]

################################################# step2 (COLUMN.CVS.FIle columns)
TXT_RNAseq..COLUMN.Samples.Unique= "Sample.Identifier";     	TXT_RNAseq..COLUMN.Samples.ID= "Patient_number";
#########
TXT_RNAseq..COLUMN.to_plot..VEC  = c("Patient_number","Patient_number.G1","Patient_number.G2","Patient_number.G3","Tissue.Column","Concentration")
#########
RNAseq.Step2..RM.TXT.BAM.files= c("_TRIM.gz",".Dir1.bam",".Dir2.bam")[0]

################################################# step3
RNAseq..Fastq.Gene.ID.Version= "Gene.ID";    	RNAseq..RSEM.Gene.ID.Version= "ensembl";      	RNAseq..Other.Gene.ID.Version = "ensembl";		RNAseq..Exception..Project..libType=0;			MAX.FDR..Res.GO.Extras= c(0.1, 0.5, 1)[0]
RNAseq..test_run..VEC = 1;           		 	RNAseq..TXT.JOIN.Samples_Ratio= "/";			RNAseq..test_kaOs..SAVE = c(7:14);				RNAseq..Volcano.Gene..ylim.MAX= c(-1,10)[1];    RNAseq..Volcano.Special.genes..ylim.MAX= c(-1,10)[1]
RNAseq..MAX.characters.saving.CSV = 32000;		RNAseq..Special.Genes..PI= c();   				RNAseq..Special.Genes..PI..Column.Name= c();	RNAseq..Special.PathAnalalys..Terms.Name= c();	RNAseq..Special.PathAnalalys..Terms.IDs = c()
RNAseq..Special.Genes..File.Name=c();			RNAseq..Special.Genes..Column.Name=c();			RNAseq..Special.Genes..List.Names =c();			RNAseq..Special.Pathways..List =c();			RNAseq..Special.PathAnalalys..Tittle= c() 			
#########
RNAseq..Columns.Names..Genes.Excel= c("gene.Raw","gene.Ens","gene.HGNC","gene.Synonyms","external_gene_name","Symbol_authority","Symbol")		## add "" to gene column to avoit dates in excel

################################################# step4   
RNAseq..Models.Alg..Unique.VEC = c("Lima","edgeR","DESeq")
RNAseq..Models.Alg..Lima.VEC   = c("Lima1","Lima2","Lima3-Voom","Lima4-Voom")
RNAseq..Models.Alg..edgeR.VEC  = c("edgeR.ltr1","edgeR.qlf1","edgeR.ltr2","edgeR.qlf2")   
RNAseq..Models.Alg..DESeq.VEC  = c("DESeq1","DESeq1b","DESeq2","DESeq2b"); 
######
RNAseq..Models.Alg..All.Algoritms= unique(c(RNAseq..Models.Alg..Lima.VEC        , RNAseq..Models.Alg..edgeR.VEC        , RNAseq..Models.Alg..DESeq.VEC          )) 
RNAseq..Models.Alg..Max.Min.Mean = unique(c(RNAseq..Models.Alg..Lima.VEC[c(3  )], RNAseq..Models.Alg..edgeR.VEC[c(3  )], RNAseq..Models.Alg..DESeq.VEC[c(  3  )])) 
RNAseq..Models.Alg..Save.Pipe    = unique(c(RNAseq..Models.Alg..Lima.VEC[c(3:4)], RNAseq..Models.Alg..edgeR.VEC[c(3:4)], RNAseq..Models.Alg..DESeq.VEC[c(1,3:4)]))
RNAseq..Models.Alg..Save.Pipe    = unique(c(RNAseq..Models.Alg..Lima.VEC[c(3  )], RNAseq..Models.Alg..edgeR.VEC[c(3  )], RNAseq..Models.Alg..DESeq.VEC[c(  3  )]))
######
RNAseq..Models..NOT_RUN= c("Lima","edgeR","DESeq")[0];      RNAseq..DESeq.METHOD..ONLY.Test.VEC = c("test1")[0];     RNAseq..DESeq.METHOD..ONLY.USE.Method= c("Default","pooled-CR","NOT_RUN_DESeq")[2];
######
METHOD..DESeq...estimateSizeFactors.Project= c("Default","pooled-CR","pooled")[1];   				### use "pooled-CR" when the data mark error in "estimateDispersions";  "pooled"=default
METHOD..DESeq2..mean.dispersion.Project    = c("Default","local"    ,"mean"  )[1];   				### use "pooled-CR" when the data mark error in "estimateDispersions";  "pooled"=default
######
RNAseq..EMERGENCY..RUn.Pathways..Pipe= c(1,0)[1]

###########################################################################################################################################
########################################################################################################################################### 

if(Project.RNA..run=="Example..P1"){ 
	######
	TXT_RNAseq..PI.name   = "_Example_Project";		Project.RNA..Pipe.ID= "P1"
	######
	ORG.fastq.bam.DIR..VEC= "2024_Oct_23/";		FILE.Samples_Info= "_RNAseq_Samples_Info..Example.csv"
	######
	RUN.align.FASTQ..1.2.fastq= c(0,1)[2];       RUN.align.FASTQ..1.2.fastq...fastq.gz.VEC= c("_R1_001.fastq.gz","_R2_001.fastq.gz")
	######
	RNAseq..test_run..VEC = c(1, "1R")[1]
	######
	DIR_Annotations.Organism= c("Homo_sapiens","Mus_musculus")[2]     				
}


###########################################################################################################################################
########################################################################################################################################### 
############
if(Running_Step_0_BSUB_Process==0 | Running_Step_0_BSUB_Process==2) source(paste(MAIN.MAIN.DIR...Pipeline..RNseq,"RR0.RNAseq..Directories.r",sep=""))
############
FILE_RNAseq..samples.with.bad.QC.Rdata= "RNA.seq..samples.with.bad.QC.Rdata";   if(RUN..Trimmomatic..ONE=="Yes") FILE_RNAseq..samples.with.bad.QC.Rdata= "RNA.seq..samples.with.bad.QC..Trim.Rdata"
############
if(length(RNAseq..test_run..VEC)>0) RNAseq..test_run..VEC= RNAseq..test_run..VEC[order(RNAseq..test_run..VEC)]
