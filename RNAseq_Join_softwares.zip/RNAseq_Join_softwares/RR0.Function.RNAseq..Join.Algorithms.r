
#########################################################################################################################################################                    
#########################################################################################################################################################
######################################################################################################################################################### 
FFF.RNAseq..Plotting_Models= function(Counts.PLOT, Targets.PLOT, design.PLOT, TABLEs.ALL.PLOT, TABLE.ALL.JOIN.PLOT, TABLE.TOGO.PLOT, CASE.Model.VEC.PLOT=c("Lima1","Lima2","edgeR1","edgeR2","DESeq0","DESeq1" ,"DESeq2b"), Use.Col.Max.Mean.PLOT, 
	                                  Models..VOOM.PLOT= RNAseq..Models..VOOM, DIR_Annotations.Organism.PLOT= DIR_Annotations.Organism, Plot.ONLY.Cases.PLOT=c(), Special.Genes.list.PLOT= RNAseq..Data.Special.Genes.list ) {

### Models..VOOM.PLOT= RNAseq..Models..VOOM;  DIR_Annotations.Organism.PLOT= DIR_Annotations.Organism;  Plot.ONLY.Cases.PLOT=c("barcodeplot")[0];  Special.Genes.list.PLOT= RNAseq..Data.Special.Genes.list;    Use.Col.Max.Mean.PLOT= Use.Col.Max.Mean.plot
### Counts.PLOT=Counts.gene.PLOT; Targets.PLOT=Targets.Model; design.PLOT= design.Model;  TABLEs.ALL.PLOT=TABLEs.ALL.ALL;  TABLE.ALL.JOIN.PLOT=TABLE.ALL.JOIN.plot; TABLE.TOGO.PLOT=TABLE.SAVE.TOGO;  CASE.Model.VEC.PLOT=CASE.Model.VEC;

###### FFF.RNAseq..Plotting_Models(Counts.gene.PLOT, Targets.Model, design.Model, TABLEs.ALL.ALL, TABLE.ALL.JOIN.plot, TABLE.SAVE.TOGO.toplot, CASE.Model.VEC, Use.Col.Max.Mean.plot, RNAseq..Models..VOOM, DIR_Annotations.Organism, c(), RNAseq..Data.Special.Genes.list)

########################################################################   
logFC.PLOT  = c(RNAseq..Figure..MIN.log2.fold, 1.2)[1];    	FDR1.value.PLOT= c(RNAseq..Figure..MIN.Fil1.FDR,0.05)[1];	    ####  values for pavlues to plot black, orange and red points  (volcano);	
P.value.PLOT= c(RNAseq..Figure..MIN.p.value  ,0.05)[1]; 	FDR2.value.PLOT= c(RNAseq..Figure..MIN.Fil2.FDR,0.10)[1];   
 
######################################################################## 
Targets.PLOT[,"COLOUS"]= "blue";  Targets.PLOT[Targets.PLOT[,"Test"]==Targets.PLOT[,"Test"][1],"COLOUS"]= "red"   
#########
COLLORS.MDS.PLOT = Targets.PLOT[,"COLOUS"];     COLLORS.MDS.PLOT2= unique(Targets.PLOT[,"COLOUS"]);       COLLORS.legend.PLOT= unique(Targets.PLOT[,"Test"]);   
###########################
COL.SAMPELS.Lib..PLOT= paste(Targets.PLOT[,"Patient_number"]," -", Targets.PLOT[,"Test"],sep="");             COL.Small.Lib..PLOT= paste(Targets.PLOT[,"Patient_number"],sep="");
if(length(unique(Targets.PLOT[,"libType"]))>1) {
	COL.SAMPELS.Lib..PLOT= paste(Targets.PLOT[,"Patient_number"]," -", Targets.PLOT[,"Test"]," -", Targets.PLOT[,"libType"],sep="");
	COL.Small.Lib..PLOT  = paste(Targets.PLOT[,"Patient_number"]," -", Targets.PLOT[,"libType"],sep="");
}
########################################################################   
COl.SAMPLES.Original.PLOT= colnames(Counts.PLOT);   
COl.SAMPLES.Original.PLOT= COl.SAMPLES.Original.PLOT[COl.SAMPLES.Original.PLOT!="gene.PLOT"];   COl.SAMPLES.Original.PLOT= COl.SAMPLES.Original.PLOT[COl.SAMPLES.Original.PLOT!="RawPro.gene"]
#######
test_run.pp.PLOT= unique(TABLEs.ALL.PLOT[,"Test.XX"]);  if(length(test_run.pp.PLOT)!=1) stop(paste("MAIn ERROR.. plotting more test than one --> length(test_run)!=1 -->",length(test_run.pp.PLOT) ))
		
#################################################################################### 
TXT.run.VennDiagram.GO= "VennDiagram.GO";  if(exists("PLOT.VennDiagram..GO.KEGG")) if(PLOT.VennDiagram..GO.KEGG==0) TXT.run.VennDiagram.GO= c()
Plot.MODEL.MAIN..VEC= c("barplot","boxplot","plotMD","heatmap3","plotMDS","plotBCV","plotQLDisp2","plotQLDisp","plotMD_res","plot_qqt","Volcano","VennDiagram","Volcano.Join","Volcano.Gene","heatmap2",TXT.run.VennDiagram.GO,"Path.Analysis2","barcodeplot.Gene","barcodeplot","heatmap1") ## "VennDiagram.GO","Volcano2"
Plot.MODEL.MAIN..VEC= c("barplot","boxplot",         "heatmap4","plotMDS","plotBCV",              "plotQLDisp","plotMD_res",           "Volcano","VennDiagram","Volcano.Join","Volcano.Gene","heatmap5",                       "Path.Analysis2","barcodeplot.Gene","barcodeplot") ## "VennDiagram.GO","Volcano2"
#######
if(length(Plot.ONLY.Cases.PLOT)>0) Plot.MODEL.USE..VEC= Plot.ONLY.Cases.PLOT else Plot.MODEL.USE..VEC= Plot.MODEL.MAIN..VEC
#######
for(CASE.PLOT in Plot.MODEL.USE..VEC){  ## CASE.PLOT= c("Volcano.Gene","VennDiagram","barcodeplot", "barcodeplot.Gene","VennDiagram.GO")[3]
	############
	print(paste(" Plotting -->", CASE.PLOT))
	############
	MAX..GENES.PLOT= 30;    MAX..GENES.TXT.PLOT= c(10,15,20,40,100)[3]
	############
	if(CASE.PLOT=="barplot"         )  par(mfrow=c(1,1))
	if(CASE.PLOT=="boxplot"         )  par(mfrow=c(1,1))
	if(CASE.PLOT=="plotMD"          )  par(mfrow=c(2,1))
	if(CASE.PLOT=="plotMDS"         )  par(mfrow=c(1,1))
	if(CASE.PLOT=="plotBCV"         )  par(mfrow=c(3,2))
	if(CASE.PLOT=="plotQLDisp2"     )  par(mfrow=c(3,2))
    if(CASE.PLOT=="plotQLDisp"      )  par(mfrow=c(3,2))
  ##if(CASE.PLOT=="plotMD_res"      )  par(mfrow=c(2,2))
    if(CASE.PLOT=="plot_qqt"        )  par(mfrow=c(2,2))
	if(CASE.PLOT=="Volcano"         ){ if(length(CASE.Model.VEC.PLOT)<9) par(mfrow=c(2,2)) else par(mfrow=c(3,3))  } 
	if(CASE.PLOT=="Volcano.Join"    ){ par(mfrow=c(1,1));   MAX..GENES.TXT.PLOT= 20   }
	if(CASE.PLOT=="Volcano.Gene"    ){ par(mfrow=c(1,1));   MAX..GENES.TXT.PLOT= 50   }
	if(CASE.PLOT=="VennDiagram"     )  par(mfrow=c(2,2))
	if(CASE.PLOT=="VennDiagram.GO"  )  par(mfrow=c(3,3))
	if(CASE.PLOT=="Path.Analysis1"  )  par(mfrow=c(1,1))
	if(CASE.PLOT=="Path.Analysis2"  )  par(mfrow=c(1,1))
	if(CASE.PLOT=="barcodeplot.Gene")  par(mfrow=c(3,1)); 
	if(CASE.PLOT=="barcodeplot"     )  par(mfrow=c(3,1));  
	if(CASE.PLOT=="Volcano2"        )  par(mfrow=c(2,2))
	if(CASE.PLOT=="heatmap1"        )  par(mfrow=c(1,1))
	if(CASE.PLOT=="heatmap2"        ){ par(mfrow=c(1,1));   MAX..GENES.PLOT= RNAseq..Heatplot..MAX.GENES     }
	if(CASE.PLOT=="heatmap3"        ){ par(mfrow=c(1,1));   MAX..GENES.PLOT= RNAseq..Heatplot..MAX.GENES     }
	if(CASE.PLOT=="heatmap4"        ){ par(mfrow=c(1,1));   MAX..GENES.PLOT= RNAseq..Heatplot..MAX.GENES     }
	if(CASE.PLOT=="heatmap5"        ){ par(mfrow=c(1,1));   MAX..GENES.PLOT= RNAseq..Heatplot..MAX.GENES     }
	
for(CASE.Model in c("Raw data","Join.Alg",CASE.Model.VEC.PLOT)) {    ## yes { CASE.PLOT=c("barplot","heatmap1","plotMD_res","Volcano","barcodeplot","VennDiagram")[5];   CASE.Model=c("Raw data","Join.Alg","edgeR.ltr2","edgeR.qlf1","edgeR.ltr1","edgeR.qlf2","DESeq1" ,"Lima1")[1];
	############
	RUn.Join.Alg.plots.pp= 0;   COL.logFC="logFC";  COL.pvalue= "PValue";    COL.FDR="FDR";    #print(paste("        -->", CASE.Model))
	if(CASE.Model=="Join.Alg"){
		RUn.Join.Alg.plots.pp= 1;   COL.logFC= paste("logFC" ,Use.Col.Max.Mean.PLOT,sep="");   COL.pvalue= paste("PValue",Use.Col.Max.Mean.PLOT,sep="");      COL.FDR= paste("FDR",Use.Col.Max.Mean.PLOT,sep="")
	}

	############ 	 
	RES.PLOT= c();  FIT.PLOT= c();  dge_PLOT=dge_MAIN[0,];   
	############
	if(CASE.Model=="Raw data"                               ){ dge_PLOT=dge_MAIN;     		FIT.PLOT= c();       }
	if(CASE.Model=="Lima1"       | CASE.Model=="Lima2"      ){ dge_PLOT=dge_Lima;     		FIT.PLOT= fit_Lima1;        if(CASE.Model=="Lima2"     )  FIT.PLOT= fit_Lima2;          }
	if(CASE.Model=="Lima3-Voom"  | CASE.Model=="Lima4-Voom" ){ dge_PLOT=dge_Lima_Voom;     	FIT.PLOT= fit_Lima_Voom1;   if(CASE.Model=="Lima4-Voom")  FIT.PLOT= fit_Lima_Voom2;     }
	if(CASE.Model=="edgeR.ltr1"  | CASE.Model=="edgeR.qlf1" ){ dge_PLOT=dge_edgeR;    		FIT.PLOT= fit_edgeR_lrt;    RES.PLOT=res_edgeR_lrt;     if(CASE.Model=="edgeR.qlf1"){ FIT.PLOT= fit_edgeR_qlf;   RES.PLOT=res_edgeR_qlf    }}
	if(CASE.Model=="edgeR.ltr2"  | CASE.Model=="edgeR.qlf2" ){ dge_PLOT=dge_edgeR_B;  		FIT.PLOT= fit_edgeR_B_lrt;  RES.PLOT=res_edgeR_B_lrt;   if(CASE.Model=="edgeR.qlf2"){ FIT.PLOT= fit_edgeR_B_qlf; RES.PLOT=res_edgeR_B_qlf  }}
	if(CASE.Model=="DESeq1"      | CASE.Model=="DESeq1b"    ){ dge_PLOT=dge_DESeq1;   	 	FIT.PLOT= c();   if(CASE.Model=="DESeq1b") { dge_PLOT=dge_DESeq1b;   FIT.PLOT= fit_DESeq1b }}
	if(CASE.Model=="DESeq2"      | CASE.Model=="DESeq2b"    ){ dge_PLOT=dge_DESeq2;   	 	FIT.PLOT= c();   if(CASE.Model=="DESeq2b") { dge_PLOT=dge_DESeq2;    FIT.PLOT= c()         }}

	######################### preparing TABLE.Plot   
	COl.Special.gene.List.pp= c()
	if(length(Special.Genes.list.PLOT)>0) if(CASE.Model=="Join.Alg" | CASE.Model=="heatmap2" | CASE.Model=="heatmap3" | 88==88){ COl.Special.gene.List.pp= colnames(Special.Genes.list.PLOT); COl.Special.gene.List.pp= COl.Special.gene.List.pp[COl.Special.gene.List.pp!="ROWS"] }
	#########################
	DESeq2..Pvalue.NA.Values.x= c(0.5, 0.05, 0)[1]
	TABLEs.ALL.PLOT[TABLEs.ALL.PLOT[,"Model"]=="DESeq2"  & is.na(TABLEs.ALL.PLOT[,"PValue"]),"PValue"]= DESeq2..Pvalue.NA.Values.x;  TABLEs.ALL.PLOT[TABLEs.ALL.PLOT[,"Model"]=="DESeq2"  & is.na(TABLEs.ALL.PLOT[,"FDR"]),"FDR"]= DESeq2..Pvalue.NA.Values.x
	TABLEs.ALL.PLOT[TABLEs.ALL.PLOT[,"Model"]=="DESeq2b" & is.na(TABLEs.ALL.PLOT[,"PValue"]),"PValue"]= DESeq2..Pvalue.NA.Values.x;  TABLEs.ALL.PLOT[TABLEs.ALL.PLOT[,"Model"]=="DESeq2b" & is.na(TABLEs.ALL.PLOT[,"FDR"]),"FDR"]= DESeq2..Pvalue.NA.Values.x
	#########################
	TABLE.Plot= TABLEs.ALL.PLOT[0,]
	if(RUn.Join.Alg.plots.pp==0) if(nrow(TABLEs.ALL.PLOT    )>0) TABLE.Plot= TABLEs.ALL.PLOT    [TABLEs.ALL.PLOT    [,"Model"]==CASE.Model,c(COL.logFC,COL.pvalue,COL.FDR,"RawPro.gene","Raw.geneID","gene.PLOT","type.gene.PLOT", COl.Special.gene.List.pp)];  ### "logCPM","LR"
	if(RUn.Join.Alg.plots.pp==1) if(nrow(TABLE.ALL.JOIN.PLOT)>0) TABLE.Plot= TABLE.ALL.JOIN.PLOT[TABLE.ALL.JOIN.PLOT[,"Model"]=="Join.Alg",c(COL.logFC,COL.pvalue,COL.FDR,"RawPro.gene","Raw.geneID","gene.PLOT","type.gene.PLOT", COl.Special.gene.List.pp)]
	######
	#print("######");  print(colnames(TABLE.Plot));  print("jajaj");  print(CASE.Model)
	#########################
	if(nrow(TABLE.Plot)>0) {
		#########################  
		pvalue.MIN.INF= min(as.numeric(TABLE.Plot[TABLE.Plot[,COL.pvalue]!=Inf & TABLE.Plot[,COL.pvalue]!=-Inf,COL.pvalue]));		logFC.MAX.INF= max(as.numeric(TABLE.Plot[TABLE.Plot[,COL.logFC]!=Inf & TABLE.Plot[,COL.logFC]!=-Inf,COL.logFC]))
		#######
		TABLE.Plot[TABLE.Plot[,COL.pvalue]==Inf,COL.pvalue]=pvalue.MIN.INF;  TABLE.Plot[TABLE.Plot[,COL.FDR]==Inf,COL.FDR]= pvalue.MIN.INF;  TABLE.Plot[TABLE.Plot[,COL.logFC]==Inf,COL.logFC]= logFC.MAX.INF;  TABLE.Plot[TABLE.Plot[,COL.logFC]==-Inf,COL.logFC]= -logFC.MAX.INF
		####### 
		TABLE.Plot[,"YES.pvalue"]= 0;   
		TABLE.Plot[as.numeric(TABLE.Plot[,COL.pvalue])<= P.value.PLOT & abs(as.numeric(TABLE.Plot[,COL.logFC]))>=logFC.PLOT,"YES.pvalue"]=1;   
		TABLE.Plot[as.numeric(TABLE.Plot[,COL.pvalue])<= P.value.PLOT & abs(as.numeric(TABLE.Plot[,COL.logFC]))>=logFC.PLOT & as.numeric(TABLE.Plot[,COL.FDR])<= FDR2.value.PLOT,"YES.pvalue"]=2 
		TABLE.Plot[as.numeric(TABLE.Plot[,COL.pvalue])<= P.value.PLOT & abs(as.numeric(TABLE.Plot[,COL.logFC]))>=logFC.PLOT & as.numeric(TABLE.Plot[,COL.FDR])<= FDR1.value.PLOT,"YES.pvalue"]=3  
		####### 
		TABLE.Plot= TABLE.Plot[order(abs(as.numeric(TABLE.Plot[,COL.logFC ])),decreasing = TRUE),];
	}
	
	######################### 
	#TABLE.Plot= TABLE7;   TABLE.Plot= TABLE8; 
	########
	CASE.Mod.U= CASE.Model;  for(SUB in c(1,2,3)) CASE.Mod.U= sub(SUB,"",CASE.Mod.U,fixed=TRUE) 
	TXT.pavlue=""; if(CASE.Model!="Raw data" & nrow(TABLE.Plot)>0) TXT.pavlue= paste( nrow(TABLE.Plot[TABLE.Plot[,"YES.pvalue"]>=1,]),"-",nrow(TABLE.Plot[TABLE.Plot[,"YES.pvalue"]>=2,]),"-",nrow(TABLE.Plot[TABLE.Plot[,"YES.pvalue"]>=3,]) )
	########
	MAIN.FIGURE.barplot     = paste("Mapped Reads = ",CASE.Model," (",nrow( dge_PLOT      ),")",sep=""); 
	MAIN.FIGURE.boxplot     = paste(    "boxplot  = ",CASE.Model," (",nrow(Counts.PLOT    ),")",sep="");
	MAIN.FIGURE.plotMD.1    = paste(  "log−ratio1 = ",CASE.Mod.U," (",nrow( dge_PLOT      ),")",sep="");  if(CASE.Model!="Raw data") MAIN.FIGURE.plotMD.1 = paste("log−ratio1 =",CASE.Mod.U) 
	MAIN.FIGURE.plotMD.2    = paste(  "log−ratio2 = ",CASE.Mod.U," (",nrow( dge_PLOT      ),")",sep="");  if(CASE.Model!="Raw data") MAIN.FIGURE.plotMD.2 = paste("log−ratio2 =",CASE.Mod.U)
	MAIN.FIGURE.plotMDS     = paste(                  CASE.Mod.U," (",nrow( dge_PLOT      ),")",sep="");  if(CASE.Model!="Raw data") MAIN.FIGURE.plotMDS  = paste(   "plotMDS =",CASE.Mod.U);  MAIN.FIGURE.plotMD.De= MAIN.FIGURE.plotMDS;  #if(length(Plot.ONLY.Cases.PLOT)>0) MAIN.FIGURE.plotMDS= c()
	MAIN.FIGURE.plotBCV     = paste(    "Raw Data = ",CASE.Model," (",nrow( dge_PLOT      ),")",sep="");  if(length(Plot.ONLY.Cases.PLOT)>0) MAIN.FIGURE.plotMDS= c()
	MAIN.FIGURE.plotBCV2    = paste(    "Raw Data = ",CASE.Model," (",nrow( dge_PLOT      ),")",sep="");   
	MAIN.FIGURE.plotQLDisp  = paste(    "Fit Data = ",CASE.Model," (",nrow( FIT.PLOT      ),")",sep=""); 
	MAIN.FIGURE.plotQLDisp2 = paste(    "Fit Data = ",CASE.Model," (",nrow( FIT.PLOT      ),")",sep=""); 
	MAIN.FIGURE.plot_qqt    = paste(         "qqt = ",CASE.Model," (",nrow( FIT.PLOT      ),")",sep=""); 
	MAIN.FIGURE.barcodeplot = paste("barcode plot = ",CASE.Model," (",nrow( dge_PLOT      ),")",sep="");   
	MAIN.FIGURE.plotMD_res  = paste(          	      CASE.Model," (",  TXT.pavlue         ,")",sep="");
	MAIN.FIGURE.VOlnano     = paste(                  CASE.Model," (",  TXT.pavlue         ,")",sep="");
	MAIN.FIGURE.VOlnano.Gene= paste(    "Special Gene List --> "," (",  TXT.pavlue         ,")",sep="");   if(length(Special.Genes.list.PLOT)<=0) MAIN.FIGURE.VOlnano.Gene= c(); if(CASE.Model!="Join.Alg") MAIN.FIGURE.VOlnano.Gene= c()
	MAIN.FIGURE.VennDiagram = paste(                  CASE.Model," (",nrow(TABLEs.ALL.PLOT),")",sep="");   if(CASE.Model!="Raw data") MAIN.FIGURE.VennDiagram = c() 
	MAIN.FIGURE.VennDia.TOGO= paste(                  CASE.Model," (",nrow(TABLEs.ALL.PLOT),")",sep="");   if(CASE.Model!="Raw data") MAIN.FIGURE.VennDia.TOGO= c()
	MAIN.FIGURE.heatmap1    = paste(   "Heatmap 1 = ",CASE.Model," (",nrow(Counts.PLOT    ),")",sep="");
	MAIN.FIGURE.heatmap2    = paste(   "Heatmap 2 = ",    ""    ," (",nrow(Counts.PLOT    ),")",sep="");
	MAIN.FIGURE.heatmap3    = paste(   "Heatmap 3 = ",    ""    ," (",nrow(Counts.PLOT    ),")",sep="");  
	MAIN.FIGURE.heatmap4    = paste(   "Heatmap 4 = ",    ""    ," (",nrow(Counts.PLOT    ),")",sep=""); 
	MAIN.FIGURE.heatmap5    = paste(   "Heatmap 5 = ",    ""    ," (",nrow(Counts.PLOT    ),")",sep="");  
	###########
	MAIN.FIGURE.heatmap2= c();  MAIN.FIGURE.heatmap3=c(); if(!(CASE.Model=="DESeq2")){ MAIN.FIGURE.heatmap4=c(); MAIN.FIGURE.heatmap5=c() };   ## if(!(CASE.Model=="DESeq1")) MAIN.FIGURE.heatmap3=c();    
	#########################
	if(!(CASE.Model=="Lima3-Voom" | CASE.Model=="Lima4-Voom")) MAIN.FIGURE.plotBCV2=c()
	if(CASE.Model=="edgeR.ltr1" | CASE.Model=="edgeR.ltr2"                                                    ){ MAIN.FIGURE.plotQLDisp=c();   }
	if(CASE.Model=="DESeq1"     | CASE.Model=="DESeq1b"                                                       ){ MAIN.FIGURE.plotQLDisp=c();  MAIN.FIGURE.plotBCV=c();  MAIN.FIGURE.barplot=c();  MAIN.FIGURE.plotMD.1=c();       MAIN.FIGURE.plotMD.2=c();  MAIN.FIGURE.plotMDS=c();  MAIN.FIGURE.plot_qqt=c()  }
	if(CASE.Model=="DESeq2"     | CASE.Model=="DESeq2b"                                                       ){ MAIN.FIGURE.plotQLDisp=c();  MAIN.FIGURE.plotBCV=c();  MAIN.FIGURE.barplot=c();  MAIN.FIGURE.plotMD.1=c();       MAIN.FIGURE.plotMD.2=c();  MAIN.FIGURE.plotMDS=c();  MAIN.FIGURE.plot_qqt=c()  }
	if(CASE.Model=="Lima1"      | CASE.Model=="Lima2" | CASE.Model=="Lima3-Voom"  | CASE.Model=="Lima4-Voom"  ){ MAIN.FIGURE.plotQLDisp=c();  MAIN.FIGURE.plotBCV=c();  MAIN.FIGURE.barplot=c();  MAIN.FIGURE.plotMD.1=c() } else MAIN.FIGURE.plotMD.2=c()
	if(CASE.Model=="Raw data"   ){ MAIN.FIGURE.VOlnano=c(); MAIN.FIGURE.heatmap=c(); MAIN.FIGURE.plotMD_res=c(); MAIN.FIGURE.plotQLDisp=c();  MAIN.FIGURE.plotBCV=c();  MAIN.FIGURE.barcodeplot=c();  MAIN.FIGURE.plotQLDisp2=c() } 
 	######## 
 	if(CASE.Model=="Lima2"  | CASE.Model=="Lima4-Voom" | CASE.Model=="edgeR.ltr2" | CASE.Model=="edgeR.qlf2") { MAIN.FIGURE.plotMD.1=c();  MAIN.FIGURE.plotMD.2=c();  MAIN.FIGURE.plotMDS=c();  MAIN.FIGURE.plotQLDisp2=c() }
 	if(CASE.Model=="edgeR.ltr1" | CASE.Model=="edgeR.ltr2" | CASE.Model=="edgeR.qlf1" | CASE.Model=="edgeR.qlf2") MAIN.FIGURE.plot_qqt=c()
	
	#####################################################################################################
	##if(CASE.PLOT=="plotMD"){ echo="FALSE"; pdf.options(encoding='ISOLatin2.enc') } else { echo="TRUE"; pdf.options(encoding='default') }
	########
	if(RUn.Join.Alg.plots.pp==0) {
	if(length(MAIN.FIGURE.barplot   )>0 & CASE.Model=="Raw data") if(CASE.PLOT=="barplot"   ){ BB.mean= dge_PLOT$samples$lib.size*1e-6;  barplot(BB.mean, names.arg=COL.Small.Lib..PLOT, ylab="Library size (millions)", las= 2, cex.names= 0.50, border= TRUE, main=MAIN.FIGURE.barplot, col=COLLORS.MDS.PLOT);   legend("topright", legend=COLLORS.legend.PLOT, col=COLLORS.MDS.PLOT2, pch=15);  abline(h=c(mean(BB.mean),mean(BB.mean)), col="blue", lty = 2)  }
	if(length(MAIN.FIGURE.boxplot   )>0 & CASE.Model=="Raw data") if(CASE.PLOT=="boxplot"   ){ AA= log10(Counts.PLOT[,COl.SAMPLES.Original.PLOT]);  AA.mean=c();  for(COl.k in colnames(AA)){ AA[AA[,COl.k]==Inf | AA[,COl.k]==-Inf,COl.k]=0; AA.mean=c(AA.mean, mean(AA[,COl.k])) };   
	                                                                                           boxplot(AA, main=MAIN.FIGURE.boxplot,names=COL.Small.Lib..PLOT, las = 2, cex.axis=0.5, col=COLLORS.MDS.PLOT, ylab= expression("log"[10]*" (Counts)"));   legend("topright", legend=COLLORS.legend.PLOT, col=COLLORS.MDS.PLOT2, pch=15);  abline(h=c(mean(AA.mean),mean(AA.mean)), col="blue", lty = 2) }
	if(length(MAIN.FIGURE.plotMD.1  )>0)                          if(CASE.PLOT=="plotMD"    ){ plotMD    (cpm(dge_PLOT, log=TRUE), column=1, main=MAIN.FIGURE.plotMD.1, ylab="Expression log-ratio" ) }
	if(length(MAIN.FIGURE.plotMD.2  )>0)                          if(CASE.PLOT=="plotMD"    ){ plotMD    (    dge_PLOT           , column=1, main=MAIN.FIGURE.plotMD.2, ylab="Expression log-ratio" ) }
	if(length(MAIN.FIGURE.plotMDS   )>0)                          if(CASE.PLOT=="plotMDS"   ){ plotMDS   (dge_PLOT, col=COLLORS.MDS.PLOT   , main=MAIN.FIGURE.plotMDS   );  }  ## legend("topright", legend=COLLORS.legend.PLOT, col=COLLORS.MDS.PLOT2, pch=15) }
	if(length(MAIN.FIGURE.plotBCV   )>0)                          if(CASE.PLOT=="plotBCV"   ){ plotBCV   (dge_PLOT                         , main=MAIN.FIGURE.plotBCV   ) }
	if(length(MAIN.FIGURE.plotQLDisp)>0)                          if(CASE.PLOT=="plotQLDisp"){ plotQLDisp(FIT.PLOT                         , main=MAIN.FIGURE.plotQLDisp) }
	if(length(MAIN.FIGURE.plotMD_res)>0 & length(RES.PLOT)>0    ) if(CASE.PLOT=="plotMD_res"){ plotMD    (RES.PLOT, main=MAIN.FIGURE.plotMD_res, ylab="Expression log-ratio", cex.main=0.9);   abline(h=c(-1, 1), col="blue")  }
	########
	if(CASE.PLOT=="plotMDS" & length(MAIN.FIGURE.plotMD.De)>0) if(CASE.Model=="DESeq2"){ print( plotPCA(Desq2..vsd, intgroup=c("condition","Test")) )  } 
	
	##################  New DeSeq2 (plots counts) 
	MAIN.FIGURE.plotCounts.De= c()
	if(CASE.PLOT=="plotCounts" & length(MAIN.FIGURE.plotCounts.De)>0) if(CASE.Model=="DESeq2") {
		if(exists("DEsk2.condition..Pipe")) Desq2..res = results(dds, name=DEsk2.condition..Pipe) else Desq2..res = results(dds, name="condition_UnA_vs_Aff")
		Desq2..d   = plotCounts(dge_DESeq2, gene=which.min(Desq2..res$padj), intgroup="condition", returnData=TRUE)
		print(ggplot(Desq2..d, aes(x=condition, y=count)) + geom_point(position=position_jitter(w=0.1,h=0)) + scale_y_log10(breaks=c(25,100,400)))
	} 

	################## propmap 
	if(length(propmap.ORG)>0 & 66==55) {
		o = order(Targets$Sample.Identifier)
		o = c(1:nrow(Targets))
		barplot(as.matrix(t(cbind(propmap.ORG[o,"NumMapped"]*1e-6,(propmap.ORG[o,"NumTotal"]-propmap.ORG[o,"NumMapped"])*1e-6))),ylab="Number of Reads (millions)", 
            names = Targets$Sample.Identifier[o],las=3, cex.names=0.3, cex.axis=0.7, density = c(80,0),legend = c("Number of Mapped Reads", "Number of Unmapped Reads"),
            args.legend = list(x = "topright",cex = 0.5, bty = "n"))
	}
	##################  
	}

	################################################## plotBCV --> VOOM
	if(length(MAIN.FIGURE.plotBCV2)>0 & RUn.Join.Alg.plots.pp==0) if(CASE.PLOT=="plotBCV") {
		if(Models..VOOM.PLOT==1) VOOM.R = voom(dge_MAIN   , design.PLOT, plot=TRUE)      ## (library sizes are quite variable between samples)
		if(Models..VOOM.PLOT==2) VOOM.R = voom(Counts.PLOT[,COl.SAMPLES.Original.PLOT], design.PLOT, plot=TRUE)
		if(Models..VOOM.PLOT==3) VOOM.R = voom(Counts.PLOT[,COl.SAMPLES.Original.PLOT], design.PLOT, plot=TRUE, normalize="quantile");		## If the data are very noisy
	}
	################################################## plotBCV --> VOOM
	if(length(MAIN.FIGURE.plotQLDisp2)>0 & length(FIT.PLOT)>0 & RUn.Join.Alg.plots.pp==0) if(CASE.PLOT=="plotQLDisp2"){ plotMD(FIT.PLOT, main=MAIN.FIGURE.plotQLDisp2);   abline(0,0,col="blue");   }  ## text(fit$Amean[top30],fit$coef[top30],labels=fit$genes[top30,"Name"],cex=0.8,col="blue")
	if(length(MAIN.FIGURE.plot_qqt   )>0 & length(FIT.PLOT)>0 & RUn.Join.Alg.plots.pp==0) if(CASE.PLOT=="plot_qqt"   ){ qqt(FIT.PLOT$t, df=FIT.PLOT$df.prior+FIT.PLOT$df.residual, pch=16,cex=0.2, main=MAIN.FIGURE.plot_qqt);  abline(0,1) }

	################################################## Path.Analysis  
	if(CASE.PLOT=="Path.Analysis1" | CASE.PLOT=="Path.Analysis2") if(nrow(TABLE.TOGO.PLOT)>0 & RUn.Join.Alg.plots.pp==1) {
		######### 
		PLOT.GO.Kegg.VEC..Path.PLOT.l= RNAseq..Pathanalysis..PLOT.MAIN;   PLOT.pvalue.A.PLOT.l= c("all","soft","join","Select")[1];   if(CASE.PLOT=="Path.Analysis2"){ PLOT.GO.Kegg.VEC..Path.PLOT.l= RNAseq..Pathanalysis..PLOT.Special;   PLOT.pvalue.A.PLOT.l= c("all","soft","join","Select")[3] }
		#########  
		TABLE.TOGO.PLOT..SPecial= TABLE.TOGO.PLOT[TABLE.TOGO.PLOT[,"User"]=="Path-Plot",];       MAIN.TITLE..Path.ll= c();    if(exists("RNAseq..Special.PathAnalalys..Tittle")) if(length(RNAseq..Special.PathAnalalys..Tittle)>0) if(RNAseq..Special.PathAnalalys..Tittle[1]!="") MAIN.TITLE..Path.ll= RNAseq..Special.PathAnalalys..Tittle[1]
		if(nrow(TABLE.TOGO.PLOT..SPecial)>0) FFF.RNAseq..Plot.Path.Analysis(TABLE.TOGO.PLOT..SPecial, c(), c("kegga","goana","both")[3] , c("all","soft","join","Select")[4], RNAseq..Pathanalysis..Min.Pvalue, c(1000000)                      , c(1000000)                      , MAIN.TITLE..Path.ll)
		if(nrow(TABLE.TOGO.PLOT         )>0) FFF.RNAseq..Plot.Path.Analysis(TABLE.TOGO.PLOT         , c(), PLOT.GO.Kegg.VEC..Path.PLOT.l,        PLOT.pvalue.A.PLOT.l       , RNAseq..Pathanalysis..Min.Pvalue, RNAseq..Pathanalysis..MAX.Ngenes, RNAseq..Pathanalysis..MAX.NPaths, c() )
	}

	################################################## VennDiagram
	if(CASE.PLOT=="VennDiagram") if(length(MAIN.FIGURE.VennDiagram)>0 & nrow(TABLEs.ALL.PLOT)>0 & RUn.Join.Alg.plots.pp==0) {
		#########
		if(!exists("CASEs.PLOT..Overlapping.Gene")) CASEs.PLOT..Overlapping.Gene= c(1,2,3,4)[c(1:4)];  
		#########     
		for(CASE.JoiXX in CASEs.PLOT..Overlapping.Gene) {  ## CASE.JoiXX=1
			#########
			Models.Alg.logFC.PLOT= c(-1,1.2,1.5,2)[CASE.JoiXX];     Models.Alg.PValue.PLOT = c(-1,0.05,0.05,0.01)[CASE.JoiXX];     Models.Alg.FDR.PLOT= c(-1,0.1,0.05,0.01)[CASE.JoiXX]
			#########
			print.JOIN.Algorithms=c(0,1)[1]; 		print.JOIN.Percetage=print.JOIN.Algorithms;   		print.VEN.DIAGRAM=print.JOIN.Algorithms
			#########
			if(print.JOIN.Algorithms>0) print(paste("############    CASE=",CASE.JoiXX,"       ", date() ))
			#########
			RNAseq..test_run..PLOT= unique(TABLEs.ALL.PLOT[,"Test.XX"])
			#########
			RUN.Togo.PLOT= c(1,2)[1];		TXT.Main.Title1.PLOT= "Gene overlapping";     TXT.Main.Title2.PLOT="";   Use.Col.Max.Mean..VD= c(".All")[1]
			TABLE.test.NEW.PLOT = FFF.RNAseq..JOIN.Algorithms.Tables.Togo (RUN.Togo.PLOT, TABLEs.ALL.PLOT    , RNAseq..test_run..PLOT, Use.Col.Max.Mean..VD, Models.Alg.logFC.PLOT, Models.Alg.PValue.PLOT, Models.Alg.FDR.PLOT, print.JOIN.Algorithms)
			                      FFF.RNAseq..JOIN.Algorithms..VEN.DIAGRAM(               TABLE.test.NEW.PLOT, RNAseq..test_run..PLOT, TXT.Main.filters..FF, TXT.Main.Title1.PLOT, TXT.Main.Title2.PLOT, print.VEN.DIAGRAM)                        
			rm(TXT.Main.filters..FF, COL.SAVE..TABLE..pvlues..FF, COL.SAVE..TABLE.test.NEW..FF, envir = globalenv())                                          
	}	}
	
	################################################## VennDiagram.TOGO
	if(CASE.PLOT=="VennDiagram.GO") if(length(MAIN.FIGURE.VennDia.TOGO)>0 & nrow(TABLEs.ALL.PLOT)>0 & RUn.Join.Alg.plots.pp==0) if(nrow(TABLE.TOGO.PLOT)>0){
		#########
		if(!exists("CASEs.PLOT..PAthway.GO.KEGG" )) CASEs.PLOT..PAthway.GO.KEGG = c(1,2,3,4)[c(1:4)];				if(!exists("MAX.PValue.Path.KEGG.VenDiagram..VEC")) MAX.PValue.Path.KEGG.VenDiagram..VEC= c(-1, 1e-03, 1e-05, 1e-07)
		#########
		## setwd(MAIN.MAIN.DIR...MAIN.Temporal);   pdf(paste(Project.RNA..run,"..TEST..VennDiagram.pdf",sep="")) 
		#########
		par(mfrow=c(3,2));
		for(CASE.JoiXX in CASEs.PLOT..PAthway.GO.KEGG) {
			ROWS.old.GO.KEGG= 100
			###########################
			if(ROWS.old.GO.KEGG>0) {
				GO.logFC.PLOT= c(-1,1.2,1.5,2)[CASE.JoiXX];     GO.PValue.PLOT = c(-1,0.05,0.05,0.01)[CASE.JoiXX];      GO.FDR.PLOT= c(-1,0.1,0.05,0.01)[CASE.JoiXX];
				###########################
				#USE.Defaults.Results=0;  if(GO.logFC.PLOT==MIN.logFC..Res.GO & GO.PValue.PLOT==MAX.PValue..Res.GO & MAX.FDR..Res.GO..Plot.QC==GO.FDR.PLOT) USE.Defaults.Results=1;
				USE.Defaults.Results=0;   if(CASE..Res.GO==CASE.JoiXX) USE.Defaults.Results=1;
				#######
				if(USE.Defaults.Results==0) RUN.Big.Table.TOGO.PLOT= 1 else RUN.Big.Table.TOGO.PLOT= 0
				#######
				for(GO.PValue.Path in MAX.PValue.Path.KEGG.VenDiagram..VEC) for(RUN.goana.Kegga.PLOT in c(1:6)) {  ## CASE.JoiXX=4;  RUN.goana.Kegga.PLOT=5
				##############
					RUN.Togo.PLOT= 2;   GO.PLOT.PLOT=c(TRUE,FALSE)[2];   print.JOIN.KKII=c(0,1)[1]
					XXX= FFF.RNAseq..RUN.goana.Kegga(RUN.Togo.PLOT, RUN.Big.Table.TOGO.PLOT, TABLEs.ALL.PLOT, CASE.Model.VEC.PLOT, test_run.pp.PLOT,  DIR_Annotations.Organism.PLOT, GO.logFC.PLOT, GO.PValue.PLOT,  GO.FDR.PLOT, GO.PValue.Path, print.JOIN.KKII, GO.PLOT.PLOT)
					###########################
					TXT.Main.goana.Kegga..FF.GO= ""
					if(RUN.goana.Kegga.PLOT==1){ TABLE.TOGO.PLOT.pp= TABLE.test.NEW.M1.goana.UP..FFF;		TXT.Main.goana.Kegga..FF.GO= paste("gene ontology (Up-regulated   "   ,nrow(TABLE.TOGO.PLOT.pp),")",sep="") }
					if(RUN.goana.Kegga.PLOT==2){ TABLE.TOGO.PLOT.pp= TABLE.test.NEW.M1.goana.DOWN..FFF;		TXT.Main.goana.Kegga..FF.GO= paste("gene ontology (Down-regulated   " ,nrow(TABLE.TOGO.PLOT.pp),")",sep="") }
					if(RUN.goana.Kegga.PLOT==3){ TABLE.TOGO.PLOT.pp= TABLE.test.NEW.M1.Kegga.UP..FFF;		TXT.Main.goana.Kegga..FF.GO= paste("KEGG pathways (Up-regulated   "   ,nrow(TABLE.TOGO.PLOT.pp),")",sep="") }
					if(RUN.goana.Kegga.PLOT==4){ TABLE.TOGO.PLOT.pp= TABLE.test.NEW.M1.Kegga.DOWN..FFF;		TXT.Main.goana.Kegga..FF.GO= paste("KEGG pathways (Down-regulated   " ,nrow(TABLE.TOGO.PLOT.pp),")",sep="") }
					if(RUN.goana.Kegga.PLOT==5){ TABLE.TOGO.PLOT.pp= TABLE.test.NEW.M2.goana..FFF;			TXT.Main.goana.Kegga..FF.GO= paste("gene ontology (gene enrichment   ",nrow(TABLE.TOGO.PLOT.pp),")",sep="") }
					if(RUN.goana.Kegga.PLOT==6){ TABLE.TOGO.PLOT.pp= TABLE.test.NEW.M2.Kegga..FFF;			TXT.Main.goana.Kegga..FF.GO= paste("KEGG pathways (gene enrichment   ",nrow(TABLE.TOGO.PLOT.pp),")",sep="") }
					##TXT.Main.goana.Kegga..FF.GO= ""
					###########################
					print(paste("############    CASE=",CASE.JoiXX,"       ", TXT.Main.goana.Kegga..FF.GO, "      ", date() ))
					########################### 
					 FFF.RNAseq..JOIN.Algorithms..VEN.DIAGRAM(TABLE.TOGO.PLOT.pp, test_run.pp.PLOT, TXT.JOIN.filters.go.Kegga..FFF, TXT.Main.goana.Kegga..FF.GO, TXT.Main.goana.Kegga..FF.GO, print.JOIN.KKII, "Soft.Go") 
					#FFF.RNAseq..JOIN.Algorithms..VEN.DIAGRAM(TABLE.TOGO.PLOT.pp, test_run.pp.PLOT, TXT.Main.filters.GO..FF       , TXT.Main.goana.Kegga..FF.GO, TXT.Main.filters.KE..FF    , print.JOIN.TOGO, "Soft")  
            		ROWS.old.GO.KEGG= nrow(TABLE.TOGO.PLOT.pp)
            	}
            	if(exists("TABLE.test.NEW.M1.goana.UP..FFF")) rm(TABLE.test.NEW.M1.goana.UP..FFF, TABLE.test.NEW.M1.goana.DOWN..FFF, TABLE.test.NEW.M1.Kegga.UP..FFF, TABLE.test.NEW.M1.Kegga.DOWN..FFF, TABLE.test.NEW.M2.goana..FFF, TABLE.test.NEW.M2.Kegga..FFF, TXT.JOIN.filters.go.Kegga..FFF, envir = globalenv())
		}	}
		#rm(GO.Kegga.Model1..FFF, GO.Kegga.Model2..FFF, GO.Kegga.TXT.filters..FFF, envir = globalenv())			
	}

	################################################## Volcano  
	if(nrow(TABLE.Plot)>0) if(((CASE.PLOT=="Volcano" | CASE.PLOT=="Volcano2") & RUn.Join.Alg.plots.pp==0) | (CASE.PLOT=="Volcano.Join" & CASE.Model=="Join.Alg") | 
	                           (CASE.PLOT=="Volcano.Gene" & RUn.Join.Alg.plots.pp==1 & length(MAIN.FIGURE.VOlnano.Gene)>0) )  {
		###############
		TABLE.Plot[is.na(TABLE.Plot[,"type.gene.PLOT"]),"type.gene.PLOT"]= "";   #print(colnames(TABLE.Plot))
		###############
		ALL.pp= TABLE.Plot[,c(COL.logFC,COL.pvalue,COL.FDR,"gene.PLOT","type.gene.PLOT","YES.pvalue", COl.Special.gene.List.pp)];       ALL.pp[,COL.pvalue]= -log10(ALL.pp[,COL.pvalue]);
		ALL.pp= ALL.pp[order(abs(as.numeric(ALL.pp[,COL.pvalue])), decreasing = FALSE),];
		ALL.pp= ALL.pp[order(abs(as.numeric(ALL.pp[,COL.logFC ])), decreasing = TRUE ),]; 
		 
		###############
		ZOOOM.SPECIAL..VEC.xx= c(0,1,2)[1];   if(length(Plot.ONLY.Cases.PLOT)>0) ZOOOM.SPECIAL..VEC.xx= c(0,1,2)[1:1] 
		#########
		COl.Special.gene.List.pppp= c();  
		if(CASE.PLOT=="Volcano" | CASE.PLOT=="Volcano2" | CASE.PLOT=="Volcano.Join") COl.Special.gene.List.pppp= "NORMAL"
		if(CASE.PLOT=="Volcano.Gene" & length(COl.Special.gene.List.pp)>0          ) COl.Special.gene.List.pppp= c(RNAseq..Heatmap..PLOT_GENES..VEC[RNAseq..Heatmap..PLOT_GENES..VEC!="Auto"])  ##  "NORMAL",
		
		###############
		if(CASE.PLOT=="Volcano.Join" | CASE.PLOT=="Volcano.Gene") Legend..yes.PLOT=1 else Legend..yes.PLOT=0
		###############
		if(length(COl.Special.gene.List.pppp)>0 & nrow(ALL.pp)>0) for(VOL.PLOT in COl.Special.gene.List.pppp){  ## VOL.PLOT=COl.Special.gene.List.pppp[1]
			#########
			PLOT.SPECIFC.colour.xx=0;   ZOOOM.SPECIAL..VEC.xx= c(0,1)[1];		FDR1..colous.xx= "orange";    FDR2..colous.xx= "red"
			#########
			ALL.YPP= ALL.pp[ALL.pp[,"YES.pvalue"] <2 & ALL.pp[,"type.gene.PLOT"]=="protein_coding",];
			FDR1.PP= ALL.pp[ALL.pp[,"YES.pvalue"]==2 & ALL.pp[,"type.gene.PLOT"]=="protein_coding",];   
			FDR1   = ALL.pp[ALL.pp[,"YES.pvalue"]>=2 & ALL.pp[,"type.gene.PLOT"]=="protein_coding",];    
			FDR2   = ALL.pp[ALL.pp[,"YES.pvalue"]>=3 & ALL.pp[,"type.gene.PLOT"]=="protein_coding",];  FDR2.PP= FDR2;    MAT.TXT.pp= ALL.pp;   FDR.XYlim.pp= FDR1;
			#########
			if(VOL.PLOT=="NORMAL") {		
				MAIN.FIGURE.VOlnano.USE= paste("Join results  (A=",nrow(ALL.pp),";  F1=",nrow(FDR1),"-",nrow(FDR2),")",sep="")
				MAIN.FIGURE.VOlnano.USE= paste(CASE.Model, "  (A=",nrow(ALL.pp),";  F1=",nrow(FDR1),"-",nrow(FDR2),")",sep="")
				MAIN.FIGURE.VOlnano.USE= gsub("Join.Alg","Join results",MAIN.FIGURE.VOlnano.USE,fixed=TRUE)  
				#####
				MAT.TXT.pp2= MAT.TXT.pp[MAT.TXT.pp[,"type.gene.PLOT"]=="protein_coding",];  if(nrow(MAT.TXT.pp2)>3) MAT.TXT.pp= MAT.TXT.pp2
				
			} else {
				FDR1= FDR1[FDR1[,VOL.PLOT]!="",];   FDR2= FDR2[FDR2[,VOL.PLOT]!="",];   FDR.XYlim.pp= FDR1;   if(length(Plot.ONLY.Cases.PLOT)>0) ZOOOM.SPECIAL..VEC.xx= c(0,1,2)[1:2]
				#########					
				if(length(RNAseq..VOLCANO..COLOR.special..MAIN)>0) if(nrow(RNAseq..VOLCANO..COLOR.special..MAIN)>0)	{
					RNAseq..VOLCANO..COLOR.special..USE= RNAseq..VOLCANO..COLOR.special..MAIN[RNAseq..VOLCANO..COLOR.special..MAIN[,"Special.Genes"]==VOL.PLOT,];   #print(RNAseq..VOLCANO..COLOR.special..USE);   print(dim(RNAseq..VOLCANO..COLOR.special..USE)) 
					if(nrow(RNAseq..VOLCANO..COLOR.special..USE) >1) stop("MAIN ERROR ---> nrow(RNAseq..VOLCANO..COLOR.special..USE)>1")
					if(nrow(RNAseq..VOLCANO..COLOR.special..USE)==1){  
						######
						RNAseq..VOLCANO..COLOR.special..BLUE.xx= RNAseq..VOLCANO..COLOR.special..USE[1,"BLUE"];    RNAseq..VOLCANO..COLOR.special..RED.xx = RNAseq..VOLCANO..COLOR.special..USE[1,"RED"]
						######
						FDR.USE.pp= ALL.pp[ALL.pp[,"YES.pvalue"]>=3,]
						FDR1= FDR.USE.pp[FDR.USE.pp[,RNAseq..VOLCANO..COLOR.special..BLUE.xx]!="",];	 FDR2= FDR.USE.pp[FDR.USE.pp[,RNAseq..VOLCANO..COLOR.special..RED.xx]!="",];			  FDR1..colous.xx= "lightseagreen";    	   FDR2..colous.xx="red";      
						LEGEND.Volcano.PLOT..USE.color.xx= c(RNAseq..VOLCANO..COLOR.special..BLUE.xx,RNAseq..VOLCANO..COLOR.special..RED.xx);								  
						######
						FDR.XYlim.pp= FDR.USE.pp[FDR.USE.pp[,VOL.PLOT]!="",];    PLOT.SPECIFC.colour.xx=1;    #FDR1.PP=FDR1;   FDR2.PP= FDR2
				}	}
				#########
				MAT.TXT.pp= ALL.pp[ALL.pp[,VOL.PLOT]!="" & ALL.pp[,"YES.pvalue"]>=1,]
				MAIN.FIGURE.VOlnano.USE= paste(    VOL.PLOT,"    (A=",  nrow(ALL.pp),";  G=",nrow(ALL.pp[ALL.pp[,VOL.PLOT]!="",]),";  F=",nrow(FDR1),"-",nrow(FDR2),")",sep="")
			}
			############################## 
			for(ZOOOM.SPECIAL.xx in ZOOOM.SPECIAL..VEC.xx) {
				#####
				XMAX.FDR1.pp= as.integer(max(abs(ALL.pp[,COL.logFC])))+2;   XMIN.FDR1.pp= -XMAX.FDR1.pp;    TXT.ZOOOM0.yy="" 
				#####
				XLIM= range(XMIN.FDR1.pp, XMAX.FDR1.pp);   YLIM.xx= c(-1,-1)
				if(CASE.PLOT=="Volcano.Gene") if(exists("RNAseq..Volcano.Gene..ylim.MAX")) if(RNAseq..Volcano.Gene..ylim.MAX>0){ YLIM.xx= range(-1, RNAseq..Volcano.Gene..ylim.MAX);  TXT.ZOOOM0.yy=paste("   Ylim <",RNAseq..Volcano.Gene..ylim.MAX)   }
				#####
				MAIN.FIGURE.VOlnano.USE2= paste(MAIN.FIGURE.VOlnano.USE, TXT.ZOOOM0.yy,sep="")
				if(ZOOOM.SPECIAL.xx>=1 & nrow(FDR.XYlim.pp)>0){
					#####
					FDR.XYlim.pp2= FDR.XYlim.pp[FDR.XYlim.pp[,"type.gene.PLOT"]=="protein_coding",];  if(nrow(FDR.XYlim.pp2)>10) FDR.XYlim.pp= FDR.XYlim.pp2 
					#####
					YLIM.FDR1.pp=  1.1*max(as.numeric(FDR.XYlim.pp[,COL.pvalue]))
					XMIN.FDR1.pp=  min( c( (1.1*min(as.numeric(FDR.XYlim.pp[,COL.logFC ]))), (-logFC.PLOT-.3) ))
					XMAX.FDR1.pp=  max( c( (1.1*max(as.numeric(FDR.XYlim.pp[,COL.logFC ]))), ( logFC.PLOT+.3) ))
			 		#####
					YLIM.xx= range(-0.25, YLIM.FDR1.pp);		XLIM= range(XMIN.FDR1.pp, XMAX.FDR1.pp);       TXT.ZOOOM1.yy="";
					if(exists("RNAseq..Volcano.Special.genes..ylim.MAX")) if(RNAseq..Volcano.Special.genes..ylim.MAX<YLIM.FDR1.pp){ YLIM.xx= range(-1, RNAseq..Volcano.Special.genes..ylim.MAX);   TXT.ZOOOM1.yy=paste("   Ylim <",RNAseq..Volcano.Special.genes..ylim.MAX)  }
					#####
					MAIN.FIGURE.VOlnano.USE2= paste(MAIN.FIGURE.VOlnano.USE, "      ---> ZOOM",ZOOOM.SPECIAL.xx,TXT.ZOOOM1.yy,sep="")
					MAIN.FIGURE.VOlnano.USE2= paste(MAIN.FIGURE.VOlnano.USE, "      ---> ZOOM",sep="")
				}
				##### 
				if(ZOOOM.SPECIAL.xx==0 | (ZOOOM.SPECIAL.xx>=1 & nrow(FDR.XYlim.pp)>0)){
					####################
					XLAB=expression("log"[2]*" (Fold Change)")
					if(Use.Col.Max.Mean.PLOT==".Max") XLAB= expression("log"[2]*" (Fold Change)  --> max(algorithms)");    if(Use.Col.Max.Mean.PLOT==".Med" ) XLAB= expression("log"[2]*" (Fold Change)  --> median(algorithms)");   
					if(Use.Col.Max.Mean.PLOT==".Min") XLAB= expression("log"[2]*" (Fold Change)  --> min(algorithms)");    if(Use.Col.Max.Mean.PLOT==".Mean") XLAB= expression("log"[2]*" (Fold Change)  --> mean(algorithms)")
					######
					FDR1..colous.xx.YY= FDR1..colous.xx;  	FDR2..colous.xx.YY= FDR2..colous.xx;       	FDR1..colous.xx.ZZ= FDR1..colous.xx;  	FDR2..colous.xx.ZZ= FDR2..colous.xx;   	FDR1.P= FDR1.PP;   	FDR2.P= FDR2.PP;  	plot.Red.points.xx=0;	ALL.pp..TTT= ALL.pp; 
					if(RNAseq..VOLCANO..Black_points.To.Red==1) if(CASE.PLOT=="Volcano.Gene") if(VOL.PLOT!="NORMAL") if(PLOT.SPECIFC.colour.xx==0){  
						FDR1..colous.xx.YY= "orange";    	FDR2..colous.xx.YY= "red";      			FDR1..colous.xx.ZZ= "royalblue1";    	FDR2..colous.xx.ZZ= "navyblue";   		FDR1.P= FDR1.PP;   	FDR2.P= FDR2.PP;	plot.Red.points.xx=1;   ALL.pp..TTT= ALL.YPP   }
					######
					if(VOL.PLOT=="NORMAL" | CASE.PLOT=="Volcano" | CASE.PLOT=="Volcano2") {  FDR1..colous.xx.ZZ= "royalblue1";    	FDR2..colous.xx.ZZ= "navyblue"  }
					######
					if(ZOOOM.SPECIAL.xx>=2){ ALL.pp..TTT= ALL.pp[c(1:3),];  ALL.pp..TTT[,COL.logFC]=0;  ALL.pp..TTT[,COL.pvalue]=0 }
					
					#################### Plot 0
					if(TXT.ZOOOM0.yy==""){ plot(ALL.pp..TTT[,c(COL.logFC,COL.pvalue)], col="black", type="p", cex=.3, ylab= expression("-log"[10]*" (P Value)"), xlab=XLAB, main=MAIN.FIGURE.VOlnano.USE2, cex.main=0.9, xlim=XLIM )
				    } else                 plot(ALL.pp..TTT[,c(COL.logFC,COL.pvalue)], col="black", type="p", cex=.3, ylab= expression("-log"[10]*" (P Value)"), xlab=XLAB, main=MAIN.FIGURE.VOlnano.USE2, cex.main=0.9, xlim=XLIM, ylim=YLIM.xx )
					#####
					if(ZOOOM.SPECIAL.xx<=1){
						if(nrow(FDR1.P)>0) points(FDR1.P[,c(COL.logFC,COL.pvalue)], col=FDR1..colous.xx.YY, type="p", pch = 8, cex=.3)
						if(nrow(FDR2.P)>0) points(FDR2.P[,c(COL.logFC,COL.pvalue)], col=FDR2..colous.xx.YY, type="p", pch = 8, cex=.3)
						#####
						if(VOL.PLOT!="NORMAL"){
							if(nrow(FDR1 )>0) points(FDR1 [,c(COL.logFC,COL.pvalue)], col=FDR1..colous.xx.ZZ, type="p", pch = 8, cex=.5)
							if(nrow(FDR2 )>0) points(FDR2 [,c(COL.logFC,COL.pvalue)], col=FDR2..colous.xx.ZZ, type="p", pch = 8, cex=.5)
					}	}
					#####
					points(c(-100,100),c(-log10(P.value.PLOT),-log10(P.value.PLOT)), col="gray", type="l", cex=1)
					points(c(-logFC.PLOT,-logFC.PLOT),c(-100,100), col="gray", type="l", cex=1);    points(c(logFC.PLOT,logFC.PLOT),c(-100,100), col="gray", type="l", cex=1)
					#####
					if(PLOT.SPECIFC.colour.xx==0) LEGEND.Volcano.PLOT= c(paste("FDR >",FDR2.value.PLOT),paste("FDR <",FDR2.value.PLOT),paste("FDR <",FDR1.value.PLOT)) else LEGEND.Volcano.PLOT= LEGEND.Volcano.PLOT..USE.color.xx
					#####
					if(Legend..yes.PLOT==1) legend("topright", legend=LEGEND.Volcano.PLOT, col=c("black",FDR1..colous.xx.YY,FDR2..colous.xx.YY), pch=15)
					#####	
					#print(head(MAT.TXT.pp))
					if(nrow(MAT.TXT.pp)>=2) {
						#####
						MAT.TXT.pp[,"COLOUR"]="black";
						if(PLOT.SPECIFC.colour.xx==0){
							MAT.TXT.pp[MAT.TXT.pp[,"type.gene.PLOT"]=="protein_coding" & MAT.TXT.pp[,"YES.pvalue"]>=2 ,"COLOUR"]= FDR1..colous.xx.ZZ 
							MAT.TXT.pp[MAT.TXT.pp[,"type.gene.PLOT"]=="protein_coding" & MAT.TXT.pp[,"YES.pvalue"]>=3 ,"COLOUR"]= FDR2..colous.xx.ZZ
							NN.Repressed1.pp= nrow(MAT.TXT.pp[MAT.TXT.pp[,"type.gene.PLOT"]=="protein_coding" & MAT.TXT.pp[,"YES.pvalue"]>=2 & as.numeric(MAT.TXT.pp[,COL.logFC])<0,])
							NN.Induced1.pp  = nrow(MAT.TXT.pp[MAT.TXT.pp[,"type.gene.PLOT"]=="protein_coding" & MAT.TXT.pp[,"YES.pvalue"]>=2 & as.numeric(MAT.TXT.pp[,COL.logFC])>0,])
							NN.Repressed2.pp= nrow(MAT.TXT.pp[MAT.TXT.pp[,"type.gene.PLOT"]=="protein_coding" & MAT.TXT.pp[,"YES.pvalue"]>=3 & as.numeric(MAT.TXT.pp[,COL.logFC])<0,])
							NN.Induced2.pp  = nrow(MAT.TXT.pp[MAT.TXT.pp[,"type.gene.PLOT"]=="protein_coding" & MAT.TXT.pp[,"YES.pvalue"]>=3 & as.numeric(MAT.TXT.pp[,COL.logFC])>0,])  
							NN.Repressed.pp = paste(NN.Repressed1.pp,"-",NN.Repressed2.pp,sep="")
							NN.Induced.pp   = paste(NN.Induced1.pp  ,"-",NN.Induced2.pp  ,sep="")
						} else {
							MAT.TXT.pp[MAT.TXT.pp[,RNAseq..VOLCANO..COLOR.special..RED.xx ]!="" & MAT.TXT.pp[,"YES.pvalue"]>=3,"COLOUR"]= FDR2..colous.xx.ZZ
							MAT.TXT.pp[MAT.TXT.pp[,RNAseq..VOLCANO..COLOR.special..BLUE.xx]!="" & MAT.TXT.pp[,"YES.pvalue"]>=3,"COLOUR"]= FDR1..colous.xx.ZZ
							NN.Repressed1.pp= nrow(MAT.TXT.pp[MAT.TXT.pp[,RNAseq..VOLCANO..COLOR.special..BLUE.xx]!="" & MAT.TXT.pp[,"YES.pvalue"]>=3 & as.numeric(MAT.TXT.pp[,COL.logFC])<0,])
							NN.Repressed2.pp= nrow(MAT.TXT.pp[MAT.TXT.pp[,RNAseq..VOLCANO..COLOR.special..RED.xx ]!="" & MAT.TXT.pp[,"YES.pvalue"]>=3 & as.numeric(MAT.TXT.pp[,COL.logFC])<0,])
							NN.Induced1.pp  = nrow(MAT.TXT.pp[MAT.TXT.pp[,RNAseq..VOLCANO..COLOR.special..BLUE.xx]!="" & MAT.TXT.pp[,"YES.pvalue"]>=3 & as.numeric(MAT.TXT.pp[,COL.logFC])>0,])
							NN.Induced2.pp  = nrow(MAT.TXT.pp[MAT.TXT.pp[,RNAseq..VOLCANO..COLOR.special..RED.xx ]!="" & MAT.TXT.pp[,"YES.pvalue"]>=3 & as.numeric(MAT.TXT.pp[,COL.logFC])>0,])
							NN.Repressed.pp = paste(NN.Repressed1.pp,"-",NN.Repressed2.pp,sep="")
							NN.Induced.pp   = paste(NN.Induced1.pp  ,"-",NN.Induced2.pp  ,sep="")
						}
						####################
						MAT.TXT.pp= MAT.TXT.pp[MAT.TXT.pp[,"COLOUR"]!="black",]
						#MAT.TXT.pp= MAT.TXT.pp[as.numeric(abs(MAT.TXT.pp[,COL.logFC]))>=logFC.PLOT,]
						if(nrow(MAT.TXT.pp)>0){
							MAT.TXT.pp[,"pos"]=4;  if(nrow(MAT.TXT.pp)>1) MAT.TXT.pp[seq(2,nrow(MAT.TXT.pp),2),"pos"]= 2;    #print(MAT.TXT.pp[,c(VOL.PLOT,COL.logFC, "YES.pvalue","COLOUR","type.gene.PLOT")])
							#####
							top30..RR.x= c(1:nrow(MAT.TXT.pp)); 
							if(VOL.PLOT=="NORMAL"){   
								MAT.TXT.pp= MAT.TXT.pp[order(as.numeric(MAT.TXT.pp[,COL.logFC])),];    MAT.TXT.pp[,"XXX.RR"]= c(1:nrow(MAT.TXT.pp));   MAT.TXT.pp[,"XXX.yes"]= 0
								if(MAX..GENES.TXT.PLOT>= nrow(MAT.TXT.pp)) MAT.TXT.pp[,"XXX.yes"]= 1 else {
									MAT.TXT.pp[c(1:MAX..GENES.TXT.PLOT),"XXX.yes"]= 1;  MAT.TXT.pp[c(nrow(MAT.TXT.pp):(nrow(MAT.TXT.pp)-MAX..GENES.TXT.PLOT)),"XXX.yes"]= 1
								} 
								top30..RR.x = c(MAT.TXT.pp[MAT.TXT.pp[,"XXX.yes"]==1,"XXX.RR"])
							} 
							#####
							CEX.text.pp= 0.6;  if(ZOOOM.SPECIAL.xx>=1) CEX.text.pp= 0.8 
				   	    	#text(MAT.TXT.pp[top30..RR.x,COL.logFC],MAT.TXT.pp[top30..RR.x,COL.pvalue],labels=MAT.TXT.pp[top30..RR.x,"gene.PLOT"],cex=CEX.text.pp)
				    		text(MAT.TXT.pp[top30..RR.x,COL.logFC],MAT.TXT.pp[top30..RR.x,COL.pvalue] ,labels=MAT.TXT.pp[top30..RR.x,"gene.PLOT"],cex=CEX.text.pp,col= MAT.TXT.pp[,"COLOUR"], pos=MAT.TXT.pp[,"pos"])
				    		##############################
				    		if(!exists("RNAseq..USE.Reverse.Targets.Model")) RNAseq..USE.Reverse.Targets.Model.USE= 0 else RNAseq..USE.Reverse.Targets.Model.USE= RNAseq..USE.Reverse.Targets.Model[1]
				    		#####
				    		TEXT.induced.pp  = paste("Induced (aff;  "                          ,NN.Induced.pp,")",sep="");        TEXT.repressed.pp= paste("Repressed (aff;  "                          ,NN.Repressed.pp,")",sep="");
				    		TEXT.induced.pp  = paste("Induced (",RNA.SEQ.Test.VEC..Pipe[1],";  ",NN.Induced.pp,")",sep="");        TEXT.repressed.pp= paste("Repressed (",RNA.SEQ.Test.VEC..Pipe[1],";  ",NN.Repressed.pp,")",sep="");
				    		#####   
				    		col.induced.TXT.pp="springgreen4";     col.repressed.TXT.pp="royalblue3"
				    		#####
				    		CEX.text.ind.red.pp= 0.65;     Y.indred.pp= -0.1;  if(ZOOOM.SPECIAL.xx>=1 & nrow(FDR.XYlim.pp)>0) if(YLIM.FDR1.pp<10) Y.indred.pp= 0   
							#####
							TEXT.repressed.XXX.pp= TEXT.repressed.pp;   TEXT.induced.XXX.pp= TEXT.induced.pp 
				    		if(RNAseq..USE.Reverse.Targets.Model.USE==0){  TEXT.repressed.XXX.pp= TEXT.induced.pp;   TEXT.induced.XXX.pp=TEXT.repressed.pp  }
				    		#####
				    		if(CASE.PLOT!="Volcano"){
				    			text((3*XMIN.FDR1.pp/4), Y.indred.pp, TEXT.induced.XXX.pp  , cex=CEX.text.ind.red.pp, col= col.induced.TXT.pp  , pos=c(2,4)[2])  ##below,left,above,right
				    			text((3*XMAX.FDR1.pp/4), Y.indred.pp, TEXT.repressed.XXX.pp, cex=CEX.text.ind.red.pp, col= col.repressed.TXT.pp, pos=c(2,4)[1])  ##below,left,above,right
	}	}	}	} 	}	}	}

	################################################## barcodeplot 
	if(CASE.PLOT=="barcodeplot" | CASE.PLOT=="barcodeplot.Gene") if(length(MAIN.FIGURE.barcodeplot)>0) if(nrow(TABLE.TOGO.PLOT)>0) {
		####################################
		COl.GENES.barcodeplot.pp= "RawPro.gene";		COl.GENES.GO.barcodeplot.pp= "GeneID.GoTo";		COL.Ngenes.GoTo.PLOT= "Ngenes.GoTo";		COL.TNgenes.GoTo.PLOT= "TNgenes.GoTo";		TXT.Test.MAIN..PP="Test";
		MIN.Num.Genes.to_plot.barcodeplot.pp= c(1,2,10)[2];	 		MAX.Num.Genes.to_plot.barcodeplot.pp= 10000;	    MAX.characters.TITLE.barcodeplot.pp= 1000;				barcodeplot.update.plot.pp=c(1,0)[1] 
		MAX.characters.we.can.plot.pp= 200;			MAX.PValue.Path.barcodeplot.pp= c(-1,1e-04, 1e-05)[1]
		##################
		MAX.number.plots.barcodeplot.PLOT= c(3,10,100)[2];  if(length(Plot.ONLY.Cases.PLOT)==1) if(Plot.ONLY.Cases.PLOT=="barcodeplot" | Plot.ONLY.Cases.PLOT=="barcodeplot.Gene") MAX.number.plots.barcodeplot.PLOT= c(3,10,1000)[3]
		##################
		TABLE.Plot.bar.Inp= TABLE.Plot[0,]
		if(CASE.Model=="Join.Alg"                             ) TABLE.Plot.bar.Inp= TABLE.ALL.JOIN.PLOT[,c(COL.logFC,COl.GENES.barcodeplot.pp,"Raw.geneID","gene.PLOT", COl.Special.gene.List.pp, paste("Filters",Use.Col.Max.Mean.PLOT,sep="") )] 
		if(CASE.Model=="edgeR.ltr2" | CASE.Model=="Lima3-Voom") TABLE.Plot.bar.Inp= TABLE.Plot         [,c(COL.logFC,COl.GENES.barcodeplot.pp,"Raw.geneID","gene.PLOT")]
		if(length(Plot.ONLY.Cases.PLOT)==1 & CASE.Model!="Join.Alg") TABLE.Plot.bar.Inp= TABLE.Plot[0,]
		##################
		COL.pavlue.P.DE.pp  = paste(TXT.Test.MAIN..PP, test_run.pp.PLOT,".P.DE"  ,sep="")
		COL.pavlue.P.Up.pp  = paste(TXT.Test.MAIN..PP, test_run.pp.PLOT,".P.Up"  ,sep="")
		COL.pavlue.P.Down.pp= paste(TXT.Test.MAIN..PP, test_run.pp.PLOT,".P.Down",sep="")
		##################
		if(CASE.PLOT=="barcodeplot.Gene") CASE.barcodeplot_TO_PLOT= c(10,11)
		if(CASE.PLOT=="barcodeplot"     ) CASE.barcodeplot_TO_PLOT= 100
		if(length(Plot.ONLY.Cases.PLOT)>0 & CASE.PLOT=="barcodeplot" & barcodeplot.update.plot.pp==0) CASE.barcodeplot_TO_PLOT= c(1:6)
		if(length(Plot.ONLY.Cases.PLOT)>0 & CASE.PLOT=="barcodeplot" & barcodeplot.update.plot.pp==1) CASE.barcodeplot_TO_PLOT= c( 8 )
		##################
		if(nrow(TABLE.Plot.bar.Inp)>0) for(CASE.pp in CASE.barcodeplot_TO_PLOT) {  ## CASE.pp=100
			########## 
			if(  CASE.pp==8           ){ COL.pavlue.USE.pp = c();        				TXT..FIL2.pp= "error";  	    TXT.Method.FIL.pp= c();      } 
			if(  CASE.pp==10          ){ COL.pavlue.USE.pp = c();        				TXT..FIL2.pp= "Gene-List";  	TXT.Method.FIL.pp= c();      } 
			if(  CASE.pp==11          ){ COL.pavlue.USE.pp = c();        				TXT..FIL2.pp= "Path-List";  	TXT.Method.FIL.pp= c();      } 
			if(  CASE.pp==100         ){ COL.pavlue.USE.pp = c();        				TXT..FIL2.pp= "error"    ;     	TXT.Method.FIL.pp= c();      }  
			##########   
			if(CASE.pp==1 | CASE.pp==4){ COL.pavlue.USE.pp = COL.pavlue.P.Up.pp;  		TXT..FIL2.pp= "up"    ;  TXT.Method.FIL.pp="goana1"; if(CASE.pp==4) TXT.Method.FIL.pp="kegga1"  }
			if(CASE.pp==2 | CASE.pp==5){ COL.pavlue.USE.pp = COL.pavlue.P.Down.pp;  	TXT..FIL2.pp= "down"  ;  TXT.Method.FIL.pp="goana1"; if(CASE.pp==5) TXT.Method.FIL.pp="kegga1"  }
			if(CASE.pp==3 | CASE.pp==6){ COL.pavlue.USE.pp = COL.pavlue.P.DE.pp;  		TXT..FIL2.pp= "geneN" ;  TXT.Method.FIL.pp="goana2"; if(CASE.pp==6) TXT.Method.FIL.pp="kegga2"  }
			########## 
   			TABLE.GO.CUT.pp= TABLE.TOGO.PLOT
   			if(nrow(TABLE.GO.CUT.pp)>0) {
   				TABLE.GO.CUT.pp = TABLE.GO.CUT.pp[as.character(TABLE.GO.CUT.pp[,"User"])!="0" | as.numeric(TABLE.GO.CUT.pp[,"pvalue.A"])<= MAX.PValue.Path..Barcodeplot,]
   				TABLE.GO.CUT.pp = TABLE.GO.CUT.pp[as.character(TABLE.GO.CUT.pp[,"User"])!="0" | as.numeric(TABLE.GO.CUT.pp[,"N"])<=RNAseq..Pathanalysis..MAX.Ngenes,];
   				TABLE.GO.USER.pp= TABLE.GO.CUT.pp[as.character(TABLE.GO.CUT.pp[,"User"])!="0",];  if(nrow(TABLE.GO.USER.pp)>1) TABLE.GO.USER.pp= TABLE.GO.USER.pp[order(TABLE.GO.USER.pp[,"RawPro.gene"]),]
   				TABLE.GO.CUT.pp= rbind(TABLE.GO.USER.pp, TABLE.GO.CUT.pp[as.character(TABLE.GO.CUT.pp[,"User"])=="0",])
   			}
			if(nrow(TABLE.GO.CUT.pp)>MAX.number.plots.barcodeplot) TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[c(1:MAX.number.plots.barcodeplot),]
   			##################		
   			if(CASE.pp>=1 & CASE.pp<=6){
   				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,"User"   ]) & TABLE.GO.CUT.pp[,"User"   ]!="Gene-List" & TABLE.GO.CUT.pp[,"User"]!="Path-List",]
   				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,"Method" ]) & TABLE.GO.CUT.pp[,"Method" ]==TXT.Method.FIL.pp,]
   				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,"UP.DOWN"]) & TABLE.GO.CUT.pp[,"UP.DOWN"]==TXT..FIL2.pp     ,]
   				if(MAX.PValue.Path.barcodeplot.pp>=0 & MAX.PValue.Path.barcodeplot.pp<=1)
				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,COL.pavlue.USE.pp   ]) & as.numeric(TABLE.GO.CUT.pp[,COL.pavlue.USE.pp   ])<=MAX.PValue.Path.barcodeplot.pp,]
				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,COL.Ngenes.GoTo.PLOT]) & as.numeric(TABLE.GO.CUT.pp[,COL.Ngenes.GoTo.PLOT])>=MIN.Num.Genes.to_plot.barcodeplot.pp,]
				#########
				if(nrow(TABLE.GO.CUT.pp)>0) TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[order(as.numeric(TABLE.GO.CUT.pp[,COL.pavlue.USE.pp]),decreasing=FALSE),];
			}
			##########		
   			if(CASE.pp==8){
   				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,"User"   ]) & TABLE.GO.CUT.pp[,"User"   ]!="Gene-List" & TABLE.GO.CUT.pp[,"User"]!="Path-List",]
   				if(MAX.PValue.Path.barcodeplot.pp>=0 & MAX.PValue.Path.barcodeplot.pp<=1)
				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,"pvalue.A"          ]) & as.numeric(TABLE.GO.CUT.pp[,"pvalue.A"          ])<=MAX.PValue.Path.barcodeplot.pp   ,]
				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,COL.Ngenes.GoTo.PLOT]) & as.numeric(TABLE.GO.CUT.pp[,COL.Ngenes.GoTo.PLOT])>=MIN.Num.Genes.to_plot.barcodeplot.pp,]
				#########
				if(nrow(TABLE.GO.CUT.pp)>0) TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[order(as.numeric(TABLE.GO.CUT.pp[,   "pvalue.A"    ]),decreasing=FALSE),];
			}
			##################
			if(CASE.pp==10 | CASE.pp==11){
				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,"User"]) & TABLE.GO.CUT.pp[,"User"]==TXT..FIL2.pp,]
				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,COL.Ngenes.GoTo.PLOT]) & as.numeric(TABLE.GO.CUT.pp[,COL.Ngenes.GoTo.PLOT])>=MIN.Num.Genes.to_plot.barcodeplot.pp,]
				if(nrow(TABLE.GO.CUT.pp)>0) if(nrow(TABLE.GO.CUT.pp)>1) if(CASE.Model=="edgeR.ltr2" | CASE.Model=="Lima3-Voom") TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[0,]
				#print(nrow(TABLE.GO.CUT.pp));  print(CASE.Model);
				#print(head(TABLE.GO.CUT.pp[,c("Ngenes.GoTo",COL.pavlue.P.Up.pp,COL.pavlue.P.Down.pp,COL.pavlue.P.DE.pp, "Pathway")]),3);
				COL.pavlue.USE.pp = COL.pavlue.P.Up.pp
			}
			##################
			if(CASE.pp==100) {
				##################
   				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,"User"]) & TABLE.GO.CUT.pp[,"User"]!="Gene-List" & TABLE.GO.CUT.pp[,"User"]!="Path-List",]
   				TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,COL.Ngenes.GoTo.PLOT]) & as.numeric(TABLE.GO.CUT.pp[,COL.Ngenes.GoTo.PLOT])>=MIN.Num.Genes.to_plot.barcodeplot.pp,]
   				##################
   				if(nrow(TABLE.GO.CUT.pp)>0 & barcodeplot.update.plot.pp==1) {
   					TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[order(as.numeric(TABLE.GO.CUT.pp[,"pvalue.A"]),decreasing=FALSE),];  
   					TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[1,]
   					########
   					COL.pavlue.USE.pp = TABLE.GO.CUT.pp[1,"pvalue.A"];
   				}
   				if(nrow(TABLE.GO.CUT.pp)>0 & barcodeplot.update.plot.pp==0) {
   					TABLE.GO.CUT.pp[,"XX.pavlues"]=1;   TABLE.GO.CUT.pp[,"XX.Col.use"]=1
   					for(COL.pp in c(COL.pavlue.P.Up.pp,COL.pavlue.P.Down.pp,COL.pavlue.P.DE.pp)) {
   						TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,COL.pp]) & as.numeric(TABLE.GO.CUT.pp[,COL.pp])<as.numeric(TABLE.GO.CUT.pp[,"XX.pavlues"]),"XX.Col.use"]= COL.pp
   						TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,COL.pp]) & as.numeric(TABLE.GO.CUT.pp[,COL.pp])<as.numeric(TABLE.GO.CUT.pp[,"XX.pavlues"]),"XX.pavlues"]=
   						TABLE.GO.CUT.pp[!is.na(TABLE.GO.CUT.pp[,COL.pp]) & as.numeric(TABLE.GO.CUT.pp[,COL.pp])<as.numeric(TABLE.GO.CUT.pp[,"XX.pavlues"]),   COL.pp   ]
   					}
   					TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[order(as.numeric(TABLE.GO.CUT.pp[,"XX.pavlues"]),decreasing=FALSE),];  
   					TABLE.GO.CUT.pp= TABLE.GO.CUT.pp[1,]
   					########
   					COL.pavlue.USE.pp = TABLE.GO.CUT.pp[1,"XX.Col.use"];
   					########
   					#print(head(TABLE.GO.CUT.pp[,c("XX.pavlues","XX.Col.use","Ngenes.GoTo",COL.pavlue.P.Up.pp,COL.pavlue.P.Down.pp,COL.pavlue.P.DE.pp, "Pathway")]),3);  print(min(as.numeric(TABLE.GO.CUT.pp[,"XX.pavlues"])));
			}	}
			##################
			if(nrow(TABLE.GO.CUT.pp)>0) {
				ROWS.TO.PLOT.pp= min(c(nrow(TABLE.GO.CUT.pp),MAX.number.plots.barcodeplot.PLOT));  #print("###jajaj");  print(CASE.pp);  print(CASE.Model);
				##########
				## print("");  print(ROWS.TO.PLOT.pp);  print(nrow(TABLE.GO.CUT.pp));  print(head(TABLE.GO.CUT.pp,2)); print("");
				if(ROWS.TO.PLOT.pp>0) for(RR.pp in c(1:ROWS.TO.PLOT.pp)) {  ## RR.pp=1
					####################
					GENES.PLOT.pp= unlist(strsplit(TABLE.GO.CUT.pp[RR.pp,COl.GENES.GO.barcodeplot.pp], ",", fixed=TRUE))
					##########
					WAR..TXT.pp= "";  if(length(GENES.PLOT.pp)>MAX.Num.Genes.to_plot.barcodeplot.pp){ GENES.PLOT.pp= GENES.PLOT.pp[1:MAX.Num.Genes.to_plot.barcodeplot.pp];    WAR..TXT.pp="  --> WAR" }
					####################
					COL.Term.Pathway.pp= "Pathway";   TXT.gonna.or.kkeg.pp= "error";   if(CASE.pp==11) TXT.gonna.or.kkeg.pp= "Pathway List";   if(CASE.pp==10) TXT.gonna.or.kkeg.pp= "Gene List"
					if(length(grep("GO:"  ,TABLE.GO.CUT.pp[RR.pp,COl.GENES.barcodeplot.pp],fixed=TRUE))>0) TXT.gonna.or.kkeg.pp= "Gene Ontology"
					if(length(grep("path:",TABLE.GO.CUT.pp[RR.pp,COl.GENES.barcodeplot.pp],fixed=TRUE))>0) TXT.gonna.or.kkeg.pp= "KEGG";
					####################
					if(barcodeplot.update.plot.pp==0) {
						if(CASE.pp==100 | CASE.pp==11) TXT..FIL2.pp= TABLE.GO.CUT.pp[1,"UP.DOWN"];
						if(CASE.pp==11) {
							if(TABLE.GO.CUT.pp[RR.pp,"UP.DOWN"]=="up"   ) COL.pavlue.USE.pp= COL.pavlue.P.Up.pp;		if(TABLE.GO.CUT.pp[RR.pp,"UP.DOWN"]=="down") COL.pavlue.USE.pp= COL.pavlue.P.Down.pp
							if(TABLE.GO.CUT.pp[RR.pp,"UP.DOWN"]=="geneN") COL.pavlue.USE.pp= COL.pavlue.P.DE.pp;		
					}	}
					#################### 
					TXT.user.yes="";  if(CASE.pp==11) TXT.user.yes="Special:  ";  #if(barcodeplot.update.plot.pp==1 & CASE.pp==8) TXT.user.yes=paste(TXT.gonna.or.kkeg.pp,": ",sep="");
					##########
					MAIN.title1.barcode.pp= paste(TXT.user.yes,TABLE.GO.CUT.pp[RR.pp,COl.GENES.barcodeplot.pp]," --> ",TABLE.GO.CUT.pp[RR.pp,COL.Term.Pathway.pp], sep="")
					MAIN.title1.barcode.pp= strtrim(MAIN.title1.barcode.pp, MAX.characters.TITLE.barcodeplot.pp)
					CEX.MAIN= 1;  if(nchar(MAIN.title1.barcode.pp)>80) CEX.MAIN= 0.9;  if(nchar(MAIN.title1.barcode.pp)>200) CEX.MAIN= 0.8
					##########
					TXT.CASE.Model.pp= paste(";   ",CASE.Model,sep="");  if(length(Plot.ONLY.Cases.PLOT)>0) TXT.CASE.Model.pp=""
					TXT.up.down.GeneN.pp= "gene enrichment";  if(TXT..FIL2.pp=="down") TXT.up.down.GeneN.pp= "down-regulated";  if(TXT..FIL2.pp=="up") TXT.up.down.GeneN.pp= "up-regulated";   
					##########
					TXT.Algorithms.pp= paste(";   Soft=",TABLE.GO.CUT.pp[RR.pp,paste(TXT.Test.MAIN..PP, test_run.pp.PLOT,".S",sep="")],";   Alg=", TABLE.GO.CUT.pp[RR.pp,paste(TXT.Test.MAIN..PP, test_run.pp.PLOT,".A",sep="")],TXT.CASE.Model.pp, sep="") 
					MAIN.title2.barcode.pp= paste(TXT.gonna.or.kkeg.pp, "  (",TXT.up.down.GeneN.pp,",   pvalue < ",format(as.numeric(TABLE.GO.CUT.pp[RR.pp,COL.pavlue.USE.pp]),digits = 2,nsmall=2),TXT.Algorithms.pp,")",WAR..TXT.pp,sep="")
					
					######################################## new update (join results) 
					if(barcodeplot.update.plot.pp==1) {
						pvalue.VEC.TXT.pp= c();  
						if(as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.Down.All"])>=0 & as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.Down.All"])<=0.05) pvalue.VEC.TXT.pp= c(pvalue.VEC.TXT.pp, paste( "down (p<",format(as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.Down.All"]),digits = 2,nsmall=2),")",sep=""))
						if(as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.Up.All"  ])>=0 & as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.Up.All"  ])<=0.05) pvalue.VEC.TXT.pp= c(pvalue.VEC.TXT.pp, paste(   "up (p<",format(as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.Up.All"  ]),digits = 2,nsmall=2),")",sep=""))
						if(as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.DE.All"  ])>=0 & as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.DE.All"  ])<=0.05) pvalue.VEC.TXT.pp= c(pvalue.VEC.TXT.pp, paste("geneN (p<",format(as.numeric(TABLE.GO.CUT.pp[RR.pp,"P.DE.All"  ]),digits = 2,nsmall=2),")",sep=""))
						if(length(pvalue.VEC.TXT.pp)<=0) pvalue.VEC.TXT.pp= "no pvalue" else {
							pvalue.VEC.TXT.pp= paste(pvalue.VEC.TXT.pp, collapse=";  ")
							pvalue.VEC.TXT.pp= sub("down","down-regulated",pvalue.VEC.TXT.pp,fixed=TRUE);   pvalue.VEC.TXT.pp= sub("up","up-regulated",pvalue.VEC.TXT.pp,fixed=TRUE);   pvalue.VEC.TXT.pp= sub("geneN","gene enrichment",pvalue.VEC.TXT.pp,fixed=TRUE) 
						}
						###############
						MAIN.title2.barcode.pp= paste(pvalue.VEC.TXT.pp, TXT.CASE.Model.pp, WAR..TXT.pp,sep="") 
					}
					########################################  
					#print("jkajja"); print(TABLE.GO.CUT.pp[RR.pp,]);  print(COL.pavlue.USE.pp);  print(RR.pp);  print("")
					##########
					MAIN.title.barcode.pp= c(MAIN.title1.barcode.pp, MAIN.title2.barcode.pp);     PVALUE..TXT.pp= as.numeric(TABLE.GO.CUT.pp[RR.pp,COL.pavlue.USE.pp]);   PVALUE..TXT.pp= PVALUE..TXT.pp[!is.na(PVALUE..TXT.pp)];  if(length(PVALUE..TXT.pp)<=0) PVALUE..TXT.pp=1
					#if((CASE.pp==10) | (CASE.pp==11 & PVALUE..TXT.pp<0)) MAIN.title.barcode.pp= paste(MAIN.title1.barcode.pp, TXT.CASE.Model.pp)
					##########
					TABLE.Barcode.pp= TABLE.Plot.bar.Inp
					ind.barcode.pp1 = match(as.character(GENES.PLOT.pp),as.character(TABLE.Barcode.pp[,"Raw.geneID"]));   if(length(ind.barcode.pp1[is.na(ind.barcode.pp1)])>0){ print(paste("MAIN error, matching RawPro.gene with NA --> ind.barcode  -->",length(ind.barcode.pp1[is.na(ind.barcode.pp1)]) )); stop(MAIN.title.barcode.pp) }
					TABLE.Barcode.pp= TABLE.Barcode.pp[ind.barcode.pp1,];
					TABLE.Barcode.pp= TABLE.Barcode.pp[order(as.numeric(TABLE.Barcode.pp[,COL.logFC]), decreasing = TRUE),];
					####################
					Print.ALL.Genes.pp= c(0,1)[1];  Filer.NO.PASS.pp= c(0,1)[1];    LOg.CUT.SYM.pp= c(1.48, RNAseq..Figure..MIN.log2.fold)[2];    if(TABLE.GO.CUT.pp[RR.pp, "User" ]=="Gene-List"){ LOg.CUT.SYM.pp= c(1.48, RNAseq..Figure..MIN.log2.fold)[2];  Filer.NO.PASS.pp= c(0,1)[2] }
					XX.title.barcode.pp= FFF.RNAseq..XLAB.barcode(TABLE.Barcode.pp, LOg.CUT.SYM.pp, COL.logFC, MAX.characters.we.can.plot.pp, TABLE.GO.CUT.pp[RR.pp,COL.TNgenes.GoTo.PLOT], Filer.NO.PASS.pp, Print.ALL.Genes.pp)
					##########  
					XLAB.barcode.pp= XX.title.barcode.pp[1];	Sub.title.barcode.pp= XX.title.barcode.pp[2];	 UP.DOWN.length.pp= as.integer(XX.title.barcode.pp[3]) 
					########## 
					if(UP.DOWN.length.pp>=3) run.plot.bar.pp= 1 else run.plot.bar.pp= 0;  #print(paste(" UP.DOWN.length.pp -->", UP.DOWN.length.pp ))
					##########
					if(nchar(Sub.title.barcode.pp)>MAX.characters.we.can.plot.pp) Sub.title.barcode.pp= paste(strtrim(Sub.title.barcode.pp,(MAX.characters.we.can.plot.pp-13) ),"........etc.",sep="")
					CEX.SUB.pp= 0.9;  if(UP.DOWN.length.pp>13) CEX.SUB.pp= 0.75;  if(UP.DOWN.length.pp>17) CEX.SUB.pp= 0.65;  if(UP.DOWN.length.pp>30) CEX.SUB.pp= 0.5;  if(UP.DOWN.length.pp>40) CEX.SUB.pp= 0.45
					####################
					#################### correction (plotting genes up and down) 
					####################
					COLNAMES.TABLE.Plot.Barcode..UU= colnames(TABLE.Plot.bar.Inp);   COL.FILETERS.pp= COLNAMES.TABLE.Plot.Barcode..UU[grep("Filters.",COLNAMES.TABLE.Plot.Barcode..UU,fixed=TRUE)];  
					if(length(COL.FILETERS.pp)>0 & nrow(TABLE.Plot.bar.Inp)>0 & TABLE.GO.CUT.pp[RR.pp,"User"]=="Gene-List"){
						TABLE.Plot.Barcode2= TABLE.Plot.bar.Inp
						TABLE.Plot.Barcode2[TABLE.Plot.Barcode2[,COL.FILETERS.pp[1]]=="NOT PASS" & as.numeric(TABLE.Plot.Barcode2[,COL.logFC])>=  LOg.CUT.SYM.pp, COL.logFC]=  1;
						TABLE.Plot.Barcode2[TABLE.Plot.Barcode2[,COL.FILETERS.pp[1]]=="NOT PASS" & as.numeric(TABLE.Plot.Barcode2[,COL.logFC])<= -LOg.CUT.SYM.pp, COL.logFC]= -1;
						ind.barcode.pp2= match(as.character(GENES.PLOT.pp),as.character(TABLE.Plot.Barcode2[,"Raw.geneID"]));   if(length(ind.barcode.pp2[is.na(ind.barcode.pp2)])>0) stop("MAIN error, matching RawPro.gene with NA --> ind.barcode")
					} else {
					  ##TABLE.Plot.Barcode2= TABLE.Plot.bar.Inp[as.numeric(TABLE.Plot.bar.Inp[,COL.logFC])>= min(as.numeric(TABLE.Barcode.pp[,COL.logFC])) & as.numeric(TABLE.Plot.bar.Inp[,COL.logFC])<= max(as.numeric(TABLE.Barcode.pp[,COL.logFC])),]
						TABLE.Plot.Barcode2= TABLE.Plot.bar.Inp
				  		ind.barcode.pp2    = match(as.character(GENES.PLOT.pp),as.character(TABLE.Plot.Barcode2[,"Raw.geneID"]));   if(length(ind.barcode.pp2[is.na(ind.barcode.pp2)])>0) stop("MAIN error, matching RawPro.gene with NA --> ind.barcode")
					}
					##########
					if(run.plot.bar.pp==0) barcodeplot(as.numeric(TABLE.Plot.bar.Inp [,COL.logFC]), index = ind.barcode.pp1, main=MAIN.title.barcode.pp, xlab=XLAB.barcode.pp, cex.main=CEX.MAIN, cex.lab=1, quantiles= c(-LOg.CUT.SYM.pp,LOg.CUT.SYM.pp));
					if(run.plot.bar.pp==1) barcodeplot(as.numeric(TABLE.Plot.Barcode2[,COL.logFC]), index = ind.barcode.pp2, main=MAIN.title.barcode.pp, xlab=XLAB.barcode.pp, cex.main=CEX.MAIN, cex.lab=1, quantiles= c(-LOg.CUT.SYM.pp,LOg.CUT.SYM.pp));
					if(run.plot.bar.pp==2) barcodeplot(as.numeric(TABLE.Plot.Barcode2[,COL.logFC]), index = ind.barcode.pp2, main=MAIN.title.barcode.pp, xlab=XLAB.barcode.pp, cex.main=CEX.MAIN, cex.lab=1);         
					                     # barcodeplot(as.numeric(TABLE.Barcode.pp   [,COL.logFC]), index = c(1:nrow(TABLE.Barcode.pp)), main=MAIN.title.barcode.pp, xlab=XLAB.barcode.pp, cex.main=CEX.MAIN, cex.lab=1)
					                     ##########    
					title(sub = Sub.title.barcode.pp, cex.sub=CEX.SUB.pp )
					##########
					#barcodeplot(as.numeric(TABLE.Barcode.pp[,COL.logFC]), main=MAIN.title.barcode.pp, xlab=XLAB.barcode.pp, cex.main=CEX.MAIN, cex.lab=1)
					#title(sub = Sub.title.barcode.pp, cex.sub=0.5)
				  ##barcodeplot(as.numeric(TABLE.Barcode.pp$logFC), ind.barcode[[1]], main=names(ind.barcode)[1])
	              ##barcodeplot(res_edgeR_qlf$table$logFC, index[[1]], index[[2]])
	}	}	}	}

	######################################## heatmap (DESeq2, see manual) { pdf(FILE.test);    ##  dev.off();  
	########################################
	if(CASE.Model=="DESeq2") if(CASE.PLOT=="heatmap4" | CASE.PLOT=="heatmap5") if(length(MAIN.FIGURE.heatmap4)>0 | length(MAIN.FIGURE.heatmap5)>0) {
		##########			
		DESeq2..Columns.Order.xx  = paste("logFC"  ,Use.Col.Max.Mean.PLOT,sep="")
		DESeq2..Columns.Filters.xx= paste("Filters",Use.Col.Max.Mean.PLOT,sep="")
		DESeq2..NNN_genes_plot.xx = 25

		####################
		TABLE.ALL.JOIN.plot[,"gene.PLOT**"]= TABLE.ALL.JOIN.plot[,"gene.PLOT"]
		TABLE.ALL.JOIN.plot[TABLE.ALL.JOIN.plot[,DESeq2..Columns.Filters.xx]==""   ,"gene.PLOT**"]=paste("**",TABLE.ALL.JOIN.plot[TABLE.ALL.JOIN.plot[,DESeq2..Columns.Filters.xx]==""   ,"gene.PLOT**"],sep="")
		TABLE.ALL.JOIN.plot[TABLE.ALL.JOIN.plot[,DESeq2..Columns.Filters.xx]=="LOW","gene.PLOT**"]=paste("*" ,TABLE.ALL.JOIN.plot[TABLE.ALL.JOIN.plot[,DESeq2..Columns.Filters.xx]=="LOW","gene.PLOT**"],sep="")
		
		#################### Heatmap of the sample-to-sample distances  
		####################
		if(CASE.PLOT=="heatmap4" & length(MAIN.FIGURE.heatmap4)>0) {
			MAIN.heatmap.Deseq2.x= paste("Heatmap of the sample-to-sample distances  (",nrow(TABLE.ALL.JOIN.plot),")",sep="");     ##MAIN.heatmap.Deseq2.x= MAIN.FIGURE.heatmap4
			######
			##Desq2..vsd = vst(dge_DESeq2, blind=FALSE)
			Desq2..sampleDists.x = dist(t(assay(Desq2..vsd)))
			Desq2..sampleDistMatrix.x = as.matrix(Desq2..sampleDists.x)
			rownames(Desq2..sampleDistMatrix.x) = paste(Desq2..vsd$condition, Desq2..vsd$type, sep="-");     ##colnames(Desq2..sampleDistMatrix.x) = NULL
			Desq2..colors.x = colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
			######
			pheatmap(Desq2..sampleDistMatrix.x, clustering_distance_rows=Desq2..sampleDists.x, clustering_distance_cols=Desq2..sampleDists.x, col=Desq2..colors.x, main = MAIN.heatmap.Deseq2.x)
			######
			rm(Desq2..sampleDists.x, Desq2..sampleDistMatrix.x, Desq2..colors.x, MAIN.heatmap.Deseq2.x) 
		}
		#################### Heatmap of the count matrix 
		####################
		if(CASE.PLOT=="heatmap5" & length(MAIN.FIGURE.heatmap5)>0){  
			################ 
			PLOT_GENES..VEC.xx= unique(c("Auto",RNAseq..Heatmap..PLOT_GENES..VEC));   XXX.COLNAMES.JOIN.x= colnames(TABLE.ALL.JOIN.plot)
			######
			if(nrow(TABLE.ALL.JOIN.plot)>0) for(gene.PLOT.xxx in PLOT_GENES..VEC.xx){  ## VOL.PLOT=COl.Special.gene.List.pppp[1]
				################
				select.genes.xx= c();    TXT.MAIN.xx= gene.PLOT.xxx;   
				######
				if(gene.PLOT.xxx=="Auto"){
					###### 
					TEMP.DESeq2.xx= TABLE.ALL.JOIN.plot
					###### 
					TEMP.DESeq2.xxF= TEMP.DESeq2.xx[!is.na(TEMP.DESeq2.xx[,"type.gene.PLOT"]) & TEMP.DESeq2.xx[,"type.gene.PLOT"]=="protein_coding",]
					if(nrow(TEMP.DESeq2.xxF)>DESeq2..NNN_genes_plot.xx) TEMP.DESeq2.xx= TEMP.DESeq2.xxF;  rm(TEMP.DESeq2.xxF);  ##table(TEMP.DESeq2.xx[,"type.gene.PLOT"])
					######
					TEMP.DESeq2.xxP= TEMP.DESeq2.xx[!is.na(TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]) &  TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]=="",]
					TEMP.DESeq2.xxL= TEMP.DESeq2.xx[!is.na(TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]) & (TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]=="" | TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]=="LOW"),]
					if(nrow(TEMP.DESeq2.xxP)>=DESeq2..NNN_genes_plot.xx) TEMP.DESeq2.xx= TEMP.DESeq2.xxP else
					if(nrow(TEMP.DESeq2.xxL)>=DESeq2..NNN_genes_plot.xx) TEMP.DESeq2.xx= TEMP.DESeq2.xxL;  rm(TEMP.DESeq2.xxP, TEMP.DESeq2.xxL) 
					###### 	
					### select = order(rowMeans(counts(dge_DESeq2,normalized=TRUE)), decreasing=TRUE)[1:20]
					select1.xx= TEMP.DESeq2.xx[order(as.numeric(TEMP.DESeq2.xx[,DESeq2..Columns.Order.xx]), decreasing = TRUE ),][c(1:DESeq2..NNN_genes_plot.xx),"RawPro.gene"]
					select2.xx= TEMP.DESeq2.xx[order(as.numeric(TEMP.DESeq2.xx[,DESeq2..Columns.Order.xx]), decreasing = FALSE),][c(1:DESeq2..NNN_genes_plot.xx),"RawPro.gene"]
					select.genes.xx= paste(unique(c(select1.xx,select2.xx)));  rm(select1.xx,select2.xx, TEMP.DESeq2.xx);    TXT.MAIN.xx= "Join results"
					###### 
					### TEMP.DESeq2.xx[paste(select.genes.xx),c(DESeq2..Columns.Order.xx,"gene.PLOT")]
				}
				if(gene.PLOT.xxx!="Auto"){ 
					if(length(XXX.COLNAMES.JOIN.x[XXX.COLNAMES.JOIN.x==gene.PLOT.xxx])<=0) stop("MAIN ERROR  ---> length(XXX.COLNAMES.JOIN.x[XXX.COLNAMES.JOIN.x==gene.PLOT.xxx])<=0")
					TEMP.DESeq2.xx= TABLE.ALL.JOIN.plot[TABLE.ALL.JOIN.plot[,gene.PLOT.xxx]!="",];  N.ORG.select.genes= nrow(TEMP.DESeq2.xx)
					if(nrow(TEMP.DESeq2.xx)>=MAX..GENES.PLOT | RNAseq..DESeq2..FORCE.Run.Filters..Heatplot==1){
						TEMP.DESeq2.xxP= TEMP.DESeq2.xx[!is.na(TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]) &  TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]=="",]
						TEMP.DESeq2.xxL= TEMP.DESeq2.xx[!is.na(TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]) & (TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]=="" | TEMP.DESeq2.xx[,DESeq2..Columns.Filters.xx]=="LOW"),]
						if(nrow(TEMP.DESeq2.xxL)>=MAX..GENES.PLOT) TEMP.DESeq2.xx= TEMP.DESeq2.xxP else
						if(nrow(TEMP.DESeq2.xxL)>=    5          ) TEMP.DESeq2.xx= TEMP.DESeq2.xxL;  rm(TEMP.DESeq2.xxP, TEMP.DESeq2.xxL) 
					 }
					 select.genes.xx= paste(unique(TEMP.DESeq2.xx[order(as.numeric(TEMP.DESeq2.xx[,DESeq2..Columns.Order.xx]), decreasing = FALSE),][,"RawPro.gene"]));  rm(TEMP.DESeq2.xx)  
				}
				################ Heatmap of the count matrix 
				##print(paste(gene.PLOT.xxx, "         ",length(select.genes.xx) ));   ##print(dim(TABLE.ALL.JOIN.plot));   print(dim(TABLE.ALL.JOIN.plot));   
				if(length(select.genes.xx)>1){ 
					######
					GENE.heatmap.Deseq2.x= paste(TXT.MAIN.xx, "   (genes= ",length(select.genes.xx),")",sep=""); 
					if(gene.PLOT.xxx!="Auto") if(length(select.genes.xx)!=N.ORG.select.genes) GENE.heatmap.Deseq2.x= paste(TXT.MAIN.xx, "   (genes= ",N.ORG.select.genes," - ",length(select.genes.xx),")",sep="")
					######
					##Desq2..vsd = vst(dge_DESeq2, blind=FALSE)
					Desq2..df.x  = as.data.frame(colData(dge_DESeq2)[,c("condition","Test")])
					DESeq2.PLOT.heat.xx= assay(Desq2..vsd)[select.genes.xx,]; 
					###
					ROW.NAMES.PLOt.xx= unique(TABLE.ALL.JOIN.plot[select.genes.xx,"gene.PLOT**"]);   if(length(ROW.NAMES.PLOt.xx)!=nrow(DESeq2.PLOT.heat.xx)) stop("MAIN ERROR --> length(ROW.NAMES.PLOt.xx)!=nrow(DESeq2.PLOT.heat.xx)")
					rownames(DESeq2.PLOT.heat.xx)= ROW.NAMES.PLOt.xx
					######
					Desq2..fontsize.xx= 10;  if(length(select.genes.xx)>40) Desq2..fontsize.xx= 8;   if(length(select.genes.xx)>60) Desq2..fontsize.xx= 7;   if(length(select.genes.xx)>80) Desq2..fontsize.xx= 6;   if(length(select.genes.xx)>100) Desq2..fontsize.xx= 5;   
					if(length(select.genes.xx)>150) Desq2..fontsize.xx= 4;   if(length(select.genes.xx)>200) Desq2..fontsize.xx= 3;   if(length(select.genes.xx)>300) Desq2..fontsize.xx= 2;   if(length(select.genes.xx)>500) Desq2..fontsize.xx= 1
					######
					#pheatmap(DESeq2.PLOT.heat.xx, cluster_rows=FALSE, show_rownames=TRUE, cluster_cols=TRUE , annotation_col=Desq2..df.x, main = GENE.heatmap.Deseq2.x)
					pheatmap(DESeq2.PLOT.heat.xx, cluster_rows=FALSE, show_rownames=TRUE, cluster_cols=FALSE, annotation_col=Desq2..df.x, main = GENE.heatmap.Deseq2.x, fontsize_row = Desq2..fontsize.xx)
					######
					rm(select.genes.xx, Desq2..df.x, DESeq2.PLOT.heat.xx, ROW.NAMES.PLOt.xx)
	}	}	}	}

	#########################
	XX.Heatmap..PLOT_GENES..Project.VEC= "Auto"
	if(CASE.PLOT=="heatmap2") XX.Heatmap..PLOT_GENES..Project.VEC= unique(c(RNAseq..Heatmap..PLOT_GENES..VEC,"Auto"))
	if(CASE.PLOT=="heatmap1" & length(Plot.ONLY.Cases.PLOT)>0) XX.Heatmap..PLOT_GENES..Project.VEC= RNAseq..Heatmap..PLOT_GENES..VEC
	#####
	if(nrow(TABLE.Plot)>0 & RUn.Join.Alg.plots.pp==0) if(CASE.PLOT=="heatmap1" | CASE.PLOT=="heatmap2" | CASE.PLOT=="heatmap3") for(Heatmap..PLOT_GENES..pp in XX.Heatmap..PLOT_GENES..Project.VEC){
		#####
		MAIN.FIGURE.heatmap1..USE= MAIN.FIGURE.heatmap1;    MAIN.FIGURE.heatmap2..USE= MAIN.FIGURE.heatmap2;   MAIN.FIGURE.heatmap3..USE= MAIN.FIGURE.heatmap3;
		#####
		if(Heatmap..PLOT_GENES..pp=="Auto") {
			TABLE.heatmap.O= TABLE.Plot
			TABLE.heatmap= TABLE.heatmap.O[TABLE.heatmap.O[,"YES.pvalue"]>=3,]
			if(nrow(TABLE.heatmap)<MAX..GENES.PLOT) TABLE.heatmap= TABLE.heatmap.O[TABLE.heatmap.O[,"YES.pvalue"]>=2,]
			if(nrow(TABLE.heatmap)<MAX..GENES.PLOT) TABLE.heatmap= TABLE.heatmap.O[TABLE.heatmap.O[,"YES.pvalue"]>=1,]
			if(nrow(TABLE.heatmap)<MAX..GENES.PLOT) TABLE.heatmap= TABLE.heatmap.O
			#####
			TABLE.heatmap= TABLE.heatmap.O[order(abs(as.numeric(TABLE.heatmap.O[,COL.logFC])), decreasing = TRUE),];
			#####
			MAX.TEST= min(c(nrow(TABLE.heatmap), MAX..GENES.PLOT));    TABLE.heatmap= TABLE.heatmap[c(1:MAX.TEST),];    TABLE.heatmap= TABLE.heatmap[order(as.numeric(TABLE.heatmap[,COL.logFC]), decreasing = TRUE),];
		} else {
			##########
			TABLE.heatmap.O= TABLE.Plot;    #print(colnames(TABLE.Plot));    print(Heatmap..PLOT_GENES..pp)
			TABLE.heatmap= TABLE.heatmap.O[TABLE.heatmap.O[,Heatmap..PLOT_GENES..pp]=="XX",]
			#####
			if(length(MAIN.FIGURE.heatmap1)>0) MAIN.FIGURE.heatmap1..USE= paste(Heatmap..PLOT_GENES..pp,"  (",nrow(TABLE.heatmap),")  -->",CASE.Model,sep="");
			if(length(MAIN.FIGURE.heatmap2)>0) MAIN.FIGURE.heatmap2..USE= paste(Heatmap..PLOT_GENES..pp,"  (",nrow(TABLE.heatmap),")",sep="");    
		}
		#####
		#print(paste(" Plotting HeatPlot ---> Gene Column --->", Heatmap..PLOT_GENES..pp,"       rows=", nrow(TABLE.heatmap) ))
		#####
		MM.Plot= match(TABLE.heatmap[,"RawPro.gene"],Counts.PLOT[,"RawPro.gene"]);  if(length(MM.Plot[is.na(MM.Plot)])>0) stop("MAIN error, matching RawPro.gene with NA --> MM.Plot")
		Counts.heatmap= Counts.PLOT[MM.Plot,];    rownames(Counts.heatmap)= Counts.heatmap[,"gene.PLOT"];    colnames(Counts.heatmap)= c(COL.SAMPELS.Lib..PLOT,"gene.PLOT") 
		#####
		##Counts.heatmap;  TABLE.heatmap     ##### select.FULL.PLOT= as.character(TABLE.heatmap[,"RawPro.gene"]);  Counts.heatmap= Counts.PLOT[select.FULL.PLOT,]; 
		#############
		##palettes.names.PLOT1= "GnBu"  ## Default
		##palettes.names.PLOT1= c("Blues","BuGn","BuPu","GnBu","Greens","Greys","Oranges","OrRd","PuBu","PuBuGn","PuRd","Purples","RdPu","Reds","YlGn","YlGnBu","YlOrBr","YlOrRd")[18]
		##########
		RNAseq..Heatplot..COLORS..PLOT= 0;  if(exists("RNAseq..Heatplot..COLORS")) RNAseq..Heatplot..COLORS..PLOT= RNAseq..Heatplot..COLORS
		########## 
		palettes.names.PLOT1= c("YlOrRd","RdYlBu")[1];    		hmcol.PLOT1= colorRampPalette(brewer.pal(9, palettes.names.PLOT1))(MAX..GENES.PLOT)
		palettes.names.PLOT2= "Reds";							hmcol.PLOT2= colorRampPalette(brewer.pal(9, palettes.names.PLOT2))(MAX..GENES.PLOT)
		palettes.names.PLOT3= "Oranges"; 						hmcol.PLOT3= colorRampPalette(brewer.pal(9, palettes.names.PLOT3))(MAX..GENES.PLOT)
		palettes.names.PLOT4= "OrRd";							hmcol.PLOT4= colorRampPalette(brewer.pal(9, palettes.names.PLOT4))(MAX..GENES.PLOT)
		palettes.names.PLOT5= "PuRd"; 							hmcol.PLOT5= colorRampPalette(brewer.pal(9, palettes.names.PLOT5))(MAX..GENES.PLOT)
		######
		if(Heatmap..PLOT_GENES..pp!="Auto"){
			palettes.names.PLOT1= "RdYlBu";    	hmcol.PLOT1= colorRampPalette(brewer.pal(9, palettes.names.PLOT1))(MAX..GENES.PLOT)		## project Ye
		}
		####################
		ERROR.00.COL=c();  for(YYrr in COL.SAMPELS.Lib..PLOT) if(sum(abs(as.numeric(Counts.heatmap[,YYrr])))==0) ERROR.00.COL=c(ERROR.00.COL,YYrr)
		if(length(ERROR.00.COL)>0) {
			print(paste("waring ===> only 0 in this column --. adding 1 in one row -->", length(ERROR.00.COL) ))
			Counts.heatmap[1,ERROR.00.COL]= 1
		}
		####################
		par(cex.main=0.8)
		####################
		if(CASE.PLOT=="heatmap1" & length(MAIN.FIGURE.heatmap1..USE)>0) {
			#print("jajaj6");  print(Counts.heatmap[,COL.SAMPELS.Lib..PLOT])
			#heatmap  (as.matrix(    Counts.heatmap[,COL.SAMPELS.Lib..PLOT]),                            col = hmcol.PLOT1, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap1..USE, labRow = FALSE, labCol = FALSE)
			#heatmap.2(as.matrix(    Counts.heatmap[,COL.SAMPELS.Lib..PLOT])                                              , trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap1..USE) 
			#heatmap.2(as.matrix(    Counts.heatmap[,COL.SAMPELS.Lib..PLOT])                           , col = hmcol.PLOT1, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap1..USE)
			#heatmap.2(as.matrix(cpm(Counts.heatmap[,COL.SAMPELS.Lib..PLOT]), prior.count=2, log=TRUE ), col = hmcol.PLOT2, trace="none", margin=c(10,7), main=MAIN.FIGURE.heatmap1..USE, cexRow=0.80, cexCol=0.80, cex.main = 0.80)
			#heatmap.2(as.matrix(cpm(Counts.heatmap[,COL.SAMPELS.Lib..PLOT]), prior.count=2, log=TRUE ), col = hmcol.PLOT3, trace="none", margin=c(10,7), main=MAIN.FIGURE.heatmap1..USE, cexRow=0.80, cexCol=0.80, cex.main = 0.80)
			 heatmap.2(as.matrix(cpm(Counts.heatmap[,COL.SAMPELS.Lib..PLOT]), prior.count=2, log=TRUE ), col = hmcol.PLOT1, trace="none", margin=c(10,7), main=MAIN.FIGURE.heatmap1..USE, cexRow=0.80, cexCol=0.80, cex.main = 0.80)
		}

		######################################## heatmap (DESeq1, see manual) { pdf(FILE.test);    ##  dev.off(); 
		########################################
		if(CASE.Model=="DESeq1" & 55==99) if(CASE.PLOT=="heatmap2" | CASE.PLOT=="heatmap3") if(length(MAIN.FIGURE.heatmap2..USE)>0 | length(MAIN.FIGURE.heatmap3..USE)>0)  {
			##MAX.FULL= min(c(nrow(cds.FULL.PLOT), MAX..GENES.PLOT));    #select.FULL= order(rowMeans(counts(cds.FULL.PLOT)), decreasing=TRUE)[1:MAX.FULL]
			##res.FULL.PLOT.heat= res.FULL.PLOT;     res.FULL.PLOT.heat= res.FULL.PLOT.heat[order(abs(as.numeric(res.FULL.PLOT.heat[,"log2FoldChange"]))),]
			##MAX.FULL= min(c(nrow(res.FULL.PLOT.heat), MAX..GENES.PLOT));             select.FULL= as.character(res.FULL.PLOT.heat[,"id"])[1:MAX.FULL]; 
			#####
			##### COL.SAMPELS.Lib..PLOT= paste(Targets.PLOT[,"Patient_number"]," -", Targets.PLOT[,"Test"],sep="");
			cds.FULL.PLOT = dge_PLOT;		### cds.FULL.PLOT = dge_DESeq2
			#####
			if(!exists("METHOD..DESeq...estimateSizeFactors")) METHOD..DESeq...estimateSizeFactors="Default"
			METHOD..PLOT.USE= "blind";  if(CASE.Model=="DESeq1"  | CASE.Model=="DESeq1b" | CASE.Model=="DESeq2"  | CASE.Model=="DESeq2b") if(METHOD..DESeq...estimateSizeFactors!="Default") METHOD..PLOT.USE= METHOD..DESeq...estimateSizeFactors
			cds.Blind.FULL= estimateDispersions(cds.FULL.PLOT, method= METHOD..PLOT.USE)
			#####   
			vsd.FULL= varianceStabilizingTransformation( cds.Blind.FULL );  notAllZero.FULL = (rowSums(counts(cds.FULL.PLOT))>0)
			#####
			#colnames(counts(cds.FULL.PLOT))= COL.SAMPELS.Lib..PLOT;    sampleNames(dge_PLOT)= COL.SAMPELS.Lib..PLOT
			#colnames(counts(vsd.FULL))= COL.SAMPELS.Lib..PLOT; 
			##### 
			if(CASE.PLOT=="heatmap2" & length(MAIN.FIGURE.heatmap2..USE)>0) {
				counts.heatmap2  = counts(cds.FULL.PLOT)[MM.Plot,];    colnames(counts.heatmap2  )= COL.SAMPELS.Lib..PLOT;
				vsd.FULL.heatmap2= exprs (vsd.FULL     )[MM.Plot,];    colnames(vsd.FULL.heatmap2)= COL.SAMPELS.Lib..PLOT;
				##########
				LOCO.XX= Counts.heatmap[,c(1:3)];  LOCO.XX[,1]= rownames(Counts.heatmap);  LOCO.XX[,2]= rownames(vsd.FULL.heatmap2);  
				LOCO.XX[,3]= 0;  LOCO.XX[LOCO.XX[,1]!=LOCO.XX[,2],3]= 1;   LOCO.XX= LOCO.XX[LOCO.XX[,3]==0,]
				#if(nrow(LOCO.XX)==0) rownames(vsd.FULL.heatmap2)= Counts.heatmap[,"gene.PLOT"]
				rownames(vsd.FULL.heatmap2)= Counts.heatmap[,"gene.PLOT"]
				##########
				if(Heatmap..PLOT_GENES..pp=="Auto") cexRow.USE=0.10 else cexRow.USE=0.60  
				#####
				#heatmap.2(counts.heatmap2  , col = hmcol.PLOT1, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap2..USE, cex.lab=0.75		, labRow = FALSE )
				 heatmap.2(vsd.FULL.heatmap2, col = hmcol.PLOT1, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap2..USE, cexRow=cexRow.USE, cexCol=0.80, cex.main = 0.80 )
				 if(Heatmap..PLOT_GENES..pp=="Auto")
				 heatmap.2(vsd.FULL.heatmap2, col = hmcol.PLOT1, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap2..USE, labRow = FALSE	, cexCol=0.80, cex.main = 0.80 )
				 if(RNAseq..Heatplot..COLORS..PLOT==1) {
				 heatmap.2(vsd.FULL.heatmap2, col = hmcol.PLOT2, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap2..USE, labRow = FALSE	, cexCol=0.80, cex.main = 0.80 )
				 heatmap.2(vsd.FULL.heatmap2, col = hmcol.PLOT3, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap2..USE, labRow = FALSE	, cexCol=0.80, cex.main = 0.80 )
				 heatmap.2(vsd.FULL.heatmap2, col = hmcol.PLOT4, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap2..USE, labRow = FALSE	, cexCol=0.80, cex.main = 0.80 )
				 heatmap.2(vsd.FULL.heatmap2, col = hmcol.PLOT5, trace="none", margin=c(10,6), main=MAIN.FIGURE.heatmap2..USE, labRow = FALSE	, cexCol=0.80, cex.main = 0.80 ) 
				 }
			}
			#####
			if(CASE.PLOT=="heatmap3" & length(MAIN.FIGURE.heatmap3..USE)>0) {
				dists = dist( t( exprs(vsd.FULL) ) );   mat.SS = as.matrix( dists );  rownames(mat.SS) = colnames(mat.SS) = COL.SAMPELS.Lib..PLOT
			  ##heatmap.2(mat.SS, trace="none", col = rev(hmcol.PLOT1), margin=c(13, 13), main=MAIN.FIGURE.heatmap3..USE)
				heatmap.2(mat.SS, trace="none", col = rev(hmcol.PLOT1), margin=c(10,  8), main=MAIN.FIGURE.heatmap3..USE, cexRow=0.80, cexCol=0.80, cex.main = 0.80)
				if(RNAseq..Heatplot..COLORS..PLOT==1) {
				heatmap.2(mat.SS, trace="none", col = rev(hmcol.PLOT2), margin=c(10,  8), main=MAIN.FIGURE.heatmap3..USE, cexRow=0.80, cexCol=0.80, cex.main = 0.80)
				heatmap.2(mat.SS, trace="none", col = rev(hmcol.PLOT3), margin=c(10,  8), main=MAIN.FIGURE.heatmap3..USE, cexRow=0.80, cexCol=0.80, cex.main = 0.80)
				heatmap.2(mat.SS, trace="none", col = rev(hmcol.PLOT4), margin=c(10,  8), main=MAIN.FIGURE.heatmap3..USE, cexRow=0.80, cexCol=0.80, cex.main = 0.80)
				heatmap.2(mat.SS, trace="none", col = rev(hmcol.PLOT5), margin=c(10,  8), main=MAIN.FIGURE.heatmap3..USE, cexRow=0.80, cexCol=0.80, cex.main = 0.80)
		}	}	}
		
		########################################
		########################################
		par(cex.main=1)	
		####################
		### setwd(MAIN.MAIN.DIR...MAIN.Temporal);  pdf("HeatmapPlots.pdf")
		###distsRL <- dist(t(assay(rld)))
		###hmcol <- colorRampPalette(brewer.pal(9, "GnBu"))(100)
		###heatmap.2(as.matrix(distsRL), trace="none", col = rev(hmcol), margin=c(13, 13))
		###dev.off()	
	}
	###################################	
}}
#########################
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################



#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..Plot.Path.Analysis= function(TABLE.SAVE.TOGO..RRR, FILE.PDF..Path.RRR, PLOT.GO.Kegg.VEC..Path.RRR= c("kegga","goana","both")[1], PLOT.pvalue.A.RRR= c("all","soft","join","Select")[1], Min.PVLUE..Path.RRR= c(-1, 0.05, 0.01, 0.0001)[2] ,
                                         MAX.Ngenes..Path.RRR= c(-1,100,150,200)[4], MAX..Rows..Path.RRR= c(-1, 50,100,200)[2], RNAseq..Special.PathAnalalys..Tittle.RRR= c() ){ 


### Min.PVLUE..Path.RRR = c(-1, 0.05, 0.01, 0.0001)[2];  MAX.Ngenes..Path.RRR= c(-1,100,150,200)[4];  MAX..Rows..Path.RRR= c(-1, 50,100,200)[2]
### TABLE.SAVE.TOGO..RRR= TABLE.SAVE.TOGO;    FILE.PDF..Path.RRR=TEST..PDF1.USE;   PLOT.GO.Kegg.VEC..Path.RRR= c("kegga","goana","both")[1]

################################################
VEC.USE.pavlue.RRR= c(1:4)
if(PLOT.pvalue.A.RRR=="soft") VEC.USE.pavlue.RRR= c(2:4);   if(PLOT.pvalue.A.RRR=="join") VEC.USE.pavlue.RRR= c(1);   if(PLOT.pvalue.A.RRR=="Select") VEC.USE.pavlue.RRR= c(1); 
#####
COLs.pvalue..Path.RR  = c("pvalue.A","P.Up.All","P.Down.All","P.DE.All")
COLs.Ngenes..Path.RR  = c( "genes.A",  "Up.All",  "Down.All",  "DE.All")
#####
COL..PathName..Path.RR= c("Pathway"    )[1]
COL..ID.NAME..Path.RR = c("RawPro.gene")[1]
#####
COL.LEGEND..Path.RR= c(COL..PathName..Path.RR, COL..ID.NAME..Path.RR)[1]
COL.VEC.PLOT.pvalue..RR= COLs.pvalue..Path.RR[VEC.USE.pavlue.RRR] ##[1]

#################################################################################### 
####################################################################################
if(length(PLOT.GO.Kegg.VEC..Path.RRR)<=0) stop("MAIN ERROR   -->  length(PLOT.GO.Kegg.VEC..Path.RRR)<=0")
if(length(COLs.pvalue..Path.RR      )<=0) stop("MAIN ERROR   -->  length(COLs.pvalue..Path.RR      )<=0")
if(length(COLs.Ngenes..Path.RR      )<=0) stop("MAIN ERROR   -->  length(COLs.Ngenes..Path.RR      )<=0")
#########
COL..ID.NAME..Path.RR= COL..ID.NAME..Path.RR[1];    COL..PathName..Path.RR= COL..PathName..Path.RR[1];
##################
if(nrow(TABLE.SAVE.TOGO..RRR)>0) {
	############################
	if(length(FILE.PDF..Path.RRR)>0){
		if(MAX.Ngenes..Path.RRR>0) Txt.PDF1.RR= paste("..N",MAX.Ngenes..Path.RRR,".pdf",sep="") else Txt.PDF1.RR="..ALL.pdf"
		FILE.PDF..Path.RRR1= sub(".pdf",Txt.PDF1.RR,FILE.PDF..Path.RRR,fixed=TRUE) 
		pdf(FILE.PDF..Path.RRR1);  par(mfrow=c(1,1))
	}
	
	############################ TEST to plot
    ############################
	TABLE.SAVE.TOGO..RRR[,"TEST.PLOT"]= "none"
	TABLE.SAVE.TOGO..RRR[grep("GO:"  ,TABLE.SAVE.TOGO..RRR[,COL..ID.NAME..Path.RR]),"TEST.PLOT"]="GO Terms"
	TABLE.SAVE.TOGO..RRR[grep("path:",TABLE.SAVE.TOGO..RRR[,COL..ID.NAME..Path.RR]),"TEST.PLOT"]="KEGG Terms"
	#########
	for(COL.pva.sss in COLs.pvalue..Path.RR) TABLE.SAVE.TOGO..RRR[,COL.pva.sss]= as.numeric(TABLE.SAVE.TOGO..RRR[,COL.pva.sss])
	for(COL.pva.sss in COL.VEC.PLOT.pvalue..RR) for(Test.rrr in PLOT.GO.Kegg.VEC..Path.RRR) {	
   	 	############################
		############################
		to_PLOT.Path.RR= TABLE.SAVE.TOGO..RRR[,unique(c(COL..ID.NAME..Path.RR, COL..PathName..Path.RR, COLs.pvalue..Path.RR, COLs.Ngenes..Path.RR, "TEST.PLOT", "N" ))]
		######
		if(Test.rrr=="both" ){ to_PLOT.Path.RR= to_PLOT.Path.RR[to_PLOT.Path.RR[,"TEST.PLOT"]!="none"      ,];   TXT.TEXT.US..rr= "GO and KEGG Terms"  }
		if(Test.rrr=="kegga"){ to_PLOT.Path.RR= to_PLOT.Path.RR[to_PLOT.Path.RR[,"TEST.PLOT"]=="KEGG Terms",];   TXT.TEXT.US..rr= "KEGG Terms"         }
		if(Test.rrr=="goana"){ to_PLOT.Path.RR= to_PLOT.Path.RR[to_PLOT.Path.RR[,"TEST.PLOT"]=="GO Terms"  ,];   TXT.TEXT.US..rr= "GO Terms"           }
		######
		if(nrow(to_PLOT.Path.RR)>0) to_PLOT.Path.RR= to_PLOT.Path.RR[!is.na(to_PLOT.Path.RR[,COL.pva.sss]),];
		if(nrow(to_PLOT.Path.RR)>0 & Min.PVLUE..Path.RRR >0) to_PLOT.Path.RR= to_PLOT.Path.RR[as.numeric(to_PLOT.Path.RR[,COL.pva.sss])<= Min.PVLUE..Path.RRR ,];
		if(nrow(to_PLOT.Path.RR)>0 & MAX.Ngenes..Path.RRR>0) to_PLOT.Path.RR= to_PLOT.Path.RR[as.numeric(to_PLOT.Path.RR[,   "N"     ])<= MAX.Ngenes..Path.RRR,];
		
	    ######
		if(nrow(to_PLOT.Path.RR)>0){
   			############################ PLOT.PVALUE, LOG.PVALUE, PLOT.ID.Names 
    		############################
    		to_PLOT.Path.RR[,"PLOT.PVALUE"  ]= to_PLOT.Path.RR[,COL.pva.sss]
    		to_PLOT.Path.RR[,"LOG.PVALUE"   ]= -log10(to_PLOT.Path.RR[,"PLOT.PVALUE"])
			#########
			to_PLOT.Path.RR= to_PLOT.Path.RR[order(as.numeric(to_PLOT.Path.RR[,"LOG.PVALUE"]), decreasing="TRUE"),]
			if(nrow(to_PLOT.Path.RR) > MAX..Rows..Path.RRR[1]) to_PLOT.Path.RR= to_PLOT.Path.RR[c(1:MAX..Rows..Path.RRR),]
			to_PLOT.Path.RR= to_PLOT.Path.RR[order(as.numeric(to_PLOT.Path.RR[,"LOG.PVALUE"]), decreasing="FALSE"),]
			
			############################ PLOT.ID.Names 
   			############################
   			if(COL.pva.sss=="pvalue.A") COl.N.genes="genes.A" else COl.N.genes= sub("P.","",COL.pva.sss,fixed=TRUE)
   			#if(COL.pva.sss=="pvalue.A") to_PLOT.Path.RR[,"N.GENES"]= to_PLOT.Path.RR[,"DE.All"] else to_PLOT.Path.RR[,"N.GENES"]= to_PLOT.Path.RR[,sub("P.","",COL.pva.sss,fixed=TRUE)]
   			#########
   			to_PLOT.Path.RR[,"PLOT.ID.Names"]= paste(to_PLOT.Path.RR[,COL.LEGEND..Path.RR],"  (",to_PLOT.Path.RR[,"N"]," - ",to_PLOT.Path.RR[,COl.N.genes],")",sep="") 
   			to_PLOT.Path.RR[,"PLOT.ID.Names"]= paste(to_PLOT.Path.RR[,COL.LEGEND..Path.RR],"  (",to_PLOT.Path.RR[,COL..ID.NAME..Path.RR],")",sep="") 
   			if(PLOT.pvalue.A.RRR=="Select") to_PLOT.Path.RR[,"PLOT.ID.Names"]= to_PLOT.Path.RR[,COL.LEGEND..Path.RR]
   			##to_PLOT.Path.RR[,"PLOT.ID.Names"]= to_PLOT.Path.RR[,COL.LEGEND..Path.RR]
   			
    		############################ Col.PLOT
   			############################
			to_PLOT.Path.RR[,"Col.PLOT"]= "error";   rainbow.VEC.RR= rainbow(3)
			to_PLOT.Path.RR[to_PLOT.Path.RR[,"PLOT.PVALUE"]==to_PLOT.Path.RR[,"P.Down.All"],"Col.PLOT"] =rainbow.VEC.RR[1]
			to_PLOT.Path.RR[to_PLOT.Path.RR[,"PLOT.PVALUE"]==to_PLOT.Path.RR[,"P.Up.All"  ],"Col.PLOT"] =rainbow.VEC.RR[2]
			to_PLOT.Path.RR[to_PLOT.Path.RR[,"PLOT.PVALUE"]==to_PLOT.Path.RR[,"P.DE.All"  ],"Col.PLOT"] =rainbow.VEC.RR[3] 
			if(PLOT.pvalue.A.RRR=="Select") to_PLOT.Path.RR[,"Col.PLOT"]= "grey26"
			EERROR..RR= to_PLOT.Path.RR[to_PLOT.Path.RR[,"Col.PLOT"]=="error",];  if(nrow(EERROR..RR)>0) stop("MAIN ERROR   -->  Col.PLOT")
			#########
			## head(to_PLOT.Path.RR, 10);  dim(to_PLOT.Path.RR)
			
			to_PLOT.REV1.RR= to_PLOT.Path.RR[order(as.numeric(to_PLOT.Path.RR[,"LOG.PVALUE"]), decreasing="TRUE"),]

			############################ barplot  
			############################
			if(MAX.Ngenes..Path.RRR>0) Txt.PDF2.RR= paste("(Genes < ",MAX.Ngenes..Path.RRR,")",sep="") else Txt.PDF2.RR= "(Genes = all)"
			MAIN.TITLE..Path.RR= paste("Path analysis --> ", TXT.TEXT.US..rr,"      ",Txt.PDF2.RR,"     test =", COL.pva.sss)
			MAIN.TITLE..Path.RR= paste("Path analysis --> ", TXT.TEXT.US..rr,"      ",Txt.PDF2.RR)
			if(PLOT.pvalue.A.RRR=="Select") MAIN.TITLE..Path.RR= paste("Path analysis --> ", TXT.TEXT.US..rr,"      Selection") 
			if(length(RNAseq..Special.PathAnalalys..Tittle.RRR)>0) if(RNAseq..Special.PathAnalalys..Tittle.RRR[1]!="") MAIN.TITLE..Path.RR= RNAseq..Special.PathAnalalys..Tittle.RRR[1]
			YLAB..Path.RR=  "-log10(pvalue)"
			######
            PAR.ORG.RR= par("mar")
			par(mar=c(5.1, 18.1, 1.8, 1.8));   
			######
			cex.genes.RR= 0.5;   cex.names.RR=0.5;  cex.legend.RR=0.8;  cex.main..RR = 0.8;    if(nrow(to_PLOT.Path.RR)<35){ cex.genes.RR= 0.6;   cex.names.RR=0.7  };    if(nrow(to_PLOT.Path.RR)<15){ cex.genes.RR= 0.6;   cex.names.RR=0.9  }
			######
			PLUS.RR= max(to_PLOT.Path.RR[,"LOG.PVALUE"])/7;    if(nrow(to_PLOT.Path.RR)<35) PLUS.RR= max(to_PLOT.Path.RR[,"LOG.PVALUE"])/6;    if(nrow(to_PLOT.Path.RR)<15) PLUS.RR= max(to_PLOT.Path.RR[,"LOG.PVALUE"])/5   
			XLIM..Path.RR= range(c(0,(max(to_PLOT.Path.RR[,"LOG.PVALUE"])+ 2*PLUS.RR))) 
			######
			##barplot(to_PLOT.Path.RR[,"LOG.PVALUE"], xlab=YLAB..Path.RR, horiz=TRUE, names.arg=to_PLOT.Path.RR[,"PLOT.ID.Names"], cex.names=cex.genes.RR, las = 2, col=to_PLOT.Path.RR[,"Col.PLOT"], main=MAIN.TITLE..Path.RR, cex.main=cex.main..RR, xlim=XLIM..Path.RR)
			my_bar.RR= barplot(to_PLOT.Path.RR[,"LOG.PVALUE"], xlab=YLAB..Path.RR, horiz=TRUE, names.arg=to_PLOT.Path.RR[,"PLOT.ID.Names"], cex.names=cex.names.RR, las = 2, col=to_PLOT.Path.RR[,"Col.PLOT"], main=MAIN.TITLE..Path.RR, cex.main=cex.main..RR, xlim=XLIM..Path.RR)
			#text( (1.1*to_PLOT.REV1.RR[,"LOG.PVALUE"]), c(50:1) , paste("n: ", to_PLOT.REV1.RR[,COl.N.genes], sep="") ,cex=cex.genes.RR, las = 2)
			text( rev(to_PLOT.Path.RR[,"LOG.PVALUE"] + PLUS.RR), rev(my_bar.RR), paste("Genes: ", rev(to_PLOT.Path.RR[,"N"])," - ",rev(to_PLOT.Path.RR[,COl.N.genes]), sep="") ,cex=cex.genes.RR, las = 2)
			if(PLOT.pvalue.A.RRR!="Select") legend("bottomright", legend = c("Down=Regulated","Up-Regulated","Gene-Enrichment"), cex=cex.legend.RR, bty="n", fill=rainbow(3) )
			######
			##if(min(as.numeric(to_PLOT.Path.RR[,"PLOT.PVALUE"]))>RNAseq..Pathanalysis..MultiTest.Plot)
			#abline(h=(-log10(RNAseq..Pathanalysis..MultiTest.Plot)), col="orange", lwd=3, lty=2);   
			if(PLOT.pvalue.A.RRR!="Select") if(exists("RNAseq..Pathanalysis..MultiTest.Plot")) if(length(RNAseq..Pathanalysis..MultiTest.Plot)==2){ 
				abline(v=(-log10(RNAseq..Pathanalysis..MultiTest.Plot[1])), col="orange", lwd=3, lty=2);   abline(v=(-log10(RNAseq..Pathanalysis..MultiTest.Plot[2])), col="orange", lwd=3, lty=2) 
			}
			######
			#print("jajaj Path.Analysis 1")
			par(mar=PAR.ORG.RR)
	}	}
	if(length(FILE.PDF..Path.RRR)>0){ dev.off();  print("");   print(paste("  Printing plots   --> ", FILE.PDF..Path.RRR1, "       ", date(), sep="")) }
}
############################
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..XLAB.barcode= function(GENES.SYM..UU, LOg.CUT.SYM..UU= 1.45, COL.logFC..UU= COL.logFC, MAX.characters.we.can.plot..UU, TXT.Path.barcode..UU= "Path:000 test", Filer.NO.PASS..UU= c(0,1)[1], Print.ALL.Genes..UU= c(0,1)[1] ) {

##############################
EXit.num.genes..UU=1;  increase.Cut..UU= 0.1;    
######
LOg.CUT.USE..UU= LOg.CUT.SYM..UU;  conta.while..UU= 0;  COLNAMES.GENES.SYM..UU= colnames(GENES.SYM..UU)
while(EXit.num.genes..UU==1) {
	##########
	GENES.SYM..UU[,"XX.logFC.bar"]=  0;     		GENES.SYM..UU= GENES.SYM..UU[order(as.numeric(GENES.SYM..UU[,COL.logFC..UU]), decreasing = FALSE),];   ## -> KSA=exception (decreasing = FALSE)      
	GENES.SYM..UU[as.numeric(GENES.SYM..UU[,COL.logFC..UU])<= -as.numeric(LOg.CUT.USE..UU),"XX.logFC.bar"]= -1;   
	GENES.SYM..UU[as.numeric(GENES.SYM..UU[,COL.logFC..UU])>=  as.numeric(LOg.CUT.USE..UU),"XX.logFC.bar"]=  1; 
	####
	COL.FILETERS= COLNAMES.GENES.SYM..UU[grep("Filters.",COLNAMES.GENES.SYM..UU,fixed=TRUE)];  if(length(COL.FILETERS)>0 & Filer.NO.PASS..UU==1) GENES.SYM..UU[GENES.SYM..UU[,COL.FILETERS[1]]=="NOT PASS","XX.logFC.bar"]=0;  ##print(COL.FILETERS)
	##########
	GENES.SYM.Do..UU=  GENES.SYM..UU[GENES.SYM..UU[,"XX.logFC.bar"]== -1,"gene.PLOT"]   ## GENES.SYM..UU[,c(COL.logFC..UU,"gene.PLOT")]
	GENES.SYM.Up..UU=  GENES.SYM..UU[GENES.SYM..UU[,"XX.logFC.bar"]==  1,"gene.PLOT"]
	GENES.SYM.NO..UU=  GENES.SYM..UU[GENES.SYM..UU[,"XX.logFC.bar"]==  0,"gene.PLOT"];  
	##########
	TEXT.SYM.Up..UU= "";  if(length(GENES.SYM.Up..UU)>0) TEXT.SYM.Up..UU= paste(  "Up -> ", paste(GENES.SYM.Up..UU, collapse=",")); 
	TEXT.SYM.Do..UU= "";  if(length(GENES.SYM.Do..UU)>0) TEXT.SYM.Do..UU= paste("Down -> ", paste(GENES.SYM.Do..UU, collapse=","));
	TEXT.SYM.NO..UU= "";  if(length(GENES.SYM.NO..UU)>0) TEXT.SYM.NO..UU= paste(  "ns -> ", paste(GENES.SYM.NO..UU, collapse=","));
	##########
	LOG2..TXT..UU= "";  if(conta.while..UU!=0) LOG2..TXT..UU= paste("    --> logFC>", (as.integer(LOg.CUT.USE..UU*100)/100)  )
	XLAB.barcode..UU1= paste("log fold change      [genes ==>  path (",TXT.Path.barcode..UU,");  test (",nrow(GENES.SYM..UU),");  Down (",length(GENES.SYM.Do..UU),");  ns (",length(GENES.SYM.NO..UU),");  Up (",length(GENES.SYM.Up..UU),")]", LOG2..TXT..UU, sep="")
	##########
	Sub.title.barcode..UU1= paste(TEXT.SYM.Do..UU,"      ",TEXT.SYM.NO..UU,"      ",TEXT.SYM.Up..UU, sep="")
	Sub.title.barcode..UU2= paste(TEXT.SYM.Do..UU,"      "                         ,TEXT.SYM.Up..UU, sep="")
	####################
	if(conta.while..UU==0) XLAB.barcode.MAIN0..UU1= XLAB.barcode..UU1;     
	##########
	Sub.title.barcode..USE.UU= Sub.title.barcode..UU1;      UP.DOWN.length..UU= length(GENES.SYM.Up..UU) + length(GENES.SYM.Do..UU) + length(GENES.SYM.NO..UU)			    
	if(nchar(Sub.title.barcode..USE.UU)>MAX.characters.we.can.plot..UU | conta.while..UU>0){ Sub.title.barcode..USE.UU= Sub.title.barcode..UU2;      UP.DOWN.length..UU= length(GENES.SYM.Up..UU) + length(GENES.SYM.Do..UU) }
	if(nchar(Sub.title.barcode..USE.UU)>MAX.characters.we.can.plot..UU) LOg.CUT.USE..UU = LOg.CUT.USE..UU + increase.Cut..UU else EXit.num.genes..UU=0
	if(Print.ALL.Genes..UU==1) EXit.num.genes..UU=0
	##########
	conta.while..UU= conta.while..UU + 1
}

########################################
XLAB.barcode.MAIN..UU1= paste(XLAB.barcode.MAIN0..UU1, LOG2..TXT..UU, sep="")
##########
return( c(XLAB.barcode.MAIN..UU1, Sub.title.barcode..USE.UU, UP.DOWN.length..UU ) )
} 
#########################################################################################################################################################
#########################################################################################################################################################
######################################################################################################################################################### 

#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..XLAB.barcode..OLD= function(GENES.SYM.pp, LOg.CUT.SYM.pp= 1.45, COL.logFC.pp= COL.logFC,  TXT.Path.barcode.pp= "Path:000 test") {

##############################
GENES.SYM.pp[,"XX.logFC.bar"]=  0;     											   GENES.SYM.pp= GENES.SYM.pp[order(as.numeric(GENES.SYM.pp[,COL.logFC.pp]), decreasing = FALSE),];   ## -> KSA=exception (decreasing = FALSE)      
GENES.SYM.pp[as.numeric(GENES.SYM.pp[,COL.logFC.pp])<= -as.numeric(LOg.CUT.SYM.pp),"XX.logFC.bar"]= -1;   GENES.SYM.Do.pp=  GENES.SYM.pp[GENES.SYM.pp[,"XX.logFC.bar"]== -1,"gene.PLOT"]   ## GENES.SYM.pp[,c(COL.logFC.pp,"gene.PLOT")]
GENES.SYM.pp[as.numeric(GENES.SYM.pp[,COL.logFC.pp])>=  as.numeric(LOg.CUT.SYM.pp),"XX.logFC.bar"]=  1;   GENES.SYM.Up.pp=  GENES.SYM.pp[GENES.SYM.pp[,"XX.logFC.bar"]==  1,"gene.PLOT"]
UP.DOWN.length.pppp= length(GENES.SYM.Up.pp) + length(GENES.SYM.Do.pp);			   GENES.SYM.NO.pp=  GENES.SYM.pp[GENES.SYM.pp[,"XX.logFC.bar"]==  0,"gene.PLOT"];  
##########
TEXT.SYM.Up.pp= "";  if(length(GENES.SYM.Up.pp)>0) TEXT.SYM.Up.pp= paste(  "Up -> ", paste(GENES.SYM.Up.pp, collapse=",")); 
TEXT.SYM.Do.pp= "";  if(length(GENES.SYM.Do.pp)>0) TEXT.SYM.Do.pp= paste("Down -> ", paste(GENES.SYM.Do.pp, collapse=","));
TEXT.SYM.NO.pp= "";  if(length(GENES.SYM.NO.pp)>0) TEXT.SYM.NO.pp= paste(  "ns -> ", paste(GENES.SYM.NO.pp, collapse=","));
##########
LOG2..TXT.pp= "";  if(LOg.CUT.SYM.pp>1.5) LOG2..TXT.pp= paste("  logFC>",LOg.CUT.SYM.pp)
XLAB.barcode.pp1= paste("log fold change      [genes ==>  path (",TXT.Path.barcode.pp,");  test (",nrow(GENES.SYM.pp),");  Down (",length(GENES.SYM.Do.pp),");  ns (",length(GENES.SYM.NO.pp),");  Up (",length(GENES.SYM.Up.pp),")]", LOG2..TXT.pp, sep="")
Sub.title.barcode.pp1= paste(TEXT.SYM.Do.pp,"      ",TEXT.SYM.NO.pp,"      ",TEXT.SYM.Up.pp, sep="")
Sub.title.barcode.pp2= paste(TEXT.SYM.Do.pp,"      ",TEXT.SYM.Up.pp, sep="")					
##########
return( c(XLAB.barcode.pp1, Sub.title.barcode.pp1, Sub.title.barcode.pp2, UP.DOWN.length.pppp ) )
} 
######################################################################################################################################################### 
#########################################################################################################################################################
######################################################################################################################################################### 


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..Make.Big.Table.TOGO= function(RUN.goana.Kegga..for.Plot..GOGO, TABLEs.INP.GOGO, CASE.Model.VEC.GOGO= c(CASE.Model.VEC,"Lima","edgeR","DESeq","ALL"), DIR_Annotations.Organism.GOGO=DIR_Annotations.Organism, 
                                           MIN.P.logFC.GOGO=c(1,1.2,2)[1], MIN.P.Value.GOGO=0.05, MIN.FDR.GOGO= c(0.05,0.1,0.5,1)[1], PLOT.GOGO=c(TRUE, FALSE)[1], print.GOGO=c(1,0)[1] ) {

## DIR_Annotations.Organism.GOGO= DIR_Annotations.Organism..KEKE;   MIN.P.logFC.GOGO=MIN.P.logFC..KEKE;   MIN.P.Value.GOGO=MIN.P.Value..KEKE;  MIN.FDR.GOGO=MIN.FDR..KEKE;   PLOT.GOGO=PLOT.GO..KEKE;   print.GOGO=print.GO.path..KEKE;
## RUN.goana.Kegga..for.Plot..GOGO=RUN.goana.Kegga..for.Plot..KEKE; TABLEs.INP.GOGO=TABLEs.INP..KEKE; CASE.Model.VEC.GOGO=CASE.Model.VEC..KEKE;  

################################################################################################################ {
################################################################################################################
if(print.GOGO>0) print(paste("############ FFF.RNAseq..Make.Big.Table.TOGO   --> number of tests =>", length(CASE.Model.VEC.GOGO),"       Table=", nrow(TABLEs.INP.GOGO)  ))
####
RUNNIGN.OLD.Method.GOGO= c(0,1)[1]

############################################################
############################################################
SPECIES.GOGO= c()
if(DIR_Annotations.Organism.GOGO=="Homo_sapiens") SPECIES.GOGO  = "Hs" ;  if(DIR_Annotations.Organism.GOGO=="Mus_musculus") SPECIES.GOGO  = "Mm";  if(DIR_Annotations.Organism.GOGO=="Rattus_norvegicus") SPECIES.GOGO  = "Rn";
if(DIR_Annotations.Organism.GOGO=="Homo_sapiens") SPECIES.GO.keg= "hsa";  if(DIR_Annotations.Organism.GOGO=="Mus_musculus") SPECIES.GO.keg="mmu";  if(DIR_Annotations.Organism.GOGO=="Rattus_norvegicus") SPECIES.GO.keg="rno";
#######
if(RUN.goana.Kegga..for.Plot..GOGO<0 | RUN.goana.Kegga..for.Plot..GOGO>7) stop(paste(" MAIN ERROR --> scrip with only RUN.goana.Kegga..for.Plot..GOGO==0,1,,,,6  -->",RUN.goana.Kegga..for.Plot..GOGO))

####################################################################
goana.kegga.Model1.GOGO= c();		  goana.kegga.Model2.GOGO= c();     TXT.Main.filters.GOGO=c()
##############
if(length(SPECIES.GOGO)<=0) {
	print("");  print(paste(" ERROR ERROR --> Script do not have register your organism -->", DIR_Annotations.Organism.GOGO ))
	pirnt("");  stop("kaOs is stopping")
} else {
	#######
	## setwd(MAIN.MAIN.DIR...MAIN.Temporal);    pdf(paste(Project.RNA..run,"..",FILE.Join.Algorithms..PDF1,sep=""));
	#######
	if(RUNNIGN.OLD.Method.GOGO==1) KEGGLinks.GOGO = getGeneKEGGLinks(species.KEGG = SPECIES.GO.keg)
	#######
	goana.Model1.GOGO= c();      goana.Model2.GOGO= c();    kegga.Model1.GOGO= c();      kegga.Model2.GOGO= c();  conta.Models1=0;    conta.Models2=0
	#######
	for(CASE.TO.go in CASE.Model.VEC.GOGO) {  ##  {  CASE.TO.go=CASE.Model.VEC.GOGO[1] 
		###############################
		res.fit.TO.go=c();  CASE.Type.go="error"
		###################
		if(CASE.TO.go=="Lima1"     ){ res.fit.TO.go= fit_Lima1;				CASE.Type.go="Li"   } 
		if(CASE.TO.go=="Lima2"     ){ res.fit.TO.go= fit_Lima2;				CASE.Type.go="Li"   }
		if(CASE.TO.go=="Lima3-Voom"){ res.fit.TO.go= fit_Lima_Voom1;		CASE.Type.go="Li"   }
		if(CASE.TO.go=="Lima4-Voom"){ res.fit.TO.go= fit_Lima_Voom2;		CASE.Type.go="Li"   }
		if(CASE.TO.go=="edgeR.ltr1"){ res.fit.TO.go= res_edgeR_lrt;			CASE.Type.go="ed"   }
		if(CASE.TO.go=="edgeR.qlf1"){ res.fit.TO.go= res_edgeR_qlf;			CASE.Type.go="ed"   }
		if(CASE.TO.go=="edgeR.ltr2"){ res.fit.TO.go= res_edgeR_B_lrt;		CASE.Type.go="ed"   }
		if(CASE.TO.go=="edgeR.qlf2"){ res.fit.TO.go= res_edgeR_B_qlf;		CASE.Type.go="ed"   }
		if(CASE.TO.go=="DESeq1"    ){ res.fit.TO.go= c();   				CASE.Type.go="DE"	}
		if(CASE.TO.go=="DESeq1b"   ){ res.fit.TO.go= c();   				CASE.Type.go="DE"	}
		if(CASE.TO.go=="DESeq2"    ){ res.fit.TO.go= c();   				CASE.Type.go="DE"	}
		if(CASE.TO.go=="DESeq2b"   ){ res.fit.TO.go= c();   				CASE.Type.go="DE"	}
		if(CASE.TO.go=="ALL"       ){ res.fit.TO.go= c();   				CASE.Type.go="A"	};  if(CASE.Type.go=="error") stop("MAIN ERROR  --> CASE.Type.go==error")
		###############################
		goana.Model1= c();      kegga.Model1= c();       goana.Model2= c();      kegga.Model2= c()

		########################################################
		TABLEs.Model.USE= TABLEs.INP.GOGO
		if(CASE.Type.go!="A") if(nrow(TABLEs.INP.GOGO)>0) TABLEs.Model.USE= TABLEs.INP.GOGO[TABLEs.INP.GOGO[,"Model"]==CASE.TO.go,]
		if(CASE.Type.go=="A") if(nrow(TABLEs.INP.GOGO)>0){
			###########
			TABLEs.Model.USE[,"XX.SOFT"]=0;  for(CASE.ggg in CASE.Model.VEC.GOGO) TABLEs.Model.USE[TABLEs.Model.USE[,"Model"]==CASE.ggg,"XX.SOFT"]=1
			TABLEs.Model.USE= TABLEs.Model.USE[TABLEs.Model.USE[,"XX.SOFT"]==1,]
		}
		print(paste(CASE.TO.go," ---> rows=", nrow(TABLEs.Model.USE)))
		
		########################################################
		TABLEs.Model.Fi.GO= TABLEs.Model.USE;   TXT.Main.filters.GOGO=c()
		if(MIN.P.logFC.GOGO >0                      ){ TABLEs.Model.Fi.GO= TABLEs.Model.Fi.GO[abs(as.numeric(TABLEs.Model.Fi.GO[,"logFC" ]))>=MIN.P.logFC.GOGO,];      TXT.Main.filters.GOGO= c(TXT.Main.filters.GOGO, paste( "logFC >"   ,MIN.P.logFC.GOGO )) }
		if(MIN.P.Value.GOGO >0 & MIN.P.Value.GOGO <1){ TABLEs.Model.Fi.GO= TABLEs.Model.Fi.GO[    as.numeric(TABLEs.Model.Fi.GO[,"PValue"]) <=MIN.P.Value.GOGO,];      TXT.Main.filters.GOGO= c(TXT.Main.filters.GOGO, paste("PValue >"   ,MIN.P.Value.GOGO )) }
		if(MIN.FDR.GOGO     >0 & MIN.FDR.GOGO     <1){ TABLEs.Model.Fi.GO= TABLEs.Model.Fi.GO[    as.numeric(TABLEs.Model.Fi.GO[,"FDR"   ]) <=MIN.FDR.GOGO    ,];      TXT.Main.filters.GOGO= c(TXT.Main.filters.GOGO, paste(   "FDR >"   ,MIN.FDR.GOGO     )) }
		if(length(TXT.Main.filters.GOGO)<=0) TXT.Main.filters.GOGO= "" else TXT.Main.filters.GOGO= paste("",paste(TXT.Main.filters.GOGO, collapse=";  "))
		########################################################
		if(RUNNIGN.OLD.Method.GOGO==1){
		############################################
		MIN.FDR.GOGO.goana= MIN.FDR.GOGO;  if(MIN.FDR.GOGO.goana>1 | MIN.FDR.GOGO.goana <0) MIN.FDR.GOGO.goana= 1
		#########
		GENES.run.GOGO=c();
		if(nrow(TABLEs.Model.Fi.GO)>0) {
				if(CASE.Type.go=="Li" | CASE.Type.go=="ed") {
					ROWNAMES..res.fir..GGGY= rownames(res.fit.TO.go);    MMM.GO= match(TABLEs.Model.Fi.GO[,"RawPro.gene"],ROWNAMES..res.fir..GGGY);      if(length(MMM.GO[is.na(MMM.GO)])>0) stop(paste("MAIN error, matching RawPro.gene with NA --> MMM.GO -->",length(MMM.GO[is.na(MMM.GO)]),"of",nrow(TABLEs.Model.Fi.GO)))
					#res.fit.TO.go= res.fit.TO.go[MMM.GO,];  if(CASE.TO.go==CASE.Model.VEC.GOGO[1]) print(paste("no reduction" ,"     FDR=",MIN.FDR.GOGO.goana,"       path.pvalue <",MAX.PValue.Path..Models));      ### head(fit1_Vo$F.p.value);   head(fit1_Vo$p.value)
					if(CASE.TO.go==CASE.Model.VEC.GOGO[1]) print(paste("            no reduction" ,"            FDR=",MIN.FDR.GOGO.goana,"            path.pvalue <",MAX.PValue.Path..Models));
				}
				GENES.run.GOGO= unique(TABLEs.Model.Fi.GO[,"RawPro.gene"])
		} else res.fit.TO.go= c();
		#######
		TXT..pass.or.NOT.kkk="";  if(length(GENES.run.GOGO)<=2){ res.fit.TO.go= c();  TXT..pass.or.NOT.kkk= "    --->   no PASS" }    
		#######
		if(length(res.fit.TO.go)>0) ROWssss.KK= nrow(res.fit.TO.go) else ROWssss.KK= 0;      print(paste("res.fit=",ROWssss.KK,"        TABLE.Filter=", nrow(TABLEs.Model.Fi.GO),"      -->", CASE.TO.go,"            ", date(), TXT..pass.or.NOT.kkk))
		
		############################################ 
		if(print.GOGO>0) print(paste("##############################################  ", CASE.TO.go, "       rows=",nrow(TABLEs.Model.USE)," -->",nrow(TABLEs.Model.Fi.GO),"  genes=",length(GENES.run.GOGO),"      ", date() ));   ##print(length(res.fit.TO.go))
		########
		if(length(res.fit.TO.go)>0) {
			######
			if(RUN.goana.Kegga..for.Plot..GOGO==1 | RUN.goana.Kegga..for.Plot..GOGO==2 | RUN.goana.Kegga..for.Plot..GOGO==0) {
			 ###goana.Model1 = goana(res.fit.TO.go,    FDR = MIN.FDR.GOGO.goana  , species=SPECIES.GOGO,  plot=PLOT.GOGO,  gene.pathway=KEGGLinks.GOGO, coef=2 );
				goana.Model1 = goana(res.fit.TO.go,    FDR = MIN.FDR.GOGO.goana  , species=SPECIES.GOGO,  plot=PLOT.GOGO,  gene.pathway=KEGGLinks.GOGO);  	if(print.GOGO>0) print(dim(goana.Model1));   if(print.GOGO>1){ print(topGO  (goana.Model1, n=3, sort = "up", truncate="50"));   print(topGO  (goana.Model1, n=3, sort = "down", truncate="50")) }  ## truncate= number of characteteres
				#print(paste("goana.Model1 ---> rows=", nrow(res.fit.TO.go),"   FDR=",MIN.FDR.GOGO.goana))
			}
			######
			GENES.test= rownames(res.fit.TO.go);   run.Model1.kegga.GOGO=0;  for(Gene.kjui in GENES.test) if(run.Model1.kegga.GOGO==0) if(length(KEGGLinks.GOGO[KEGGLinks.GOGO[,"GeneID"]==Gene.kjui,"GeneID"])>0) run.Model1.kegga.GOGO=1
			if(run.Model1.kegga.GOGO==0) print(paste("Warning  --> no gene found in database (KEGGLinks.GOGO) -->   genes=", nrow(res.fit.TO.go) )) else if(RUN.goana.Kegga..for.Plot..GOGO==3 | RUN.goana.Kegga..for.Plot..GOGO==4 | RUN.goana.Kegga..for.Plot..GOGO==0) {
				kegga.Model1 = kegga(res.fit.TO.go,    FDR = MIN.FDR.GOGO.goana  , species=SPECIES.GOGO,  plot=PLOT.GOGO,  gene.pathway=KEGGLinks.GOGO);  	if(print.GOGO>0) print(dim(kegga.Model1));   if(print.GOGO>1){ print(topKEGG(kegga.Model1, n=3, sort = "up", truncate="50"));   print(topKEGG(kegga.Model1, n=3, sort = "down", truncate="50")) }
				#print(paste("kegga.Model1 ---> rows=", nrow(res.fit.TO.go)))
			}
		}
		############################################
		if(nrow(TABLEs.Model.Fi.GO)>0){
			#print("JAJJA2")
			if(RUN.goana.Kegga..for.Plot..GOGO==5 | RUN.goana.Kegga..for.Plot..GOGO==0) {
				goana.Model2 = goana(unique(TABLEs.Model.Fi.GO[,"RawPro.gene"]), species=SPECIES.GOGO, plot=PLOT.GOGO, gene.pathway=KEGGLinks.GOGO);  if(print.GOGO>0) print(dim(kegga.Model2));   if(print.GOGO>1){ print(head(goana.Model2[order(goana.Model2[,"P.DE"], decreasing = FALSE),], 3)) }
				#print(paste("goana.Model2 ---> rows=", nrow(TABLEs.Model.Fi.GO)))
			}
			if(RUN.goana.Kegga..for.Plot..GOGO==6 | RUN.goana.Kegga..for.Plot..GOGO==0) {
				kegga.Model2 = kegga(unique(TABLEs.Model.Fi.GO[,"RawPro.gene"]), species=SPECIES.GOGO, plot=PLOT.GOGO, gene.pathway=KEGGLinks.GOGO);  if(print.GOGO>0) print(dim(kegga.Model2));   if(print.GOGO>1){ print(head(kegga.Model2[order(kegga.Model2[,"P.DE"], decreasing = FALSE),], 3)) }
		}	}
		############################################
		} else {
			######################################## 
			if(print.GOGO>0) print(paste("##############################################  ", CASE.TO.go, "       rows=",nrow(TABLEs.Model.USE)," -->",nrow(TABLEs.Model.Fi.GO),"      ", date() ));   ##print(length(res.fit.TO.go))
			#########
			TABLEs.Model.UP.GO= TABLEs.Mod.Down.GO= TABLEs.Model.Fi.GO
			if(nrow(TABLEs.Model.Fi.GO)>0){ TABLEs.Model.UP.GO= TABLEs.Model.Fi.GO[as.numeric(TABLEs.Model.Fi.GO[,"logFC"])>=0,];   TABLEs.Mod.Down.GO= TABLEs.Model.Fi.GO[as.numeric(TABLEs.Model.Fi.GO[,"logFC"]) <0,]   }

			###########################
			Go.KEGG.GeneLinks..USE..GOGO= Go.KEGG.GeneLinks..PATHS..FFF;     ## Go.KEGG.GeneLinks..USE..GOGO= Go.KEGG.GeneLinks..CLEAN..FFF
			#########
		  ##kegga.GENES.Al= kegga( unique(TABLEs.Model.Fi.GO[,"RawPro.gene"]), species=SPECIES.GOGO, gene.pathway=Go.KEGG.GeneLinks..GENES..FFF[,c("GeneID","PathwayID")]                                                                             );  ##  head(kegga.GENES.Al);  if(Print.ggg>0) tail(kegga.GENES.Al);  dim(kegga.GENES.Al);  print("")
            kegga.CLEAN.Al= kegga( unique(TABLEs.Model.Fi.GO[,"Raw.geneID"]), species=SPECIES.GOGO, gene.pathway=Go.KEGG.GeneLinks..USE..GOGO [,c("GeneID","PathwayID")], pathway.names= Go.KEGG.GeneLinks..USE..GOGO[,c("PathwayID","Description")] );  ##  head(kegga.CLEAN.Al);  if(Print.ggg>0) tail(kegga.CLEAN.Al);  dim(kegga.CLEAN.Al);  print("")  
			kegga.CLEAN.UP= kegga( unique(TABLEs.Model.UP.GO[,"Raw.geneID"]), species=SPECIES.GOGO, gene.pathway=Go.KEGG.GeneLinks..USE..GOGO [,c("GeneID","PathwayID")], pathway.names= Go.KEGG.GeneLinks..USE..GOGO[,c("PathwayID","Description")] );  ##  head(kegga.CLEAN.UP);  if(Print.ggg>0) tail(kegga.CLEAN.UP);  dim(kegga.CLEAN.UP);  print("")  
			kegga.CLEAN.DO= kegga( unique(TABLEs.Mod.Down.GO[,"Raw.geneID"]), species=SPECIES.GOGO, gene.pathway=Go.KEGG.GeneLinks..USE..GOGO [,c("GeneID","PathwayID")], pathway.names= Go.KEGG.GeneLinks..USE..GOGO[,c("PathwayID","Description")] );  ##  head(kegga.CLEAN.DO);  if(Print.ggg>0) tail(kegga.CLEAN.DO);  dim(kegga.CLEAN.DO);  print("")  

			########################### 
			kegga.CLEAN.UP[,"Up"  ]= kegga.CLEAN.UP[,"DE"];   kegga.CLEAN.UP[,"P.Up"  ]= kegga.CLEAN.UP[,"P.DE"];   kegga.CLEAN.UP[,"Term"]= kegga.CLEAN.UP[,"Pathway"];   kegga.CLEAN.UP[,"Ont"]= "NO"
			kegga.CLEAN.DO[,"Down"]= kegga.CLEAN.DO[,"DE"];   kegga.CLEAN.DO[,"P.Down"]= kegga.CLEAN.DO[,"P.DE"]
			#########
			kegga.CLEAN.UP.DO= kegga.CLEAN.UP;  
			if(nrow(kegga.CLEAN.UP.DO)!=nrow(kegga.CLEAN.DO)) stop("MAIN ERROR ---> nrow(kegga.CLEAN.UP.DO)!=nrow(kegga.CLEAN.DO)") else kegga.CLEAN.UP.DO[,c("Down","P.Down")]= kegga.CLEAN.DO[rownames(kegga.CLEAN.UP.DO),c("Down","P.Down")]
			if(nrow(kegga.CLEAN.UP.DO)!=nrow(kegga.CLEAN.Al)) stop("MAIN ERROR ---> nrow(kegga.CLEAN.UP.DO)!=nrow(kegga.CLEAN.Al)") else kegga.CLEAN.UP.DO[,c(  "DE","P.DE"  )]= kegga.CLEAN.Al[rownames(kegga.CLEAN.UP.DO),c("DE","P.DE"    )]
			#########
			kegga.CLEAN.UP.DO[,"SUM"]= as.integer(kegga.CLEAN.UP.DO[,"Down"]) + as.integer(kegga.CLEAN.UP.DO[,"Up"]) - as.integer(kegga.CLEAN.UP.DO[,"DE"])
			ERROR.SUM.RRR= kegga.CLEAN.UP.DO[kegga.CLEAN.UP.DO[,"SUM"]!=0,];  
			if(nrow(ERROR.SUM.RRR)>0){ 	
				print("");  print(dim(TABLEs.Mod.Down.GO));  print(dim(TABLEs.Model.UP.GO));  print(dim(TABLEs.Model.Fi.GO));  print(paste("MAIN ERROR -->  nrow(ERROR.SUM.RRR)>0  --->",nrow(ERROR.SUM.RRR), " of", nrow(kegga.CLEAN.UP.DO)));  print(head(ERROR.SUM.RRR, 10));  print("");  print(table(kegga.CLEAN.UP.DO[,"SUM"]));  print("")
				if(length(RNAseq..Path..DONT_STOP_ERROR_SUM..Test.VEC)>0){ print(paste("  RNAseq..Path..DONT_STOP_ERROR_SUM..Test.VEC -->",  paste( RNAseq..Path..DONT_STOP_ERROR_SUM..Test.VEC, collapse="; ") ));  print("");  }  
				if(length(RNAseq..Path..DONT_STOP_ERROR_SUM..Test.VEC[paste(RNAseq..Path..DONT_STOP_ERROR_SUM..Test.VEC)==paste(test_RUN.Model..Pipe)])<=0) stop(paste(" kaOs is stooping --->  path analysis ---> nrow(ERROR.SUM.RRR)>0  --> test=",test_RUN.Model..Pipe))
			}
			#########
			kegga.CLEAN.UP.DO= kegga.CLEAN.UP.DO[,c("Term","Ont","N","Up","Down","P.Up","P.Down")];   ## head(kegga.CLEAN.UP.DO)

			###########################
			kegga.CLEAN.UP.DO[,"PathwayID"]= rownames(kegga.CLEAN.UP.DO);       kegga.CLEAN.Al[,"PathwayID"]= rownames(kegga.CLEAN.Al);     kegga.CLEAN.Al[,"Term"]= kegga.CLEAN.Al[,"Pathway"];     kegga.CLEAN.UP.DO[,"Pathway"]= kegga.CLEAN.UP.DO[,"Term"];  
			goana.Model1= kegga.CLEAN.UP.DO[grep("locoG:", kegga.CLEAN.UP.DO[,"PathwayID"],fixed=TRUE),]
			kegga.Model1= kegga.CLEAN.UP.DO[grep("locoK:", kegga.CLEAN.UP.DO[,"PathwayID"],fixed=TRUE),];  if( (nrow(goana.Model1)+nrow(kegga.Model1))!=nrow(kegga.CLEAN.UP.DO)) stop("MAIN ERROR -->  (nrow(goana.Model1)+nrow(kegga.Model1))!=nrow(kegga.CLEAN.UP.DO) ")
			goana.Model2= kegga.CLEAN.Al   [grep("locoG:", kegga.CLEAN.Al   [,"PathwayID"],fixed=TRUE),]
			kegga.Model2= kegga.CLEAN.Al   [grep("locoK:", kegga.CLEAN.Al   [,"PathwayID"],fixed=TRUE),];  if( (nrow(goana.Model2)+nrow(kegga.Model2))!=nrow(kegga.CLEAN.Al   )) stop("MAIN ERROR -->  (nrow(goana.Model2)+nrow(kegga.Model2))!=nrow(kegga.CLEAN.Al   ) ")
			######
			goana.Model1[,"PathwayID"]= gsub("locoG:", "GO:"  ,goana.Model1[,"PathwayID"], fixed=TRUE);  rownames(goana.Model1)= goana.Model1[,"PathwayID"];  goana.Model1= goana.Model1[,c("Term"   ,"Ont","N","Up","Down","P.Up","P.Down")]
			kegga.Model1[,"PathwayID"]= gsub("locoK:", "path:",kegga.Model1[,"PathwayID"], fixed=TRUE);  rownames(kegga.Model1)= kegga.Model1[,"PathwayID"];  kegga.Model1= kegga.Model1[,c("Pathway","Ont","N","Up","Down","P.Up","P.Down")]
			goana.Model2[,"PathwayID"]= gsub("locoG:", "GO:"  ,goana.Model2[,"PathwayID"], fixed=TRUE);  rownames(goana.Model2)= goana.Model2[,"PathwayID"];  goana.Model2= goana.Model2[,c("Term"   ,"N","DE","P.DE")]
			kegga.Model2[,"PathwayID"]= gsub("locoK:", "path:",kegga.Model2[,"PathwayID"], fixed=TRUE);  rownames(kegga.Model2)= kegga.Model2[,"PathwayID"];  kegga.Model2= kegga.Model2[,c("Pathway","N","DE","P.DE")]
			######
			## head(kegga.Model1);   dim(kegga.Model1);   head(kegga.Model2);   dim(kegga.Model2)
		}
		
		########################################################  join		
		if(length(goana.Model1)>0){ if(length(goana.Model1.GOGO)<=0) goana.Model1.GOGO=goana.Model1[0,];   goana.Model1[,"Model"]=CASE.TO.go;   goana.Model1[,"Method"]="goana1";  	goana.Model1[,"RawPro.gene"]= rownames(goana.Model1); 	goana.Model1.GOGO= rbind(goana.Model1.GOGO, goana.Model1) } 
		if(length(kegga.Model1)>0){ if(length(kegga.Model1.GOGO)<=0) kegga.Model1.GOGO=kegga.Model1[0,];   kegga.Model1[,"Model"]=CASE.TO.go;   kegga.Model1[,"Method"]="kegga1";	kegga.Model1[,"RawPro.gene"]= rownames(kegga.Model1);   kegga.Model1.GOGO= rbind(kegga.Model1.GOGO, kegga.Model1) }
		#########	
		if(length(goana.Model2)>0){ if(length(goana.Model2.GOGO)<=0) goana.Model2.GOGO=goana.Model2[0,];   goana.Model2[,"Model"]=CASE.TO.go;   goana.Model2[,"Method"]="goana2";	goana.Model2[,"RawPro.gene"]= rownames(goana.Model2);   goana.Model2.GOGO= rbind(goana.Model2.GOGO, goana.Model2) }
		if(length(kegga.Model2)>0){ if(length(kegga.Model2.GOGO)<=0) kegga.Model2.GOGO=kegga.Model2[0,];   kegga.Model2[,"Model"]=CASE.TO.go;   kegga.Model2[,"Method"]="kegga2";	kegga.Model2[,"RawPro.gene"]= rownames(kegga.Model2);   kegga.Model2.GOGO= rbind(kegga.Model2.GOGO, kegga.Model2) }
		#########
		if(length(goana.Model1)>0) conta.Models1= conta.Models1 + nrow(goana.Model1);   if(length(kegga.Model1)>0) conta.Models1= conta.Models1 + nrow(kegga.Model1)
		if(length(goana.Model2)>0) conta.Models2= conta.Models2 + nrow(goana.Model2);   if(length(kegga.Model2)>0) conta.Models2= conta.Models2 + nrow(kegga.Model2)
		######################################################## 
	};  ## dev.off();

	########################################
	#### head(goana.Model1.GOGO);   head(kegga.Model1.GOGO);   dim(goana.Model1.GOGO);  dim(kegga.Model1.GOGO);
	#### head(goana.Model2.GOGO);   head(kegga.Model2.GOGO);   dim(goana.Model2.GOGO);  dim(kegga.Model2.GOGO);
	####
	if(length(goana.Model1.GOGO)>0){                                                                        goana.kegga.Model1.GOGO=goana.Model1.GOGO[0,];   goana.Model1.GOGO[,"Pathway"]= goana.Model1.GOGO[,"Term"] }
	if(length(kegga.Model1.GOGO)>0){ if(nrow(kegga.Model1.GOGO)>0) kegga.Model1.GOGO[,"Ont"]="kegga1"; 		goana.kegga.Model1.GOGO=kegga.Model1.GOGO[0,] }
	########
	if(length(goana.Model2.GOGO)>0){ if(nrow(goana.Model2.GOGO)>0) goana.Model2.GOGO[,"Ont"]="goana2"; 		goana.kegga.Model2.GOGO=goana.Model2.GOGO[0,];   goana.Model2.GOGO[,"Pathway"]= goana.Model2.GOGO[,"Term"] }
	if(length(kegga.Model2.GOGO)>0){ if(nrow(kegga.Model2.GOGO)>0) kegga.Model2.GOGO[,"Ont"]="kegga2"; 		goana.kegga.Model2.GOGO=kegga.Model2.GOGO[0,] }
	################
	XXX.COL.USE.Model1.GOGO= colnames(goana.kegga.Model1.GOGO);  XXX.COL.USE.Model1.GOGO= XXX.COL.USE.Model1.GOGO[XXX.COL.USE.Model1.GOGO!="Term"]
	if(length(goana.Model1.GOGO)>0) goana.kegga.Model1.GOGO= rbind(goana.kegga.Model1.GOGO, goana.Model1.GOGO[,XXX.COL.USE.Model1.GOGO])
	if(length(kegga.Model1.GOGO)>0) goana.kegga.Model1.GOGO= rbind(goana.kegga.Model1.GOGO, kegga.Model1.GOGO[,XXX.COL.USE.Model1.GOGO])
	########
	XXX.COL.USE.Model2.GOGO= colnames(goana.kegga.Model2.GOGO);  XXX.COL.USE.Model2.GOGO= XXX.COL.USE.Model2.GOGO[XXX.COL.USE.Model2.GOGO!="Term"]
	if(length(goana.Model2.GOGO)>0) goana.kegga.Model2.GOGO= rbind(goana.kegga.Model2.GOGO, goana.Model2.GOGO[,XXX.COL.USE.Model2.GOGO])
	if(length(kegga.Model2.GOGO)>0) goana.kegga.Model2.GOGO= rbind(goana.kegga.Model2.GOGO, kegga.Model2.GOGO[,XXX.COL.USE.Model2.GOGO])
	########################################
	if(length(goana.kegga.Model1.GOGO) >0) if(conta.Models1!=nrow(goana.kegga.Model1.GOGO)) stop(paste(" MAIn ERROR --> conta.Models!=nrow(goana.kegga.Model1) --> ",conta.Models1,"!=",nrow(goana.kegga.Model1.GOGO),"       ", TXT.Main.filters.GOGO ))
	if(length(goana.kegga.Model2.GOGO) >0) if(conta.Models2!=nrow(goana.kegga.Model2.GOGO)) stop(paste(" MAIn ERROR --> conta.Models!=nrow(goana.kegga.Model2) --> ",conta.Models2,"!=",nrow(goana.kegga.Model2.GOGO),"       ", TXT.Main.filters.GOGO ))
	if(length(goana.kegga.Model1.GOGO) >0 & length(goana.kegga.Model2.GOGO) >0) if(print.GOGO>0) print(paste(" --> Perfect goto join --> meth1=",   nrow(goana.kegga.Model1.GOGO), "     meth2=",  nrow(goana.kegga.Model2.GOGO),"       ", TXT.Main.filters.GOGO, "      ", date() ))
	if(length(goana.kegga.Model1.GOGO) >0 & length(goana.kegga.Model2.GOGO)<=0) if(print.GOGO>0) print(paste(" --> Perfect goto join --> meth1=",   nrow(goana.kegga.Model1.GOGO), "     meth2=",length(goana.kegga.Model2.GOGO),"       ", TXT.Main.filters.GOGO, "      ", date() ))
	if(length(goana.kegga.Model1.GOGO)<=0 & length(goana.kegga.Model2.GOGO) >0) if(print.GOGO>0) print(paste(" --> Perfect goto join --> meth1=", length(goana.kegga.Model1.GOGO), "     meth2=",  nrow(goana.kegga.Model2.GOGO),"       ", TXT.Main.filters.GOGO, "      ", date() ))
	if(length(goana.kegga.Model1.GOGO)<=0 & length(goana.kegga.Model2.GOGO)<=0) if(print.GOGO>0) print(paste(" --> Perfect goto join --> meth1=", length(goana.kegga.Model1.GOGO), "     meth2=",length(goana.kegga.Model2.GOGO),"       ", TXT.Main.filters.GOGO, "      ", date() ))
	########################################
	COl..goana.kegga.GOGO= unique(c("Pathway","Ont","N","Up","Down","P.Up","P.Down","Model","Method","RawPro.gene"))
	goana.kegga.000.GOGO= as.data.frame(array(NA,c(0,length(COl..goana.kegga.GOGO))),stringsFactors=F); colnames(goana.kegga.000.GOGO)= COl..goana.kegga.GOGO
	if(length(goana.kegga.Model1.GOGO)<=0) goana.kegga.Model1.GOGO= goana.kegga.000.GOGO else { COL.names..RR= colnames(goana.kegga.Model1.GOGO);  COL.names..RR= sub("Term","Pathway",COL.names..RR,fixed=TRUE);  colnames(goana.kegga.Model1.GOGO)= COL.names..RR }
	if(length(goana.kegga.Model2.GOGO)<=0) goana.kegga.Model2.GOGO= goana.kegga.000.GOGO else { COL.names..RR= colnames(goana.kegga.Model2.GOGO);  COL.names..RR= sub("Term","Pathway",COL.names..RR,fixed=TRUE);  colnames(goana.kegga.Model2.GOGO)= COL.names..RR }
	######
	#print(colnames(goana.kegga.Model1.GOGO));  print(colnames(goana.kegga.Model2.GOGO))
}

##############################################################
TXT.Main.filters.TOGO...FF <<- TXT.Main.filters.GOGO
goana.kegga.Model2..FF     <<- goana.kegga.Model2.GOGO
return(goana.kegga.Model1.GOGO)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################

                              
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..RUN.goana.Kegga= function(RUN.goana.Kegga..for.Plot..KEKE, RUN.Big.Table.TOGO..KEKE, TABLEs.INP..KEKE, CASE.Model.VEC..KEKE, test_run..KEKE,  DIR_Annotations.Organism..KEKE= DIR_Annotations.Organism, 
                                      MIN.P.logFC..KEKE=c(-1,1.2,2)[1], MIN.P.Value..KEKE=c(-1,0.05)[2],  MIN.FDR..KEKE= c(0.05,0.1,0.5,1)[1], MIN.P.Value.Path..KEKE= c(0.05, 0.0001)[1], 
                                      print.GO.path..KEKE=c(1,2,0)[3], PLOT.GO..KEKE=c(TRUE,FALSE)[1] ) {

########################### plooting
## RUN.goana.Kegga..for.Plot..KEKE=RUN.Togo.PLOT; RUN.Big.Table.TOGO..KEKE=RUN.Big.Table.TOGO.PLOT; TABLEs.INP..KEKE=TABLEs.ALL.PLOT; CASE.Model.VEC..KEKE=CASE.Model.VEC.PLOT; test_run..KEKE=test_run.pp.PLOT; DIR_Annotations.Organism..KEKE= DIR_Annotations.Organism.PLOT; 
## MIN.P.logFC..KEKE=GO.logFC.PLOT; MIN.P.Value..KEKE=GO.PValue.PLOT; MIN.FDR..KEKE= GO.FDR.PLOT; MIN.P.Value.Path..KEKE= GO.PValue.Path; print.GO.path..KEKE=1; PLOT.GO..KEKE=GO.PLOT.PLOT

########################### 3)script
## RUN.goana.Kegga..for.Plot..KEKE=RUN.goana.Kegga..for.Plot; RUN.Big.Table.TOGO..KEKE=RUN.Big.Table.TOGO; TABLEs.INP..KEKE=TABLEs.ALL.ALL.Plot; CASE.Model.VEC..KEKE=CASE.Model.VEC.GO; test_run..KEKE=test_RUN.Model;  DIR_Annotations.Organism..KEKE= DIR_Annotations.Organism; 
## MIN.P.logFC..KEKE= MIN.logFC..Res.GO; MIN.P.Value..KEKE= MAX.PValue..Res.GO;  MIN.FDR..KEKE= MAX.FDR.GO.USE; MIN.P.Value.Path..KEKE= MAX.PValue.Path..Models; print.GO.path..KEKE= print..Res.GO; PLOT.GO..KEKE=PLOT..Res.GO

################################################################################################################ 
################################################################################################################ {
if(print.GO.path..KEKE>0) print(paste("############ FFF.RNAseq..RUN.goana.Kegga   --> number of tests =>", length(CASE.Model.VEC..KEKE),"       Table=", nrow(TABLEs.INP..KEKE)  ))                                           
#################
## Nota kaos: need to run main input file, we need (RNAseq..Models.Alg..Unique.VEC, RNAseq..Models.Alg..Lima.VEC, RNAseq..Models.Alg..edgeR.VEC, RNAseq..Models.Alg..DESeq.VEC)
                                        
###################################################### FFF.RNAseq..Make.Big.Table.TOGO
######################################################
if(RUN.Big.Table.TOGO..KEKE!=0) {
	RUN.goana.Kegga..KEKE= 0
	GO.Kegga.Model1= FFF.RNAseq..Make.Big.Table.TOGO(RUN.goana.Kegga..KEKE, TABLEs.INP..KEKE, CASE.Model.VEC..KEKE, DIR_Annotations.Organism..KEKE, MIN.P.logFC..KEKE, MIN.P.Value..KEKE, MIN.FDR..KEKE, PLOT.GO..KEKE, print.GO.path..KEKE)
	GO.Kegga.Model2= goana.kegga.Model2..FF;  GO.Kegga.TXT.filters..KEKE= TXT.Main.filters.TOGO...FF;    rm(goana.kegga.Model2..FF, TXT.Main.filters.TOGO...FF, envir = globalenv()) 
	## head(GO.Kegga.Model1);  head(GO.Kegga.Model2);  head(GO.Kegga.TXT.filters..KEKE)
	## GO.Kegga.Model1[as.integer(GO.Kegga.Model1[,"N"])<as.integer(GO.Kegga.Model1[,"Up"]),];    GO.Kegga.Model1[as.integer(GO.Kegga.Model1[,"N"])<as.integer(GO.Kegga.Model1[,"Down"]),];   GO.Kegga.Model2[as.integer(GO.Kegga.Model2[,"N"])<as.integer(GO.Kegga.Model2[,"DE"]),]
} else {
	if(!exists("GO.Kegga.Model1..FFF") | !exists("GO.Kegga.Model2..FFF") | !exists("GO.Kegga.TXT.filters..FFF")) stop(paste("ERROR ERROR --> !exists(GO.Kegga.Model1)  --> you need to run change RUN.Big.Table.TOGO..KEKE -->", RUN.Big.Table.TOGO..KEKE))
	GO.Kegga.Model1= GO.Kegga.Model1..FFF;   GO.Kegga.Model2= GO.Kegga.Model2..FFF;   GO.Kegga.TXT.filters..KEKE= GO.Kegga.TXT.filters..FFF
}
##########
if(nrow(GO.Kegga.Model1)>0) GO.Kegga.Model1[,"Test.XX"]= test_run..KEKE;					if(nrow(GO.Kegga.Model2)>0) GO.Kegga.Model2[,"Test.XX"]= test_run..KEKE

########################################################################### {
COL.genes.YES..KEKE = c("N.Yes","N.Up","N.Down","N.both","genes.Up","genes.Down","genes.both");
COL.genes.GoTo..KEKE= c("TNgenes.GoTo","Ngenes.GoTo","genes.GoTo","GeneID.GoTo","genes.GoTo1","genes.GoTo2","genes.GoTo3");     ##COL.genes.GoTo..KEKE= c("Tgenes.GoTo") 
COL.Common..KEKE= c("Up","Down","DE");       CASE.Model.VEC.id..KEKE= CASE.Model.VEC..KEKE;       CASE.Model.VEC.id..KEKE= FFF.RNAseq..JOIN..Get.Columns.Ids(CASE.Model.VEC..KEKE, 0)
#########
COLNAMES.YES0..KEKE= c("Selection","##M","User","RawPro.gene","Method","UP.DOWN","Pathway","Ont","N","N1","N2",COL.genes.GoTo..KEKE,"##Yes",COL.genes.YES..KEKE,"##A","Filters","Per.A","genes.A","pvalue.A","##A", paste(COL.Common..KEKE,".All",sep=""),paste("P.",COL.Common..KEKE,".All",sep="") )
COLNAMES.YES1..KEKE= c("##up"  ,paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".up" ,sep=""), "##down"  ,paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".do" ,sep=""), "##DE"  ,paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".DE"  ,sep=""),
                       "##P.up",paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".upP",sep=""), "##P.down",paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".doP",sep=""), "##P.DE",paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".DEP" ,sep="") )
COLNAMES.EXTR..KEKE= c("##Pa1" ,paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".Pa1",sep=""), "##N1"    ,paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".N1" ,sep=""), "##Ont1",paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".O1"  ,sep=""),
                       "##Pa2" ,paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".Pa2",sep=""), "##N2"    ,paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".N2" ,sep=""), "##Ont2",paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".O2"  ,sep=""),
                       "##Pa3" ,"Pat1","Pat2","Ont1","Ont2","Method1","Method2")                              
##################                             
COLNAMES.SAVE..KEKE= unique(c(COLNAMES.YES0..KEKE,COLNAMES.YES1..KEKE,                    "##End"))
COLNAMES.WORK..KEKE= unique(c(COLNAMES.YES0..KEKE,COLNAMES.YES1..KEKE,COLNAMES.EXTR..KEKE,"##End"))
#########
RawPro.gene.VEC..KEKE= unique(c(GO.Kegga.Model1[,"RawPro.gene"],GO.Kegga.Model2[,"RawPro.gene"]));  
#########
goana.kegga..KEKE= as.data.frame(array(NA,c(length(RawPro.gene.VEC..KEKE),length(COLNAMES.WORK..KEKE))),stringsFactors=F); colnames(goana.kegga..KEKE)= COLNAMES.WORK..KEKE
if(nrow(goana.kegga..KEKE)>0){
	goana.kegga..KEKE[,"RawPro.gene"]= RawPro.gene.VEC..KEKE;       rownames(goana.kegga..KEKE)= RawPro.gene.VEC..KEKE
	goana.kegga..KEKE[,COLNAMES.WORK..KEKE[grep("##",COLNAMES.WORK..KEKE,fixed=TRUE)]]= "##"
}

###########################################################################                           
if(nrow(goana.kegga..KEKE)>0) for(Method.xc in c("goana1","goana2","kegga1","kegga2"))for(Model.xc in CASE.Model.VEC..KEKE){
	#########
	RUN.gona= "error"
	if(Method.xc=="goana1" | Method.xc=="kegga1"){ RUN.gona= "goke1";  GO.Kegga.USE.xx= GO.Kegga.Model1[GO.Kegga.Model1[,"Method"]==Method.xc & GO.Kegga.Model1[,"Model"]==Model.xc,] }
	if(Method.xc=="goana2" | Method.xc=="kegga2"){ RUN.gona= "goke2";  GO.Kegga.USE.xx= GO.Kegga.Model2[GO.Kegga.Model2[,"Method"]==Method.xc & GO.Kegga.Model2[,"Model"]==Model.xc,] }
	if(RUN.gona=="error") stop("MAIN ERROR --> RUN.gona==error")
	#########
	if(nrow(GO.Kegga.USE.xx)>0){
		##################
		RawPro.gene.kk= c(GO.Kegga.USE.xx[,"RawPro.gene"]);  if(length(unique(RawPro.gene.kk))!=length(RawPro.gene.kk)) stop("MAIN ERROR --> length(unique(RawPro.gene.kk))!=length(RawPro.gene.kk)")
		#########
		goana.kegga..KEKE[RawPro.gene.kk,"Method"]= Method.xc
		##################
		Model.id.xc=Model.xc;    Model.id.xc= FFF.RNAseq..JOIN..Get.Columns.Ids(Model.xc, 0)
		#########
		if(RUN.gona=="goke1"){
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".Pa1",sep="")]= GO.Kegga.USE.xx[,"Pathway"]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".N1" ,sep="")]= GO.Kegga.USE.xx[,"N"      ]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".up" ,sep="")]= GO.Kegga.USE.xx[,"Up"     ]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".do" ,sep="")]= GO.Kegga.USE.xx[,"Down"   ]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".upP",sep="")]= GO.Kegga.USE.xx[,"P.Up"   ]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".doP",sep="")]= GO.Kegga.USE.xx[,"P.Down" ]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".O1" ,sep="")]= GO.Kegga.USE.xx[,"Ont"    ]
			goana.kegga..KEKE[RawPro.gene.kk,"Method1"]= Method.xc
		}
		if(RUN.gona=="goke2"){
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".Pa2",sep="")]= GO.Kegga.USE.xx[,"Pathway"]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".N2" ,sep="")]= GO.Kegga.USE.xx[,"N"      ]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".DE" ,sep="")]= GO.Kegga.USE.xx[,"DE"     ]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".DEP",sep="")]= GO.Kegga.USE.xx[,"P.DE"   ]
			goana.kegga..KEKE[RawPro.gene.kk,paste("T",test_run..KEKE,".",Model.id.xc,".O2" ,sep="")]= GO.Kegga.USE.xx[,"Ont"    ]
			goana.kegga..KEKE[RawPro.gene.kk,"Method2"]= Method.xc
		}		
}	}
##################
if(nrow(goana.kegga..KEKE)>0) for(CAse.kkk in c("N1","N2","Pa1","Pa2","O1","O2",  "N","O","Pa", "upP","doP","DEP","pva",  "DE","up","do","gen" )){
	COL..FINAL.kkk= "error"
	if(CAse.kkk== "N1" ){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".N1" ,sep="");  COL..FINAL.kkk= "N1";   		TEST.RUN="ONE"  }
	if(CAse.kkk== "N2" ){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".N2" ,sep="");  COL..FINAL.kkk= "N2";   		TEST.RUN="ONE" 	}
	if(CAse.kkk== "Pa1"){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".Pa1",sep="");  COL..FINAL.kkk= "Pat1";   		TEST.RUN="ONE"  }
	if(CAse.kkk== "Pa2"){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".Pa2",sep="");  COL..FINAL.kkk= "Pat2";   		TEST.RUN="ONE"  }
	if(CAse.kkk== "O1" ){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".O1" ,sep="");  COL..FINAL.kkk= "Ont1";   		TEST.RUN="ONE"  }
	if(CAse.kkk== "O2" ){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".O2" ,sep="");  COL..FINAL.kkk= "Ont2";   		TEST.RUN="ONE"  }
	######
	if(CAse.kkk== "N"  ){ COL..TEST..ONE.kkk= c("N1","N2");  													    COL..FINAL.kkk= "N";   	        TEST.RUN="MAX"  };
	if(CAse.kkk== "Pa" ){ COL..TEST..ONE.kkk= c("Pat1","Pat2");  													COL..FINAL.kkk= "Pathway";   	TEST.RUN="ONE"  }
	if(CAse.kkk== "O"  ){ COL..TEST..ONE.kkk= c("Ont1","Ont2");  													COL..FINAL.kkk= "Ont";   		TEST.RUN="ADD"  };
	######
	if(CAse.kkk== "upP"){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".upP",sep="");  COL..FINAL.kkk= "P.Up.All";   	TEST.RUN="MIN"  }
	if(CAse.kkk== "doP"){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".doP",sep="");  COL..FINAL.kkk= "P.Down.All";   TEST.RUN="MIN"  }
	if(CAse.kkk== "DEP"){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".DEP",sep="");  COL..FINAL.kkk= "P.DE.All";     TEST.RUN="MIN"  }
	if(CAse.kkk== "pva"){ COL..TEST..ONE.kkk= c("P.Up.All","P.Down.All","P.DE.All");  								COL..FINAL.kkk= "pvalue.A";   	TEST.RUN="MIN"  };
	######
	if(CAse.kkk== "up" ){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".up" ,sep="");  COL..FINAL.kkk= "Up.All";   	TEST.RUN="MAX"  }
	if(CAse.kkk== "do" ){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".do" ,sep="");  COL..FINAL.kkk= "Down.All";   	TEST.RUN="MAX"  }
	if(CAse.kkk== "DE" ){ COL..TEST..ONE.kkk= paste("T",test_run..KEKE,".",CASE.Model.VEC.id..KEKE,".DE" ,sep="");  COL..FINAL.kkk= "DE.All";   	TEST.RUN="MAX"  }
	if(CAse.kkk== "gen"){ COL..TEST..ONE.kkk= c("Up.All","Down.All","DE.All");  									COL..FINAL.kkk= "genes.A";   	TEST.RUN="MAX"  }
	######  
	if(COL..FINAL.kkk=="error") stop("MAIN ERROR  --> length(COL..TEST..ONE.kkk)<=0")
	##################
	goana.kegga..KEKE[,"Value.X"]= goana.kegga..KEKE[,COL..TEST..ONE.kkk[1]];  goana.kegga..KEKE[,"error.X"]= 0;
	######
	if(length(COL..TEST..ONE.kkk)>1) for(co2.kk in c(2:length(COL..TEST..ONE.kkk))){
		COL..TEST.KK= COL..TEST..ONE.kkk[co2.kk]
		goana.kegga..KEKE[ is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]),"Value.X"   ]=  
		goana.kegga..KEKE[ is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]),COL..TEST.KK]
		######
		if(TEST.RUN=="ONE") goana.kegga..KEKE[!is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]) &            goana.kegga..KEKE[,COL..TEST.KK]!=           goana.kegga..KEKE[,"Value.X"], "error.X"   ]= 1                  
		if(TEST.RUN=="ADD") goana.kegga..KEKE[!is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]) &            goana.kegga..KEKE[,COL..TEST.KK]!=           goana.kegga..KEKE[,"Value.X"], "Value.X"   ]=paste(
		                    goana.kegga..KEKE[!is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]) &            goana.kegga..KEKE[,COL..TEST.KK]!=           goana.kegga..KEKE[,"Value.X"], "Value.X"   ],",",
		                    goana.kegga..KEKE[!is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]) &            goana.kegga..KEKE[,COL..TEST.KK]!=           goana.kegga..KEKE[,"Value.X"], COL..TEST.KK],sep="") 
		if(TEST.RUN=="MIN") goana.kegga..KEKE[!is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]) & as.numeric(goana.kegga..KEKE[,COL..TEST.KK])<as.numeric(goana.kegga..KEKE[,"Value.X"]),"Value.X"   ]=
		                    goana.kegga..KEKE[!is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]) & as.numeric(goana.kegga..KEKE[,COL..TEST.KK])<as.numeric(goana.kegga..KEKE[,"Value.X"]),COL..TEST.KK]
		if(TEST.RUN=="MAX") goana.kegga..KEKE[!is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]) & as.numeric(goana.kegga..KEKE[,COL..TEST.KK])>as.numeric(goana.kegga..KEKE[,"Value.X"]),"Value.X"   ]=
		                    goana.kegga..KEKE[!is.na(goana.kegga..KEKE[,"Value.X"]) & !is.na(goana.kegga..KEKE[,COL..TEST.KK]) & as.numeric(goana.kegga..KEKE[,COL..TEST.KK])>as.numeric(goana.kegga..KEKE[,"Value.X"]),COL..TEST.KK]                    	                                    
	}
	ERROR.XX.KK= goana.kegga..KEKE[    goana.kegga..KEKE[,"error.X"]!=0,];  if(nrow(ERROR.XX.KK)>0) stop(paste("MAIN ERROR  --> nrow(ERROR.XX.KK)>0   -->",nrow(ERROR.XX.KK),"of",nrow(goana.kegga..KEKE),"       ",CAse.kkk))
	if(CAse.kkk== "N" | CAse.kkk== "Pa" | CAse.kkk=="O" | CAse.kkk== "pva" | CAse.kkk=="gen"){
		ERROR.NA.KK= goana.kegga..KEKE[is.na(goana.kegga..KEKE[,"Value.X"]),];  if(nrow(ERROR.NA.KK)>0) stop(paste("MAIN ERROR  --> nrow(ERROR.NA.KK)>0   1 -->",nrow(ERROR.NA.KK),"of",nrow(goana.kegga..KEKE),"       ",CAse.kkk)) }
	######
	goana.kegga..KEKE[,COL..FINAL.kkk]= goana.kegga..KEKE[,"Value.X"]
}
############ {
if(nrow(goana.kegga..KEKE)>0) goana.kegga..KEKE[,"User" ]= 0
if(nrow(goana.kegga..KEKE)>0) goana.kegga..KEKE[,"Per.A"]= paste((as.integer( 100*1*as.integer(goana.kegga..KEKE[,"genes.A"])/as.integer(goana.kegga..KEKE[,"N"]))/1),"%",sep="")
#####
for(CC..keke in c( "genes.A",  "Down.All",  "Up.All",  "DE.All")) goana.kegga..KEKE[is.na(goana.kegga..KEKE[,CC..keke]),CC..keke]=0
for(CC..keke in c("pvalue.A","P.Down.All","P.Up.All","P.DE.All")) goana.kegga..KEKE[is.na(goana.kegga..KEKE[,CC..keke]),CC..keke]=1
#####
goana.kegga..KEKE[,"Ont"]= sub(",goana2","",goana.kegga..KEKE[,"Ont"],fixed=TRUE)
goana.kegga..KEKE[,"Ont"]= sub(",kegga2","",goana.kegga..KEKE[,"Ont"],fixed=TRUE);  ##print(table(goana.kegga..KEKE[,"Ont"]));  ## head(goana.kegga..KEKE)
############		
COLNAMES.YES0..KEKE..TEST= c("RawPro.gene","Pathway","Ont","N","genes.A","pvalue.A")
STOP.NA.COL= 0;  for(COL.kkk in COLNAMES.YES0..KEKE..TEST){ ERROR.NA.KK= goana.kegga..KEKE[is.na(goana.kegga..KEKE[,COL.kkk]),];  if(nrow(ERROR.NA.KK)>0){ STOP.NA.COL= 1;  print(paste("MAIN ERROR  --> nrow(ERROR.NA.KK)>0   2 -->",nrow(ERROR.NA.KK),"of",nrow(goana.kegga..KEKE),"       ",COL.kkk)) } }
if(STOP.NA.COL!=0) stop(paste(" kaos is stopping ---> see below"))
############
goana.kegga..KEKE= goana.kegga..KEKE[order(as.numeric(goana.kegga..KEKE[,"pvalue.A"]), decreasing = FALSE),]
############
goana.kegga..KEKE= goana.kegga..KEKE[,c(COLNAMES.WORK..KEKE)];    ## head(goana.kegga..KEKE)

######################################################  testting  
##TABLE.test.NEW.M1.goana.UP11= goana.kegga..KEKE[goana.kegga..KEKE[,"Method1"]=="goana1",];  TABLE.test.NEW.M1.goana.UP11[,"UP.DOWN"]="up" ;  TABLE.test.NEW.M1.goana.UP11[,"Method"]= "goana1"
##head(TABLE.test.NEW.M1.goana.UP11[,c(1:10)]);  head(TABLE.test.NEW.M1.goana.UP);  print("");  dim(TABLE.test.NEW.M1.goana.UP11);  dim(TABLE.test.NEW.M1.goana.UP)
##TABLE.test.NEW.M1.goana.UP11[,paste("T"   , test_run,".",c(RNAseq..Models.Alg..Lima.VEC,RNAseq..Models.Alg..DESeq.VEC,RNAseq..Models.Alg..edgeR.VEC),sep="")]= NA
##TABLE.test.NEW.M1.goana.UP11[,paste("TEST", test_run,".",c(RNAseq..Models.Alg..Unique.VEC),sep="")]= NA
##TABLE.test.NEW.M1.goana.UP11[,paste("TEST", test_run,".",c(RNAseq..Models.Alg..Unique.VEC),sep="")]= NA
##TABLE.test.NEW.M1.goana.UP11[,paste("Test", test_run,".",c(".A")                          ,sep="")]= NA

###################################################### FFF.RNAseq..JOIN.Algorithms.Tables.Togo { 2019 
######################################################            
GO.Kegga.Model1..USE.goana= GO.Kegga.Model1[GO.Kegga.Model1[,"Method"]=="goana1",];			GO.Kegga.Model2..USE.goana= GO.Kegga.Model2[GO.Kegga.Model2[,"Method"]=="goana2",]
GO.Kegga.Model1..USE.kegga= GO.Kegga.Model1[GO.Kegga.Model1[,"Method"]=="kegga1",];			GO.Kegga.Model2..USE.kegga= GO.Kegga.Model2[GO.Kegga.Model2[,"Method"]=="kegga2",];
if((nrow(GO.Kegga.Model1..USE.goana)+nrow(GO.Kegga.Model1..USE.kegga))!=nrow(GO.Kegga.Model1)) stop("MIAN ERROR ---> nrow(GO.Kegga.Model1..USE.goana)+nrow(GO.Kegga.Model1..USE.kegga))!=nrow(GO.Kegga.Model1)")
if((nrow(GO.Kegga.Model2..USE.goana)+nrow(GO.Kegga.Model2..USE.kegga))!=nrow(GO.Kegga.Model2)) stop("MIAN ERROR ---> nrow(GO.Kegga.Model2..USE.goana)+nrow(GO.Kegga.Model2..USE.kegga))!=nrow(GO.Kegga.Model2)")
#########################
GO.Kegga.Model1..USE.goana= GO.Kegga.Model1..USE.goana[GO.Kegga.Model1..USE.goana[,"Model"]!="ALL",];		GO.Kegga.Model2..USE.goana= GO.Kegga.Model2..USE.goana[GO.Kegga.Model2..USE.goana[,"Model"]!="ALL",]
GO.Kegga.Model1..USE.kegga= GO.Kegga.Model1..USE.kegga[GO.Kegga.Model1..USE.kegga[,"Model"]!="ALL",];		GO.Kegga.Model2..USE.kegga= GO.Kegga.Model2..USE.kegga[GO.Kegga.Model2..USE.kegga[,"Model"]!="ALL",]
#########################
Use.Col.Max.Mean..KEKE= c(".All")[1]
#######
RUN.Togo..KEKE=c(1,2,3,4)[2];  TABLE.test.NEW.M1.goana.UP  = FFF.RNAseq..JOIN.Algorithms.Tables.Togo(RUN.Togo..KEKE, GO.Kegga.Model1..USE.goana, test_run..KEKE, Use.Col.Max.Mean..KEKE, -1, MIN.P.Value.Path..KEKE, -1, print.GO.path..KEKE)
#######
RUN.Togo..KEKE=c(1,2,3,4)[3];  TABLE.test.NEW.M1.goana.DOWN= FFF.RNAseq..JOIN.Algorithms.Tables.Togo(RUN.Togo..KEKE, GO.Kegga.Model1..USE.goana, test_run..KEKE, Use.Col.Max.Mean..KEKE, -1, MIN.P.Value.Path..KEKE, -1, print.GO.path..KEKE)
#######
RUN.Togo..KEKE=c(1,2,3,4)[2];  TABLE.test.NEW.M1.Kegga.UP  = FFF.RNAseq..JOIN.Algorithms.Tables.Togo(RUN.Togo..KEKE, GO.Kegga.Model1..USE.kegga, test_run..KEKE, Use.Col.Max.Mean..KEKE, -1, MIN.P.Value.Path..KEKE, -1, print.GO.path..KEKE)
#######
RUN.Togo..KEKE=c(1,2,3,4)[3];  TABLE.test.NEW.M1.Kegga.DOWN= FFF.RNAseq..JOIN.Algorithms.Tables.Togo(RUN.Togo..KEKE, GO.Kegga.Model1..USE.kegga, test_run..KEKE, Use.Col.Max.Mean..KEKE, -1, MIN.P.Value.Path..KEKE, -1, print.GO.path..KEKE)
#######
RUN.Togo..KEKE=c(1,2,3,4)[4];  TABLE.test.NEW.M2.goana     = FFF.RNAseq..JOIN.Algorithms.Tables.Togo(RUN.Togo..KEKE, GO.Kegga.Model2..USE.goana, test_run..KEKE, Use.Col.Max.Mean..KEKE, -1, MIN.P.Value.Path..KEKE, -1, print.GO.path..KEKE)
#######
RUN.Togo..KEKE=c(1,2,3,4)[4];  TABLE.test.NEW.M2.Kegga     = FFF.RNAseq..JOIN.Algorithms.Tables.Togo(RUN.Togo..KEKE, GO.Kegga.Model2..USE.kegga, test_run..KEKE, Use.Col.Max.Mean..KEKE, -1, MIN.P.Value.Path..KEKE, -1, print.GO.path..KEKE)
#######
TXT.JOIN.filters.go.Kegga..KEKE= TXT.Main.filters..FF;   rm(TXT.Main.filters..FF, COL.SAVE..TABLE..pvlues..FF, COL.SAVE..TABLE.test.NEW..FF, envir = globalenv()) 

######################################################
###################################################### 
if(RUN.goana.Kegga..for.Plot..KEKE<0 | RUN.goana.Kegga..for.Plot..KEKE>2) stop(paste(" MAIN ERROR --> scrip with only RUN.goana.Kegga..for.Plot..KEKE==0,1,,,,6  -->",RUN.goana.Kegga..for.Plot..KEKE))
#######
if(RUN.goana.Kegga..for.Plot..KEKE==1) {
	GO.Kegga.Model1..FFF       <<- GO.Kegga.Model1
	GO.Kegga.Model2..FFF       <<- GO.Kegga.Model2
	GO.Kegga.TXT.filters..FFF  <<- GO.Kegga.TXT.filters..KEKE
	#####
	### rm(GO.Kegga.Model1..FFF, GO.Kegga.Model2..FFF, GO.Kegga.TXT.filters..FFF, envir = globalenv())   
};
#######
if(RUN.goana.Kegga..for.Plot..KEKE==2) {
	#######
	TABLE.test.NEW.M1.goana.UP..FFF    <<- TABLE.test.NEW.M1.goana.UP
	TABLE.test.NEW.M1.goana.DOWN..FFF  <<- TABLE.test.NEW.M1.goana.DOWN
	TABLE.test.NEW.M1.Kegga.UP..FFF    <<- TABLE.test.NEW.M1.Kegga.UP
	TABLE.test.NEW.M1.Kegga.DOWN..FFF  <<- TABLE.test.NEW.M1.Kegga.DOWN
	TABLE.test.NEW.M2.goana..FFF       <<- TABLE.test.NEW.M2.goana     
	TABLE.test.NEW.M2.Kegga..FFF       <<- TABLE.test.NEW.M2.Kegga 
	#######
	GO.Kegga.TXT.filters..FFF          <<- GO.Kegga.TXT.filters..KEKE
	TXT.JOIN.filters.go.Kegga..FFF     <<- TXT.JOIN.filters.go.Kegga..KEKE
	#####
	### rm(TABLE.test.NEW.M1.goana.UP..FFF, TABLE.test.NEW.M1.goana.DOWN..FFF, TABLE.test.NEW.M1.Kegga.UP..FFF, TABLE.test.NEW.M1.Kegga.DOWN..FFF, TABLE.test.NEW.M2.goana..FFF, TABLE.test.NEW.M2.Kegga..FFF, GO.Kegga.TXT.filters..FFF, TXT.JOIN.filters.go.Kegga..FFF, envir = globalenv())
	return("NADA")  
	stop("MAIN error --> function continue")  
};

###################################################### FFF.RNAseq..JOIN.Algorithms.Percetage
###################################################### 
TABLE.Percetage.M1.goana.UP  = FFF.RNAseq..JOIN.Algorithms.Percetage(TABLE.test.NEW.M1.goana.UP  , test_run..KEKE, print.GO.path..KEKE)
TABLE.Percetage.M1.goana.DOWN= FFF.RNAseq..JOIN.Algorithms.Percetage(TABLE.test.NEW.M1.goana.DOWN, test_run..KEKE, print.GO.path..KEKE)
TABLE.Percetage.M1.Kegga.UP  = FFF.RNAseq..JOIN.Algorithms.Percetage(TABLE.test.NEW.M1.Kegga.UP  , test_run..KEKE, print.GO.path..KEKE)
TABLE.Percetage.M1.Kegga.DOWN= FFF.RNAseq..JOIN.Algorithms.Percetage(TABLE.test.NEW.M1.Kegga.DOWN, test_run..KEKE, print.GO.path..KEKE)
TABLE.Percetage.M2.goana     = FFF.RNAseq..JOIN.Algorithms.Percetage(TABLE.test.NEW.M2.goana     , test_run..KEKE, print.GO.path..KEKE)
TABLE.Percetage.M2.Kegga     = FFF.RNAseq..JOIN.Algorithms.Percetage(TABLE.test.NEW.M2.Kegga     , test_run..KEKE, print.GO.path..KEKE)
#######
TABLE.Per00= TABLE.Percetage.M1.goana.UP[1:2,];   TABLE.Per00[1,]="";  TABLE.Per00[2,]="####"  
TABLE.Percetage..TOGO= rbind(TABLE.Percetage.M1.goana.UP, TABLE.Per00, TABLE.Percetage.M1.goana.DOWN, TABLE.Per00, TABLE.Percetage.M1.Kegga.UP, TABLE.Per00, TABLE.Percetage.M1.Kegga.DOWN, TABLE.Per00, TABLE.Percetage.M2.goana, TABLE.Per00, TABLE.Percetage.M2.Kegga)

##############################################################
goana.kegga..KEKE= goana.kegga..KEKE[,c(COLNAMES.SAVE..KEKE)];    ## head(goana.kegga..KEKE)
#######
TABLE.Percetage..TOGO..FF <<- TABLE.Percetage..TOGO
return(goana.kegga..KEKE)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..Special.Genes.list= function(Data.Special.Genes..GeGe, Special.Pathways..GeGe, TABLE.ALL.JOIN..GeGe=TABLE.ALL.JOIN, TABLE.SAVE.TOGO..GeGe= TABLE.SAVE.TOGO, DIR_Annotations.Organism..GeGe= DIR_Annotations.Organism, 
                                         MIN.P.logFC.GeGe=c(1,1.2,2)[1], MIN.P.Value.GeGe=0.05, MIN.FDR.GeGe= c(0.05,0.1,0.5,1)[1], MAX.MEAN.GeGe= c(".Max",".Mean") ) {

#### DIR_Annotations.Organism..GeGe= DIR_Annotations.Organism; MIN.P.logFC.GeGe=MIN.logFC..Res.GO;   MIN.P.Value.GeGe=MAX.PValue..Res.GO;   MIN.FDR.GeGe= MAX.FDR.GO.USE;   MAX.MEAN.GeGe= COL.MAX.MEAN..Res.GO
#### Data.Special.Genes..GeGe=RNAseq..Data.Special.Genes.list;   Special.Pathways..GeGe=RNAseq..Special.Pathways..List;   TABLE.ALL.JOIN..GeGe=TABLE.ALL.JOIN.plot;   TABLE.SAVE.TOGO..GeGe= TABLE.SAVE.TOGO;     

####################################  
COLNAMES.SAVE..GeGe= colnames(TABLE.SAVE.TOGO..GeGe)
ROWS.Genes..GeGe= 0;  if(length(Data.Special.Genes..GeGe)>0) ROWS.Genes..GeGe= ncol(Data.Special.Genes..GeGe)-1
############# 
TABLE1.Special.Genes..GeGe= as.data.frame(array(NA,c(         ROWS.Genes..GeGe     ,length(COLNAMES.SAVE..GeGe))),stringsFactors=F);   colnames(TABLE1.Special.Genes..GeGe)= COLNAMES.SAVE..GeGe
TABLE2.Special.Genes..GeGe= as.data.frame(array(NA,c(length(Special.Pathways..GeGe),length(COLNAMES.SAVE..GeGe))),stringsFactors=F);   colnames(TABLE2.Special.Genes..GeGe)= COLNAMES.SAVE..GeGe
############# 
Special.Pathways..YES..GeGe= c()
if(length(Data.Special.Genes..GeGe)>0) {
	############# 
	TABLE1.Special.Genes..GeGe[,c("Selection","Ont","N","genes.GoTo1","genes.GoTo2","genes.GoTo3","genes.Up","genes.Down")]= NA
	TABLE1.Special.Genes..GeGe[,COLNAMES.SAVE..GeGe[grep("##",COLNAMES.SAVE..GeGe,fixed=TRUE)]]="###"
	TABLE1.Special.Genes..GeGe[,"User"]= "Gene-List";   TABLE1.Special.Genes..GeGe[,"Ont"]= "."
	#############
	COl.Special.gene.List..GeGe= colnames(Data.Special.Genes..GeGe);  COl.Special.gene.List..GeGe= COl.Special.gene.List..GeGe[COl.Special.gene.List..GeGe!="ROWS"]
	#######
	RR..GeGe=0;  
	if(length(COl.Special.gene.List..GeGe)>0) for(CC..GeGe in COl.Special.gene.List..GeGe) {   ## CC..GeGe=COl.Special.gene.List..GeGe[1]
		RR..GeGe= RR..GeGe + 1
		#########
		GENE.list..Ge.ge= Data.Special.Genes..GeGe[!is.na(Data.Special.Genes..GeGe[,CC..GeGe]),CC..GeGe]
		#########
		GENE.list..Ge.ge.yes= TABLE.ALL.JOIN..GeGe[TABLE.ALL.JOIN..GeGe[,CC..GeGe]!="","gene.PLOT"  ];  GENE.list..Ge.ge.yes= GENE.list..Ge.ge.yes[!is.na(GENE.list..Ge.ge.yes)]
		GENE.list.ID..ge.yes= TABLE.ALL.JOIN..GeGe[TABLE.ALL.JOIN..GeGe[,CC..GeGe]!="","RawPro.gene"];  GENE.list.ID..ge.yes= GENE.list.ID..ge.yes[!is.na(GENE.list.ID..ge.yes)]
		if(length(GENE.list.ID..ge.yes)!=length(GENE.list..Ge.ge.yes)) stop(paste("MAIN ERROR --->  length(GENE.list..Ge.ge.yes)!=length(GENE.list..Ge.ge.yes)  ", length(GENE.list..Ge.ge.yes),"!=",length(GENE.list..Ge.ge.yes) ))
		#########
		if(length(GENE.list..Ge.ge    )>1) GENE.list..Ge.ge    = unique(GENE.list..Ge.ge    [order(GENE.list..Ge.ge    )])
		if(length(GENE.list..Ge.ge.yes)>1) GENE.list..Ge.ge.yes= unique(GENE.list..Ge.ge.yes[order(GENE.list..Ge.ge.yes)])
		#########
		TABLE1.Special.Genes..GeGe[RR..GeGe,"TNgenes.GoTo"]= length(GENE.list..Ge.ge    );   TABLE1.Special.Genes..GeGe[RR..GeGe,"N"]= length(GENE.list..Ge.ge)
		TABLE1.Special.Genes..GeGe[RR..GeGe, "Ngenes.GoTo"]= length(GENE.list..Ge.ge.yes)
		if(length(GENE.list..Ge.ge.yes)>0) TABLE1.Special.Genes..GeGe[RR..GeGe,  "genes.GoTo"]=  paste(GENE.list..Ge.ge.yes, collapse=",")
		if(length(GENE.list.ID..ge.yes)>0) TABLE1.Special.Genes..GeGe[RR..GeGe, "GeneID.GoTo"]=  paste(GENE.list.ID..ge.yes, collapse=",")
		#########
		TABLE1.Special.Genes..GeGe[RR..GeGe,c("RawPro.gene")]= paste("Gene-List:",RR..GeGe,sep="")
		TABLE1.Special.Genes..GeGe[RR..GeGe,c(   "Pathway" )]= paste(             CC..GeGe,sep="")
		TABLE1.Special.Genes..GeGe[RR..GeGe,c("Method"     )]= "Gene-List"
		TABLE1.Special.Genes..GeGe[RR..GeGe,c("UP.DOWN"    )]= "Gene-List"
		#########
		GENE.list..Ge.ge.yes.UP  = TABLE.ALL.JOIN..GeGe[TABLE.ALL.JOIN..GeGe[,CC..GeGe]!="" & TABLE.ALL.JOIN..GeGe[,paste("Filters",MAX.MEAN.GeGe,sep="")]!="NOT PASS" & as.numeric(TABLE.ALL.JOIN..GeGe[,paste("logFC",MAX.MEAN.GeGe,sep="")])>=  MIN.P.logFC.GeGe,"gene.PLOT"];  if(length(GENE.list..Ge.ge.yes.UP  )>0) GENE.list..Ge.ge.yes.UP  = GENE.list..Ge.ge.yes.UP  [!is.na(GENE.list..Ge.ge.yes.UP  )] 
		GENE.list..Ge.ge.yes.DOWN= TABLE.ALL.JOIN..GeGe[TABLE.ALL.JOIN..GeGe[,CC..GeGe]!="" & TABLE.ALL.JOIN..GeGe[,paste("Filters",MAX.MEAN.GeGe,sep="")]!="NOT PASS" & as.numeric(TABLE.ALL.JOIN..GeGe[,paste("logFC",MAX.MEAN.GeGe,sep="")])<= -MIN.P.logFC.GeGe,"gene.PLOT"];  if(length(GENE.list..Ge.ge.yes.DOWN)>0) GENE.list..Ge.ge.yes.DOWN= GENE.list..Ge.ge.yes.DOWN[!is.na(GENE.list..Ge.ge.yes.DOWN)] 
		######### 
		if(length(GENE.list..Ge.ge.yes.UP  )>0) TABLE1.Special.Genes..GeGe[RR..GeGe,"genes.Up"  ]= paste(GENE.list..Ge.ge.yes.UP  , collapse=",") 
		if(length(GENE.list..Ge.ge.yes.DOWN)>0) TABLE1.Special.Genes..GeGe[RR..GeGe,"genes.Down"]= paste(GENE.list..Ge.ge.yes.DOWN, collapse=",")
		#########
		TABLE1.Special.Genes..GeGe[RR..GeGe,"Per.A"]= paste(as.integer((10*100*length(unique(c(GENE.list..Ge.ge.yes.UP, GENE.list..Ge.ge.yes.DOWN))))/length(GENE.list..Ge.ge.yes))/10,"%",sep="")
}	}
if(length(Special.Pathways..GeGe)>0) {
	Special.Pathways..GeGe= unique(Special.Pathways..GeGe);    
	#########
	Special.Path.ID..GeGe= c();   Special.Path.Name..GeGe= c();
	#########
	for(Path.GeGe in Special.Pathways..GeGe){ 
		AAA= unlist(strsplit(Path.GeGe, " --> ", fixed=TRUE));  
		if(length(AAA)==1){ Special.Path.ID..GeGe= c(Special.Path.ID..GeGe, AAA   );   Special.Path.Name..GeGe=c(Special.Path.Name..GeGe,  ""   ) }
		if(length(AAA)==2){ Special.Path.ID..GeGe= c(Special.Path.ID..GeGe, AAA[1]);   Special.Path.Name..GeGe=c(Special.Path.Name..GeGe, AAA[2]) }
		if(length(AAA)>=3 | length(AAA)<=0) stop(paste("MAIN ERROR --->  length(AAA)>=3 | length(AAA)<=0 --->  ", length(AAA) ))
	};  if(length(Special.Path.Name..GeGe)!=length(Special.Path.ID..GeGe)) stop(paste("MAIN ERROR --->  length(Special.Path.Name..GeGe)!=length(Special.Path.ID..GeGe) --->  ", length(Special.Path.Name..GeGe),"!=", length(Special.Path.ID..GeGe) ))
	#########
	Special.Path.Name..GeGe= paste("Path",c(1:length(Special.Path.Name..GeGe))," --> ",Special.Path.Name..GeGe,sep="")
	#########
	Special.Path.goana.kegga..GeGe=c();  for(ID.gona in Special.Path.ID..GeGe){
		if(length(grep("GO:"  ,ID.gona,fixed=TRUE))>0) Special.Path.goana.kegga..GeGe=c(Special.Path.goana.kegga..GeGe, "goana")
		if(length(grep("path:",ID.gona,fixed=TRUE))>0) Special.Path.goana.kegga..GeGe=c(Special.Path.goana.kegga..GeGe, "kegga")
	}
	if(length(Special.Path.goana.kegga..GeGe)!=length(Special.Path.ID..GeGe)) stop(paste("MAIN ERROR --->  length(Special.Path.goana.kegga..GeGe)!=length(Special.Path.ID..GeGe) --->  ", length(Special.Path.goana.kegga..GeGe),"!=", length(Special.Path.ID..GeGe) ))
	#########
	TABLE2.Special.Genes..GeGe[,c("Selection","Ont","N","genes.GoTo1","genes.GoTo2","genes.GoTo3")]= NA
	TABLE2.Special.Genes..GeGe[,COLNAMES.SAVE..GeGe[grep("##",COLNAMES.SAVE..GeGe,fixed=TRUE)]]="###"
	TABLE2.Special.Genes..GeGe[,"User"]= "Path-List";   TABLE2.Special.Genes..GeGe[,"Ont"]= "."
	#########
	TABLE2.Special.Genes..GeGe[,c("TNgenes.GoTo","Ngenes.GoTo")]= 0
	TABLE2.Special.Genes..GeGe[,c("genes.GoTo"  ,"GeneID.GoTo")]= NA
	#########
	TABLE2.Special.Genes..GeGe[,"RawPro.gene"]= Special.Path.ID..GeGe;    #print(Special.Path.ID..GeGe)
	TABLE2.Special.Genes..GeGe[,   "Pathway" ]= Special.Path.Name..GeGe
	TABLE2.Special.Genes..GeGe[,"Method"     ]= Special.Path.goana.kegga..GeGe
	TABLE2.Special.Genes..GeGe[,"UP.DOWN"    ]= "Path-List"
	#########  
	for(Path.GeGe in Special.Path.ID..GeGe) if(length(TABLE.SAVE.TOGO..GeGe[TABLE.SAVE.TOGO..GeGe[,"RawPro.gene"]==Path.GeGe,"RawPro.gene"])>0) {
		Special.Pathways..YES..GeGe= c(Special.Pathways..YES..GeGe, Path.GeGe)
		TABLE2.Special.Genes..GeGe= TABLE2.Special.Genes..GeGe[TABLE2.Special.Genes..GeGe[,"RawPro.gene"]!=Path.GeGe,]
	}
	######################
	if(nrow(TABLE2.Special.Genes..GeGe)>0){
		print.genes..GeGe=c(1,2,0)[1];     Stop_NOT.FINDING..GeGe=c(1,0)[2];		  COL..RawPro.gene..GeGe="RawPro.gene";      COL..Gene.NAME..GeGe="gene.PLOT";     COL..Method..GeGe= "Method";
		COL.GENES..GeGe= c("TNgenes.GoTo","Ngenes.GoTo","genes.GoTo","GeneID.GoTo",   "N.Yes","N.Up","N.Down","N.both","genes.Up","genes.Down","genes.both");
		TABLE2.Special.Genes..GeGe[,COL.GENES..GeGe]= FFF.RNAseq..Obtain.genes.GO.KEGG(TABLE2.Special.Genes..GeGe, TABLE.ALL.JOIN..GeGe, TABLE.ALL.JOIN..GeGe[0,], DIR_Annotations.Organism..GeGe, print.genes..GeGe, Stop_NOT.FINDING..GeGe, COL..RawPro.gene..GeGe, COL..Gene.NAME..GeGe, COL..Method..GeGe, MIN.P.logFC.GeGe, MIN.P.Value.GeGe, MIN.FDR.GeGe, MAX.MEAN.GeGe, c() )
		rm(ERROR.NOT.find.gene..FF, envir = globalenv()) 
		TABLE2.Special.Genes..GeGe[,"N"]= TABLE2.Special.Genes..GeGe[,"TNgenes.GoTo"]
	}
	#########
	print(paste("Special pathways:   YES =", (length(Special.Pathways..GeGe)-nrow(TABLE2.Special.Genes..GeGe)),"    NO =", nrow(TABLE2.Special.Genes..GeGe) ));  print("")
	#########
}

##############################################################
Special.Pathways..YES..FF <<- Special.Pathways..YES..GeGe
TABLE2.Special.Genes..FF  <<- TABLE2.Special.Genes..GeGe
return(TABLE1.Special.Genes..GeGe)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################

                       
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..Obtain.genes.GO.KEGG= function(TABLE.TOGO..GGG, TABLE.JOIN..GGG, TABLEs.ALL.ALL..GGG, DIR_Annotations.Organism.GOGO, print.genes.GO.KEGG=c(1,2,0)[2], Stop_error.NOT.FINDING..GGG=c(1,0)[1], COL..RawPro.gene..GGG="RawPro.gene", 
                                           COL..Gene.NAME..GGG="gene.PLOT", COL..Method..GGG="Method", MIN.P.logFC.GOGO=c(1,1.2,2)[1], MIN.P.Value.GOGO=0.05, MIN.FDR.GOGO= c(0.05,0.1,0.5,1)[1], MAX.MEAN.GOGO= c(".Max",".Mean"), CASE.Model.VEC.GGG= CASE.Model.VEC.GO ) {

#### TABLE.TOGO..GGG= TABLE.SAVE.TOGO;      TABLE.JOIN..GGG= Counts.gene.PLOT;    DIR_Annotations.Organism.GOGO= DIR_Annotations.Organism;    COL..RawPro.gene..GGG="RawPro.gene";   COL..Gene.NAME..GGG=COL..Gene.NAME.GO;   COL..Method..GGG=COL..Method.GO
#### TABLE.JOIN..GGG= TABLE.ALL.JOIN.plot
#### print.genes.GO.KEGG=c(1,2,0)[1];   Stop_error.NOT.FINDING..GGG=c(1,0)[2];   ##COL.GENES.GO.KEGG..GGG= c("TNgenes.GoTo","Ngenes.GoTo","genes.GoTo","GeneID.GoTo")

#### sript 3
#### TABLE.TOGO..GGG= TABLE.SAVE.TOGO; TABLE.JOIN..GGG=TABLE.ALL.JOIN.plot; TABLEs.ALL.ALL..GGG=TABLEs.ALL.ALL.Plot;    DIR_Annotations.Organism.GOGO=DIR_Annotations.Organism;    print.genes.GO.KEGG=print.genes.GO;    Stop_error.NOT.FINDING..GGG=c(1,0)[1]; 
#### COL..RawPro.gene..GGG= c("RawPro.gene",COL..RawPro.gene.GO)[2]; COL..Gene.NAME..GGG=COL..Gene.NAME.GO; COL..Method..GGG=COL..Method.GO;    MIN.P.logFC.GOGO=MIN.logFC..Res.GO; MIN.P.Value.GOGO=MAX.PValue..Res.GO; MIN.FDR.GOGO= MAX.FDR.GO.USE; MAX.MEAN.GOGO= COL.MAX.MEAN..Res.GO; CASE.Model.VEC.GGG= CASE.Model.VEC.GO;

################################################################################################################ {
################################################################################################################
if(print.genes.GO.KEGG>0) print(paste("############ FFF.RNAseq..Obtain.genes.GO.KEGG        --> rows ==>", nrow(TABLE.TOGO..GGG),"        ", date()  ))  
####
RUNNIGN.OLD.Method..GGG= c(0,1)[1]

##############################################################
COL.TNgenes.GoTo= "TNgenes.GoTo";   COL.Ngenes.GoTo= "Ngenes.GoTo";   COL.genes.GoTo= "genes.GoTo";  COL.GeneID.GoTo= "GeneID.GoTo";
########
COL.GENES.GO.KEGG..GGG= c(COL.TNgenes.GoTo,COL.Ngenes.GoTo,COL.genes.GoTo,COL.GeneID.GoTo, "N.Yes","N.Up","N.Down","N.both","genes.Up","genes.Down","genes.both")
####################
TXT.Test.Algortitms..PP="T";      TXT.Test.MAIN..PP="Test";      TXT.Test.JoinT..PP="TEST"
########
COL..P.DE= paste(TXT.Test.MAIN..PP,test_RUN.Model,".P.DE",sep="");   COL..P.Up= paste(TXT.Test.MAIN..PP,test_RUN.Model,".P.Up",sep="");    COL..P.Down= paste(TXT.Test.MAIN..PP,test_RUN.Model,".P.Down",sep="")
	
##############################################################
if(RUNNIGN.OLD.Method..GGG==0){
	if(!exists("Go.KEGG.GeneLinks..MAIN.GENES..FFF")) stop("MAIN ERROR  --> !exists(Go.KEGG.GeneLinks..MAIN.GENES..FFF)  --> you need to run function = FFF.RNAseq..Path.analysis..Load.MAIN.GENE.PATH.files ")
} else {
########
#library(GO.db)  #if(DIR_Annotations.Organism.GOGO=="Homo_sapiens") require(org.Hs.eg.db);  if(DIR_Annotations.Organism.GOGO=="Mus_musculus") require(org.Mm.eg.db)
########
SPECIES.GO.keg=c()
if(DIR_Annotations.Organism.GOGO=="Homo_sapiens"     ){ SPECIES.GO.keg= "hsa";     go_object..GGG = as.list(org.Hs.egGO2EG) }    ##3 go_object..GGG = as.list(org.Hs.egGO2EG);  go_object..GGG = as.list(org.Hs.egGO2EG);
if(DIR_Annotations.Organism.GOGO=="Mus_musculus"     ){ SPECIES.GO.keg= "mmu";     go_object..GGG = as.list(org.Mm.egGO2EG) }    ##3 go_object..GGG = as.list(org.Mm.egGO2EG);
if(DIR_Annotations.Organism.GOGO=="Rattus_norvegicus"){ SPECIES.GO.keg= "rno";     go_object..GGG = as.list(org.Rn.egGO2EG) }    ##3 go_object..GGG = as.list(org.Mm.egGO2EG);
if(length(SPECIES.GO.keg) >0) KEGGLinks..GGG = getGeneKEGGLinks(species.KEGG = SPECIES.GO.keg)
########
if(length(SPECIES.GO.keg)<=0) stop(paste("MAIN error --> Library for genes ID and GO.TO and KEGGS is not available --> please add it --> ", DIR_Annotations.Organism.GOGO ))

############################################################## go_ORG.MATRIX.GGG (download file from page (http://geneontology.org/docs/download-go-annotations/)
DIR.GO.ORG..GGG= paste(DIR_RNAseq..Annot.Genes,DIR_Annotations.Organism.GOGO,"/",RNAseq..Version..Gene.info,sep="")
if(DIR_Annotations.Organism.GOGO=="Homo_sapiens"     ) FILE.GO.ORG..GGG= "goa_human.gaf"
if(DIR_Annotations.Organism.GOGO=="Mus_musculus"     ) FILE.GO.ORG..GGG= "mgi.gaf"
if(DIR_Annotations.Organism.GOGO=="Rattus_norvegicus") FILE.GO.ORG..GGG= "rgd.gaf"
########
go_ORG.MATRIX.GGG= read.delim( paste(DIR.GO.ORG..GGG,"/",FILE.GO.ORG..GGG,sep=""), header=FALSE, stringsAsFactors=F);    print(paste(" Loading GO data base --> Version=",RNAseq..Version..Gene.info,"      file=", FILE.GO.ORG..GGG))
go_USE.MATRIX.GGG= unique(go_ORG.MATRIX.GGG[,c("V3","V5")]);  colnames(go_USE.MATRIX.GGG)= c("gene","GO:id")  
##head(go_USE.MATRIX.GGG);  tail(go_USE.MATRIX.GGG);  dim(go_ORG.MATRIX.GGG);  dim(go_USE.MATRIX.GGG);  

############################################################## 
##############################################################
####################### map GO terms to Entrez gene ids
### https://davetang.org/muse/2010/11/10/gene-ontology-enrichment-analysis/
## 
## library(GO.db)
## cyt.go <- c("GO:0097164", "GO:0046470", "GO:0006576")
## term <- select(GO.db, keys=cyt.go, columns="TERM")
#######################
## KEGGLinks$GeneID[KEGGLinks$PathwayID=="path:mmu00010"]
##############################################
## go_object <- as.list(org.Mm.egGO2EG);   ### go_object <- as.list(org.Hs.egGO2EG)
## axon_gene= go_object['GO:0007411'];   gene.list= unlist(axon_gene, use.names=F)
## unlist(go_object['GO:0140074'], use.names=F) >> "10512" >> web(Entrez gene ids "10512") >> SEMA3C ;  web(GO:0140074) >> SEMA3C  ==> perfect
#######################
##library(GO.db)
##cyt.go <- c("GO:0097164", "GO:0046470", "GO:0006576")
##term <- select(GO.db, keys=cyt.go, columns="TERM")			
##go_id = GOID( GOTERM[ Term(GOTERM) == "chromatin remodeling"])
##############################################################
}

##############################################################
##############################################################    
ERROR.NOT.find.gene..GG= c();
if(nrow(TABLE.TOGO..GGG)>0 & nrow(TABLE.JOIN..GGG)>0) {
	################
	##TABLE.JOIN..GGG[,COL..RawPro.gene..GGG]= rownames(TABLE.JOIN..GGG)
	################
	TABLE.TOGO..GGG[,COL.GENES.GO.KEGG..GGG]= "";   TABLE.TOGO..GGG[,c(COL.TNgenes.GoTo,COL.Ngenes.GoTo)]= -1;   TABLE.TOGO..GGG[,c("N.Yes","N.Up","N.Down","N.both")]= 0;   
	################################
	conta.gona.GG=0;     conta.kegga.GG=0;   NO.gona.GG=0;     NO.kegga.GG=0;
	if(nrow(TABLE.TOGO..GGG)>0) {
		goana.kegga.VEC..GG= unique(TABLE.TOGO..GGG[,COL..RawPro.gene..GGG])
		################
		for(go.keg.G in goana.kegga.VEC..GG) {    ## go.keg.G=goana.kegga.VEC..GG[1];   ##go.keg.G="GO:0044421"
			############ 
			goana.kegga.YES..GG= TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,COL..Method..GGG]
			#####
			RUN.goona=0;  if(length(grep("goana",goana.kegga.YES..GG,fixed=TRUE))>0) RUN.goona=1
			RUN.kegga=0;  if(length(grep("kegga",goana.kegga.YES..GG,fixed=TRUE))>0) RUN.kegga=1
			#####
			if(RUN.goona==0 & RUN.kegga==0) stop(paste("MAIN ERROR -->  no method is ready for run  -->",RUN.goona,"-",RUN.kegga))
			if(RUN.goona==1 & RUN.kegga==1) stop(paste("MAIN ERROR -->  2 methods for run --> error -->",RUN.goona,"-",RUN.kegga))
			#####
			if(RUNNIGN.OLD.Method..GGG==1){
				if(RUN.goona==1 & RUN.kegga==0) {
					gene.all.list.GG1= unlist(go_USE.MATRIX.GGG[go_USE.MATRIX.GGG[,"GO:id"]==go.keg.G,"gene"])
					gene.all.list.GG2= unlist(go_object..GGG[go.keg.G], use.names=F)
					gene.all.list.GG= c(gene.all.list.GG1, gene.all.list.GG2)
				}
				if(RUN.goona==0 & RUN.kegga==1) gene.all.list.GG= KEGGLinks..GGG$GeneID[KEGGLinks..GGG$PathwayID==go.keg.G]
			} else {
				gene.all.list.GG= Go.KEGG.GeneLinks..MAIN.GENES..FFF[Go.KEGG.GeneLinks..MAIN.GENES..FFF[,"PathwayID"]==go.keg.G,"GeneID"]
			}	
			#####
			gene.all.list.GG= gene.all.list.GG[!is.na(gene.all.list.GG)]; if(length(gene.all.list.GG)>0) gene.all.list.GG=gene.all.list.GG[gene.all.list.GG!="" & gene.all.list.GG!="." & gene.all.list.GG!="NA"]; 
			if(length(gene.all.list.GG)>1) gene.all.list.GG= unique(gene.all.list.GG)
			################
			TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,COL.TNgenes.GoTo]= length(gene.all.list.GG)
			##########
			if(length(gene.all.list.GG)<=0) {  ERROR.NOT.find.gene..GG= c(ERROR.NOT.find.gene..GG, go.keg.G)
				if(print.genes.GO.KEGG>1) print(paste("warning -->  no genes for this process in datasets  -->",go.keg.G))
				if(RUN.goona==1) NO.gona.GG= NO.gona.GG + 1;    if(RUN.kegga==1) NO.kegga.GG= NO.kegga.GG + 1
				TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,COL.Ngenes.GoTo]= 0
			} else {
				######
				if(RUN.goona==1) conta.gona.GG= conta.gona.GG + 1;    if(RUN.kegga==1) conta.kegga.GG= conta.kegga.GG + 1
				MMM.GG= match(gene.all.list.GG, TABLE.JOIN..GGG [,"Raw.geneID"]);    MMM.GG= MMM.GG[!is.na(MMM.GG)]
				######
				TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,COL.Ngenes.GoTo ]= length(MMM.GG)
				######
				if(length(MMM.GG)>0) {
					Genes.EntrezID.GG= TABLE.JOIN..GGG [MMM.GG,c("Raw.geneID",COL..Gene.NAME..GGG)];   colnames(Genes.EntrezID.GG)= c("XX.RAW","XX.GENE")   
					if(nrow(Genes.EntrezID.GG)>1) Genes.EntrezID.GG= unique(Genes.EntrezID.GG[order(Genes.EntrezID.GG[,"XX.GENE"]),])
					######
					TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,COL.genes.GoTo ]= paste(Genes.EntrezID.GG[,"XX.GENE"], collapse=",")
					TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,COL.GeneID.GoTo]= paste(Genes.EntrezID.GG[,"XX.RAW" ], collapse=",")
				}
				############
				RUN..JOIN.or.ALL.ALL..GGG= c(1,2)[2];  if(nrow(TABLEs.ALL.ALL..GGG)<=0) RUN..JOIN.or.ALL.ALL..GGG= c(1,2)[1]
				if(RUN..JOIN.or.ALL.ALL..GGG==1){ Counts.YES..GGG= TABLE.JOIN..GGG;       MAX.MEAN.GOGO.yy=MAX.MEAN.GOGO  }
				if(RUN..JOIN.or.ALL.ALL..GGG==2){ Counts.YES..GGG= TABLEs.ALL.ALL..GGG;   MAX.MEAN.GOGO.yy=""             }
				###### 
				if(RUN..JOIN.or.ALL.ALL..GGG==2) if(length(CASE.Model.VEC.GGG)>0) if(nrow(Counts.YES..GGG)>0) {
					Counts.YES..GGG[,"XX.SOFT"]=0;  for(CASE.ggg in CASE.Model.VEC.GGG) Counts.YES..GGG[Counts.YES..GGG[,"Model"]==CASE.ggg,"XX.SOFT"]=1
					Counts.YES..GGG= Counts.YES..GGG[Counts.YES..GGG[,"XX.SOFT"]==1,]
				} 
				######
				if(nrow(Counts.YES..GGG)>0){
					if(MIN.P.logFC.GOGO >0                      ) Counts.YES..GGG= Counts.YES..GGG[abs(as.numeric(Counts.YES..GGG[,paste("logFC" ,MAX.MEAN.GOGO.yy,sep="")]))>=MIN.P.logFC.GOGO,]
					if(MIN.P.Value.GOGO >0 & MIN.P.Value.GOGO <1) Counts.YES..GGG= Counts.YES..GGG[    as.numeric(Counts.YES..GGG[,paste("PValue",MAX.MEAN.GOGO.yy,sep="")]) <=MIN.P.Value.GOGO,]
					if(MIN.FDR.GOGO     >0 & MIN.FDR.GOGO     <1) Counts.YES..GGG= Counts.YES..GGG[    as.numeric(Counts.YES..GGG[,paste("FDR"   ,MAX.MEAN.GOGO.yy,sep="")]) <=MIN.FDR.GOGO    ,]
				}
				############   
				if(nrow(Counts.YES..GGG)>0) {
					MMM.YES.GG= match(gene.all.list.GG, Counts.YES..GGG[,"Raw.geneID"]);    MMM.YES.GG= MMM.YES.GG[!is.na(MMM.YES.GG)]
					######
					if(length(MMM.YES.GG)<=0){
						TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,c("N.Yes","N.Up","N.Down","N.both")]= 0
					} else {
						Genes.EntrezID.YES.GG= Counts.YES..GGG[MMM.YES.GG,c("Raw.geneID", COL..Gene.NAME..GGG,paste("logFC" ,MAX.MEAN.GOGO.yy,sep="") )];   colnames(Genes.EntrezID.YES.GG)= c("XX.RAW","XX.GENE","XX.logFC")  
						if(nrow(Genes.EntrezID.YES.GG)>1) Genes.EntrezID.YES.GG= unique(Genes.EntrezID.YES.GG[order(Genes.EntrezID.YES.GG[,"XX.GENE"]),])
						######
						Genes.ALL.YES.GG= unique(Genes.EntrezID.YES.GG[,"XX.GENE"])
						Genes.UP.YES.GG = unique(Genes.EntrezID.YES.GG[as.numeric(Genes.EntrezID.YES.GG[,"XX.logFC"]) >0,"XX.GENE"])
						Genes.DO.YES.GG = unique(Genes.EntrezID.YES.GG[as.numeric(Genes.EntrezID.YES.GG[,"XX.logFC"])<=0,"XX.GENE"])
						######
						Genes.DOBLEs.GG= c()
						if(RUN..JOIN.or.ALL.ALL..GGG==2) if(length(Genes.UP.YES.GG)>0 & length(Genes.DO.YES.GG)>0){
							MMM.DOBLE.GG= match(Genes.UP.YES.GG, Genes.DO.YES.GG);    MMM.DOBLE.GG= MMM.DOBLE.GG[!is.na(MMM.DOBLE.GG)]
							if(length(MMM.DOBLE.GG)>0){
								if( max(MMM.DOBLE.GG)> length(Genes.DO.YES.GG) ) stop("MAIN ERROR --->  max(MMM.DOBLE.GG)> length(Genes.DO.YES.GG)");    Genes.DOBLEs.GG= Genes.DO.YES.GG[MMM.DOBLE.GG]
								for(Gene.kk in Genes.DOBLEs.GG){   Genes.UP.YES.GG= Genes.UP.YES.GG[Genes.UP.YES.GG!=Gene.kk];  Genes.DO.YES.GG= Genes.DO.YES.GG[Genes.DO.YES.GG!=Gene.kk] }
						}	}
						######
						TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,"N.Yes" ]= length(Genes.ALL.YES.GG)
						TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,"N.Up"  ]= length(Genes.UP.YES.GG )
						TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,"N.Down"]= length(Genes.DO.YES.GG )
						TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,"N.both"]= length(Genes.DOBLEs.GG )
						######
						if(length(Genes.UP.YES.GG)>0) TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,"genes.Up"  ]= paste(Genes.UP.YES.GG, collapse=",")
						if(length(Genes.DO.YES.GG)>0) TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,"genes.Down"]= paste(Genes.DO.YES.GG, collapse=",")
						if(length(Genes.DOBLEs.GG)>0) TABLE.TOGO..GGG[TABLE.TOGO..GGG[,COL..RawPro.gene..GGG]==go.keg.G,"genes.both"]= paste(Genes.DOBLEs.GG, collapse=",")
	}	}	}	}	}
	OUT.TABLE..GGG= TABLE.TOGO..GGG[,COL.GENES.GO.KEGG..GGG]
	####################################
	if(nrow(TABLE.TOGO..GGG)>0){
		TABLE.TOGO..GGG[,"XX.test"]= as.integer(TABLE.TOGO..GGG[,"N.Yes"]) - as.integer(TABLE.TOGO..GGG[,"N.Up"]) - as.integer(TABLE.TOGO..GGG[,"N.Down"]) - as.integer(TABLE.TOGO..GGG[,"N.both"])
		ERROR.Nyes..gg= TABLE.TOGO..GGG[TABLE.TOGO..GGG[,"XX.test"]!=0,];   if(nrow(ERROR.Nyes..gg)>0){ print("");  print(head(ERROR.Nyes..gg));  stop(paste("MAIN ERROR -->  nrow(ERROR.Nyes..gg)>0  -->",nrow(ERROR.Nyes..gg) ))  }
	}
	####################################
	if(length(ERROR.NOT.find.gene..GG)>0) {
	   	######
	   	ERROR.NOT.find.gene..GG= unique(ERROR.NOT.find.gene..GG);    ERROR.NOT.find.gene..GG= ERROR.NOT.find.gene..GG[order(ERROR.NOT.find.gene..GG)]  
	   	PER.Error.GG= paste(format( (100*length(ERROR.NOT.find.gene..GG)/length(goana.kegga.VEC..GG)),digits = 2, nsmall = 2),"%",sep="")
	   	print(paste("WARNING  WARNING -->  no pathaway in datasets  -->",length(ERROR.NOT.find.gene..GG), "of",length(goana.kegga.VEC..GG),"  ",PER.Error.GG,"  ==> gonna=",NO.gona.GG,";   kegga=",NO.kegga.GG,"      YES ==>  gonna=",conta.gona.GG,";   kegga=",conta.kegga.GG ));
	    if(print.genes.GO.KEGG>1) { print(""); if(length(ERROR.NOT.find.gene..GG)>10){ print(head(ERROR.NOT.find.gene..GG, 4));    print(tail(ERROR.NOT.find.gene..GG, 4)) } else print(ERROR.NOT.find.gene..GG); }
	   	if(Stop_error.NOT.FINDING..GGG==1) stop("kaOs is stopping")
	   	######
	   	SUM.CONTA.ERROR.GG= conta.gona.GG+conta.kegga.GG+NO.gona.GG+ NO.kegga.GG;    SUM.ORG.ERROR.GG= length(goana.kegga.VEC..GG)  
	   	if(SUM.CONTA.ERROR.GG!=SUM.ORG.ERROR.GG) stop(paste("MAIN ERROR -->  SUM.CONTA.ERROR!=nrow(TABLE.TOGO..GGG)  -->",SUM.CONTA.ERROR.GG,"!=",SUM.ORG.ERROR.GG)) 
	   	######
	} else if(print.genes.GO.KEGG>0) print(paste("Perfect -->  all pathways were in datasets  -->",nrow(TABLE.TOGO..GGG),"   YES ==>  gonna=",conta.gona.GG,"        kegga=",conta.kegga.GG )); 	
	####################################
} else { OUT.TABLE..GGG= TABLE.TOGO..GGG[0,c(1:length(COL.GENES.GO.KEGG..GGG))];  colnames(OUT.TABLE..GGG)= COL.GENES.GO.KEGG..GGG }

##############################################################
ERROR.NOT.find.gene..FF <<- ERROR.NOT.find.gene..GG
return(OUT.TABLE..GGG)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..JOIN..Change.Columns.saving= function(TABLE.test.NEW..CC, print.Change.Columns.saving..CC=c(1,0)[1] ) {

################################################################################################################
################################################################################################################
if(print.Change.Columns.saving..CC>0) print(paste("############ FFF.RNAseq..JOIN..Change.Columns.saving     -->  rows=", nrow(TABLE.test.NEW..CC) ))

##############################################################
COL..SAVE.Corret..cc= colnames(TABLE.test.NEW..CC)
#####
COL..SAVE.Corret..cc= sub("Lima1"     ,"L1"  ,COL..SAVE.Corret..cc,fixed=TRUE);		COL..SAVE.Corret..cc= sub(   "Lima2"  ,"L2"  ,COL..SAVE.Corret..cc,fixed=TRUE)
COL..SAVE.Corret..cc= sub("Lima3-Voom","L3-V",COL..SAVE.Corret..cc,fixed=TRUE);		COL..SAVE.Corret..cc= sub("Lima4-Voom","L4-V",COL..SAVE.Corret..cc,fixed=TRUE)
#####
COL..SAVE.Corret..cc= sub("edgeR.ltr1","E1.l",COL..SAVE.Corret..cc,fixed=TRUE);		COL..SAVE.Corret..cc= sub("edgeR.ltr2","E2.l",COL..SAVE.Corret..cc,fixed=TRUE);
COL..SAVE.Corret..cc= sub("edgeR.qlf1","E1.q",COL..SAVE.Corret..cc,fixed=TRUE);		COL..SAVE.Corret..cc= sub("edgeR.qlf2","E2.q",COL..SAVE.Corret..cc,fixed=TRUE);
#####
COL..SAVE.Corret..cc= sub("DESeq1"    ,"D1"   ,COL..SAVE.Corret..cc,fixed=TRUE);	COL..SAVE.Corret..cc= sub("DESeq1b"   ,"D1b" ,COL..SAVE.Corret..cc,fixed=TRUE);
COL..SAVE.Corret..cc= sub("DESeq2"    ,"D2"   ,COL..SAVE.Corret..cc,fixed=TRUE);	COL..SAVE.Corret..cc= sub("DESeq2b"   ,"D2b" ,COL..SAVE.Corret..cc,fixed=TRUE);
#####
colnames(TABLE.test.NEW..CC)= COL..SAVE.Corret..cc
##############################################################
return(TABLE.test.NEW..CC)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################

#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..JOIN..Get.Columns.Ids= function(Columns.MAIN..CC, print.Change.Columns.saving..CC=c(1,0)[1] ) {

################################################################################################################
################################################################################################################
if(print.Change.Columns.saving..CC>0) print(paste("############ FFF.RNAseq..JOIN..Change.Columns.saving     -->  rows=", paste(Columns.MAIN..CC, collapse=",") ))

##############################################################
COL..SAVE.Corret..cc= Columns.MAIN..CC
#####
if(length(COL..SAVE.Corret..cc)>0){
	COL..SAVE.Corret..cc= sub("Lima1"     ,"L1"  ,COL..SAVE.Corret..cc,fixed=TRUE);		COL..SAVE.Corret..cc= sub(   "Lima2"  ,"L2"  ,COL..SAVE.Corret..cc,fixed=TRUE)
	COL..SAVE.Corret..cc= sub("Lima3-Voom","L3-V",COL..SAVE.Corret..cc,fixed=TRUE);		COL..SAVE.Corret..cc= sub("Lima4-Voom","L4-V",COL..SAVE.Corret..cc,fixed=TRUE)
	#####
	COL..SAVE.Corret..cc= sub("edgeR.ltr1","E1.l",COL..SAVE.Corret..cc,fixed=TRUE);		COL..SAVE.Corret..cc= sub("edgeR.ltr2","E2.l",COL..SAVE.Corret..cc,fixed=TRUE);
	COL..SAVE.Corret..cc= sub("edgeR.qlf1","E1.q",COL..SAVE.Corret..cc,fixed=TRUE);		COL..SAVE.Corret..cc= sub("edgeR.qlf2","E2.q",COL..SAVE.Corret..cc,fixed=TRUE);
	#####
	COL..SAVE.Corret..cc= sub("DESeq1"     ,"D1" ,COL..SAVE.Corret..cc,fixed=TRUE);	    COL..SAVE.Corret..cc= sub("DESeq1b"   ,"D1b" ,COL..SAVE.Corret..cc,fixed=TRUE);
	COL..SAVE.Corret..cc= sub("DESeq2"     ,"D2" ,COL..SAVE.Corret..cc,fixed=TRUE);	    COL..SAVE.Corret..cc= sub("DESeq2b"   ,"D2b" ,COL..SAVE.Corret..cc,fixed=TRUE);
}
##############################################################
return(COL..SAVE.Corret..cc)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..JOIN.Algorithms.Tables.Togo= function(RUN.CASE..Pvalue.Togo..JJ, TABLE.test.ALL..JJ, test_run..VEC..JJ, Use.Col.Max.Mean..JJ=c(".Max",".Mean",".Min")[1], Models.logFC..JJ= c(1,1.2, 2 )[2], 
                                                  Models.PValue..JJ= c(0.1, 0.05, 0.01)[2], Models.FDR..JJ= c(0.1, 0.05, 0.01)[1], print.JOIN.Algorithms..JJ=c(1,0)[1], Make.Extras.CC.Mean..JJ= c(".Mean",".Min")[0] ){

##########
### TABLE.test.ALL..JJ=TABLEs.ALL.PLOT; test_run..VEC..JJ=RNAseq..test_run..PLOT; Models.Unique.VEC..JJ= RNAseq..Models.Alg..Unique.VEC; Models.Lima.VEC..JJ = RNAseq..Models.Alg..Lima.VEC; 
### Models.edgeR.VEC..JJ= RNAseq..Models.Alg..edgeR.VEC;   Models.DESeq.VEC..JJ= RNAseq..Models.Alg..DESeq.VEC;  Models.logFC..JJ= Models.Alg.logFC;   Models.PValue..JJ=Models.Alg.PValue;   Models.FDR..JJ= Models.Alg.FDR; print.JOIN.Algorithms..JJ=c(1,0)[1]
### RUN.CASE..Pvalue.Togo..JJ=RUN.Togo..KEKE; TABLE.test.ALL..JJ=GO.Kegga.Model1..USE.goana; test_run..VEC..JJ=test_run..KEKE;  Models.logFC..JJ=-1; Models.PValue..JJ=MIN.P.Value.Path..KEKE;  Models.FDR..JJ=-1; print.JOIN.Algorithms..JJ=print.GO.path..KEKE

##########
#### RUN.CASE..Pvalue.Togo..JJ=RUN.Togo..KEKE;   TABLE.test.ALL..JJ=GO.Kegga.Model1..USE.goana;   test_run..VEC..JJ=test_run..KEKE;   Use.Col.Max.Mean..JJ=Use.Col.Max.Mean..KEKE;   Models.logFC..JJ= -1;   
#### Models.PValue..JJ= MIN.P.Value.Path..KEKE;   Models.FDR..JJ= -1;   print.JOIN.Algorithms..JJ=print.GO.path..KEKE;   Make.Extras.CC.Mean..JJ= c(".Mean",".Min")[0]

################################################################################################################ {
################################################################################################################
if(print.JOIN.Algorithms..JJ>0) print(paste("############ FFF.RNAseq..JOIN.Algorithms.Tables.Togo        --> test=", paste(test_run..VEC..JJ, collapse=","),"       rows=", nrow(TABLE.test.ALL..JJ),"     run.case=", RUN.CASE..Pvalue.Togo..JJ  ))
###############################
TXT.Test.Algortitms..JJ="T";      TXT.Test.MAIN..JJ="Test";      TXT.Test.JoinT..JJ="TEST";     COL..Model..JJ= "Model";    COL..TEST..JJ= "Test.XX";   COL..RawPro.gene..JJ= "RawPro.gene";   Format.output=c(0,1,2)[2];   
#####################
if(RUN.CASE..Pvalue.Togo..JJ==1) {
	COL..FDR..JJ= "FDR";       COL..PValue..JJ= "PValue";    	COL..logFC..JJ= "logFC";           COL..Annotation..JJ= c("gene.Raw","gene.Ens","gene.HGNC","gene.Synonyms") 
	COl.MAIN.Test= COL..logFC..JJ; 			Format.output=1;   	COL..Filter..JJ= paste("Filters",Use.Col.Max.Mean..JJ,sep="")
}
if(RUN.CASE..Pvalue.Togo..JJ==2) {
	COL..FDR..JJ= "P.Down";    COL..PValue..JJ= "P.Up";      	COL..logFC..JJ= "Up";              COL..Annotation..JJ= c("Method","UP.DOWN","Pathway","Ont","N","TNgenes.GoTo","Ngenes.GoTo","genes.GoTo","GeneID.GoTo")
	COl.MAIN.Test= COL..logFC..JJ; 			Format.output=1;   	COL..Filter..JJ= "Filters"
}
if(RUN.CASE..Pvalue.Togo..JJ==3) {
	COL..FDR..JJ= "P.Up";      COL..PValue..JJ= "P.Down";    	COL..logFC..JJ= "Down";            COL..Annotation..JJ= c("Method","UP.DOWN","Pathway","Ont","N","TNgenes.GoTo","Ngenes.GoTo","genes.GoTo","GeneID.GoTo")
	COl.MAIN.Test= COL..logFC..JJ; 			Format.output=1;   	COL..Filter..JJ= "Filters"
}
if(RUN.CASE..Pvalue.Togo..JJ==4) {
	COL..FDR..JJ= "P.DE";    COL..PValue..JJ= "P.DE";        	COL..logFC..JJ= "DE";              COL..Annotation..JJ= c("Method","UP.DOWN","Pathway","Ont","N","TNgenes.GoTo","Ngenes.GoTo","genes.GoTo","GeneID.GoTo")
	COl.MAIN.Test= COL..logFC..JJ; 			Format.output=1;   	COL..Filter..JJ= "Filters"
}
#####################
if(RUN.CASE..Pvalue.Togo..JJ==11) {
	COL..FDR..JJ= "FDR";       COL..PValue..JJ= "PValue";    	COL..logFC..JJ= "logFC";           COL..Annotation..JJ= c("gene.Raw","gene.Ens","gene.HGNC","gene.Synonyms") 
	COl.MAIN.Test= COL..PValue..JJ; 		Format.output=2;   	COL..Filter..JJ= paste("Filters",Use.Col.Max.Mean..JJ,sep="")
}
if(RUN.CASE..Pvalue.Togo..JJ==12) {
	COL..FDR..JJ= "FDR";       COL..PValue..JJ= "PValue";    	COL..logFC..JJ= "logFC";           COL..Annotation..JJ= c("gene.Raw","gene.Ens","gene.HGNC","gene.Synonyms") 
	COl.MAIN.Test= COL..FDR..JJ; 			Format.output=2;   	COL..Filter..JJ= paste("Filters",Use.Col.Max.Mean..JJ,sep="")
}

#######################################################
#######################################################
## Nota kaos: need to run main input file, we need (RNAseq..Models.Alg..Unique.VEC, RNAseq..Models.Alg..Lima.VEC, RNAseq..Models.Alg..edgeR.VEC, RNAseq..Models.Alg..DESeq.VEC)
################
Models.Lima.VEC..JJ  = RNAseq..Models.Alg..Lima.VEC;			Models.edgeR.VEC..JJ = RNAseq..Models.Alg..edgeR.VEC
Models.DESeq.VEC..JJ = RNAseq..Models.Alg..DESeq.VEC;			Models.Unique.VEC..JJ= RNAseq..Models.Alg..Unique.VEC

####################################################### filter Input data
#######################################################
TXT.Main.filters..JJ= c()
if(RUN.CASE..Pvalue.Togo..JJ==1 | RUN.CASE..Pvalue.Togo..JJ==11 | RUN.CASE..Pvalue.Togo..JJ==12) if(nrow(TABLE.test.ALL..JJ)>0){	
	if(Models.logFC..JJ >0                      ){ TABLE.test.ALL..JJ= TABLE.test.ALL..JJ[abs(as.numeric(TABLE.test.ALL..JJ[,COL..logFC..JJ ]))>=Models.logFC..JJ ,];  TXT.Main.filters..JJ= c(TXT.Main.filters..JJ, paste( "logFC >"   ,Models.logFC..JJ )) }
	if(Models.PValue..JJ>0 & Models.PValue..JJ<1){ TABLE.test.ALL..JJ= TABLE.test.ALL..JJ[    as.numeric(TABLE.test.ALL..JJ[,COL..PValue..JJ]) <=Models.PValue..JJ,];  TXT.Main.filters..JJ= c(TXT.Main.filters..JJ, paste("PValue >"   ,Models.PValue..JJ)) }
	if(Models.FDR..JJ   >0 & Models.FDR..JJ   <1){ TABLE.test.ALL..JJ= TABLE.test.ALL..JJ[    as.numeric(TABLE.test.ALL..JJ[,COL..FDR..JJ   ]) <=Models.FDR..JJ   ,];  TXT.Main.filters..JJ= c(TXT.Main.filters..JJ, paste(   "FDR >"   ,Models.FDR..JJ   )) }
}
if(RUN.CASE..Pvalue.Togo..JJ==2 | RUN.CASE..Pvalue.Togo..JJ==3 | RUN.CASE..Pvalue.Togo..JJ==4) if(nrow(TABLE.test.ALL..JJ)>0){	
    #######                                
	if(Models.PValue..JJ>=0 & Models.PValue..JJ<=1){ TABLE.test.ALL..JJ= TABLE.test.ALL..JJ[    as.numeric(TABLE.test.ALL..JJ[,COL..PValue..JJ]) <=Models.PValue..JJ,];  TXT.Main.filters..JJ= c(TXT.Main.filters..JJ, paste("PValue.GO >",Models.PValue..JJ)) } 
	#######
	if(nrow(TABLE.test.ALL..JJ)>0){	
		TABLE.test.ALL..JJ[,"Method.ALL"]= paste(unique(TABLE.test.ALL..JJ[,"Method"]), collapse="; ")
		if(RUN.CASE..Pvalue.Togo..JJ==2) TABLE.test.ALL..JJ[,"UP.DOWN.ALL"]= "up"
		if(RUN.CASE..Pvalue.Togo..JJ==3) TABLE.test.ALL..JJ[,"UP.DOWN.ALL"]= "down"
		if(RUN.CASE..Pvalue.Togo..JJ==4) TABLE.test.ALL..JJ[,"UP.DOWN.ALL"]= "geneN"
}	}

####################################################### Definition columns
#######################################################
if(length(TXT.Main.filters..JJ)<=0) TXT.Main.filters..JJ= "" else TXT.Main.filters..JJ= paste("",paste(TXT.Main.filters..JJ, collapse=";  "))
########
COL.J.RUN.PValue.VEC= unique(c(COL..PValue..JJ,COL..FDR..JJ))  
########
Models.Algorithms.VEC..JJ= c(Models.Lima.VEC..JJ, Models.edgeR.VEC..JJ, Models.DESeq.VEC..JJ)
###########
Col.test.MAIN.TEXT..VEC= unique(c("S","A",COL.J.RUN.PValue.VEC, COl.MAIN.Test))
Col.test..pvlues.DD= c();  
for(test_run in test_run..VEC..JJ){
	 Col.test..pvlues.DD= c(Col.test..pvlues.DD, paste("##T",test_run,sep=""))
	 for(Table.JOIN in Col.test.MAIN.TEXT..VEC) Col.test..pvlues.DD= c(Col.test..pvlues.DD, paste(TXT.Test.MAIN..JJ      ,test_run,".",Table.JOIN,sep="") )
	 for(Table.Num in Models.Algorithms.VEC..JJ    ) Col.test..pvlues.DD= c(Col.test..pvlues.DD, paste(TXT.Test.Algortitms..JJ,test_run,".",Table.Num ,sep="") )
}
###########
COL..Filter.Mean..JJ= c();  Use.Col.Max.Mean.VEC..JJ= Use.Col.Max.Mean..JJ 
if(length(Make.Extras.CC.Mean..JJ)>0) COL..Filter.Mean..JJ= paste("Filters",Make.Extras.CC.Mean..JJ,sep="")
Use.Col.Max.Mean.VEC..JJ= c(Use.Col.Max.Mean..JJ,Make.Extras.CC.Mean..JJ)
COL..ALL..JJ=c();  for(CC.k in unique(c(COl.MAIN.Test,COL.J.RUN.PValue.VEC))) COL..ALL..JJ= c(COL..ALL..JJ, paste(CC.k, Use.Col.Max.Mean.VEC..JJ,sep=""))  
COL..SAVE1..JJ= unique(c(COL..Annotation..JJ, COL..RawPro.gene..JJ,"##A",COL..Filter..JJ,COL..Filter.Mean..JJ,"pvalue.A",COL..ALL..JJ, Col.test..pvlues.DD))

####################################################### running match genes {
#######################################################
if(nrow(TABLE.test.ALL..JJ)<=0) {
	TABLE.test.OUT..JJ= as.data.frame(array(NA,c(0,length(COL..SAVE1..JJ))),stringsFactors=F);    colnames(TABLE.test.OUT..JJ)= COL..SAVE1..JJ 
} else {
#######################################################
TABLE.test.ALL..JJ[,c(COL..ALL..JJ, Col.test..pvlues.DD   )]= NA;       TABLE.test.ALL..JJ[,"##A"]="##";    TABLE.test.ALL..JJ[,"RRR.GENE"]= "error";     TABLE.test.ALL..JJ[,"RRR.X"]= c(1:nrow(TABLE.test.ALL..JJ));    
TABLE.test.ALL..JJ[,c(COL..Filter..JJ,COL..Filter.Mean..JJ)]= "";       TABLE.test.ALL..JJ[,"pvalue.A"]= 100;       TABLE.test.ALL..JJ[,paste(TXT.Test.MAIN..JJ,test_run..VEC..JJ,".A",sep="")]=0;        TABLE.test.ALL..JJ[,paste(TXT.Test.MAIN..JJ,test_run..VEC..JJ,".S",sep="")]=0
####################
if(RUN.CASE..Pvalue.Togo..JJ==1 | RUN.CASE..Pvalue.Togo..JJ==11 | RUN.CASE..Pvalue.Togo..JJ==12) TABLE.test.ALL..JJ[,COL..Annotation..JJ]= NA;   
if(RUN.CASE..Pvalue.Togo..JJ>=2 & RUN.CASE..Pvalue.Togo..JJ<=4) TABLE.test.ALL..JJ[,c("Method","UP.DOWN","N","TNgenes.GoTo","Ngenes.GoTo","genes.GoTo","GeneID.GoTo")]= NA
####################
##print(colnames(TABLE.test.ALL..JJ));  print(COL..SAVE1..JJ); DDD=colnames(TABLE.test.ALL..JJ); for(CCf in COL..SAVE1..JJ) if(length(DDD[DDD==CCf])<=0) print(CCf)
TABLE.test.OUT..JJ= TABLE.test.ALL..JJ[,COL..SAVE1..JJ];  
####################
if(RUN.CASE..Pvalue.Togo..JJ>=2 & RUN.CASE..Pvalue.Togo..JJ<=4) if(nrow(TABLE.test.OUT..JJ)>0) TABLE.test.OUT..JJ[,c("Method","UP.DOWN")]= TABLE.test.ALL..JJ[,c("Method.ALL","UP.DOWN.ALL")]
####################
TABLE.test.OUT..JJ= unique(TABLE.test.OUT..JJ)
###########
COl.format.pvalue= c();   COl.format.log2=c();   COl.format.pvalue.MM= c();   COl.format.log2.MM=c()
for(test_run in test_run..VEC..JJ) for(Table.Num in Models.Algorithms.VEC..JJ) {	## 	Table.Num=Models.Algorithms.VEC..JJ[1]	   
    ########################
    COLUMN.AA.use= paste(TXT.Test.MAIN..JJ,test_run,".A",sep="");     NEW.COLUMN.use= paste(TXT.Test.Algortitms..JJ,test_run,".",Table.Num,sep="");  COl.format.log2= c(COl.format.log2, NEW.COLUMN.use)
    ############ 
    COL_MATCH_dataset.NN= COL..RawPro.gene..JJ;    	COL_MATCH_Input.NN= COL..RawPro.gene..JJ;    print.Anno.NN= c(1,0)[2]
    COL.data1.MATCH.NN= "RRR.X";		   			COL.data2.MATCH.NN= COL..RawPro.gene..JJ;	 
    ############  
    Database.FF= TABLE.test.ALL..JJ[TABLE.test.ALL..JJ[,COL..TEST..JJ]==test_run & TABLE.test.ALL..JJ[,COL..Model..JJ]==Table.Num, unique(c(COL..RawPro.gene..JJ,"RRR.X",COl.MAIN.Test,COL.J.RUN.PValue.VEC))];  head(Database.FF)
    ############
    if(nrow(Database.FF)>0) {
    	########################
    	Database.FF[,"RRR.X"]= c(1:nrow(Database.FF));     rownames(Database.FF)= c(1:nrow(Database.FF))
		RES= FFF.RNAseq..MATCH.table.vs.dataset(TABLE.test.OUT..JJ, Database.FF, COL_MATCH_dataset.NN, COL_MATCH_Input.NN, COL.data1.MATCH.NN, COL.data2.MATCH.NN, print.Anno.NN)
		########
		TABLE.test.OUT..JJ[,"RRR.GENE"]= RES[,"HGNC.ID3.WW"]
    	ERROR.test= TABLE.test.OUT..JJ[TABLE.test.OUT..JJ[,"RRR.GENE"]!="" & TABLE.test.OUT..JJ[,"RRR.GENE"]!=TABLE.test.OUT..JJ[,COL..RawPro.gene..JJ],];   if(nrow(ERROR.test)>0) stop(paste("ERROR ERROR test not pass 1 -->", nrow(ERROR.test) ))
    	########	
		RES[,"ROWS.1"]= c(1:nrow(RES));   RES[,"ROWS.2"]=  RES[,"gene_name3.WW"];  RES= RES[RES[,"ROWS.2"]!="",]
		########################
		if(nrow(RES)>0) {
			TABLE.test.OUT..JJ[              ,"RRR.GENE"    ]="";
			TABLE.test.OUT..JJ[RES[,"ROWS.1"],"RRR.GENE"    ]=             Database.FF[RES[,"ROWS.2"],COL..RawPro.gene..JJ]
    		TABLE.test.OUT..JJ[RES[,"ROWS.1"],NEW.COLUMN.use]= as.numeric( Database.FF[RES[,"ROWS.2"],COl.MAIN.Test   ])
    		########
    		TABLE.test.OUT..JJ[RES[,"ROWS.1"], COLUMN.AA.use]= TABLE.test.OUT..JJ[RES[,"ROWS.1"], COLUMN.AA.use] + 1
    		#########
    		ERROR.test= TABLE.test.OUT..JJ[TABLE.test.OUT..JJ[,"RRR.GENE"]!="" & TABLE.test.OUT..JJ[,"RRR.GENE"]!=TABLE.test.OUT..JJ[,COL..RawPro.gene..JJ],];   if(nrow(ERROR.test)>0) stop(paste("ERROR ERROR test not pass 1 -->", nrow(ERROR.test) ))
    		#########
    		for(COL.J.RUN in unique(c(COl.MAIN.Test, COL.J.RUN.PValue.VEC))) {
    			########################
    			COL.J.pvalue= paste(TXT.Test.MAIN..JJ,test_run,".",COL.J.RUN,sep="");    COL.J.TEMP= "Test.TEMP";   
    			########
    			if(length(COl.MAIN.Test       [COl.MAIN.Test       ==COL.J.RUN])>0) COl.format.log2.MM  = c(COl.format.log2.MM  , COL.J.pvalue) 
    			if(length(COL.J.RUN.PValue.VEC[COL.J.RUN.PValue.VEC==COL.J.RUN])>0) COl.format.pvalue.MM= c(COl.format.pvalue.MM, COL.J.pvalue)    
    			########
    			TABLE.test.OUT..JJ[,COL.J.TEMP]= NA;  TABLE.test.OUT..JJ[RES[,"ROWS.1"],COL.J.TEMP]= as.numeric(Database.FF[RES[,"ROWS.2"],COL.J.RUN])
    			########  
    			if(Table.Num==Models.Algorithms.VEC..JJ[1]) TABLE.test.OUT..JJ[,COL.J.pvalue]= TABLE.test.OUT..JJ[,COL.J.TEMP] else {
    				TABLE.test.OUT..JJ[ is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]),COL.J.pvalue]= 
    				TABLE.test.OUT..JJ[ is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]),COL.J.TEMP  ]
    				if(length(COL.J.RUN.PValue.VEC[COL.J.RUN.PValue.VEC==COL.J.RUN])>0)
    					TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]) & as.numeric(TABLE.test.OUT..JJ[,COL.J.pvalue])> as.numeric(TABLE.test.OUT..JJ[,COL.J.TEMP]),COL.J.pvalue]=
						TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]) & as.numeric(TABLE.test.OUT..JJ[,COL.J.pvalue])> as.numeric(TABLE.test.OUT..JJ[,COL.J.TEMP]),COL.J.TEMP  ]
					if(length(COl.MAIN.Test[COl.MAIN.Test==COL.J.RUN])>0)
    					TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]) & abs(as.numeric(TABLE.test.OUT..JJ[,COL.J.pvalue]))< abs(as.numeric(TABLE.test.OUT..JJ[,COL.J.TEMP])),COL.J.pvalue]=
						TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]) & abs(as.numeric(TABLE.test.OUT..JJ[,COL.J.pvalue]))< abs(as.numeric(TABLE.test.OUT..JJ[,COL.J.TEMP])),COL.J.TEMP  ]
}	}	}	}	}	
if(nrow(TABLE.test.OUT..JJ)>1) TABLE.test.OUT..JJ= unique(TABLE.test.OUT..JJ)
########
if(length(COl.format.log2.MM)>1) COl.format.log2.MM= unique(COl.format.log2.MM);       if(length(COl.format.pvalue.MM)>1) COl.format.pvalue.MM= unique(COl.format.pvalue.MM)    
if(length(COl.format.log2   )>1) COl.format.log2   = unique(COl.format.log2   );       if(length(COl.format.pvalue   )>1) COl.format.pvalue   = unique(COl.format.pvalue   )

####################################################### Calculate Softwares (Test.S)
#######################################################
for(test_run in test_run..VEC..JJ) for(PValue.J.err in unique(c(COl.MAIN.Test, COL.J.RUN.PValue.VEC))) for(INF.TT in c(Inf,-Inf)) {
	########
	COL.J.pvalue= paste(TXT.Test.MAIN..JJ,test_run,".",PValue.J.err,sep="");
	########
	CHANGE.INF..JJ= TABLE.test.OUT..JJ[TABLE.test.OUT..JJ[,COL.J.pvalue]==INF.TT,];   ## TABLE.test.OUT..JJ[is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]),]
	if(nrow(CHANGE.INF..JJ)>0) {
		CHANGE.INF..JJ[,"PVALUE.CORR"]= CHANGE.INF..JJ[,COL.J.pvalue]
		####
		for(RR.inf in c(1:nrow(CHANGE.INF..JJ))) {
			VEC.INF.jj= CHANGE.INF..JJ[RR.inf,paste(TXT.Test.Algortitms..JJ,test_run,".",Models.Algorithms.VEC..JJ,sep="")]
			VEC.INF.jj= VEC.INF.jj[!is.na(VEC.INF.jj)];  VEC.INF.jj=VEC.INF.jj[VEC.INF.jj!=INF.TT]
			if(length(VEC.INF.jj)>0) {
				if(length(COL.J.RUN.PValue.VEC[COL.J.RUN.PValue.VEC==PValue.J.err])>0)                  CHANGE.INF..JJ[RR.inf,"PVALUE.CORR"]= min(as.numeric(VEC.INF.jj))
				if(length(COl.MAIN.Test       [COl.MAIN.Test       ==PValue.J.err])>0) if(INF.TT== Inf) CHANGE.INF..JJ[RR.inf,"PVALUE.CORR"]= max(as.numeric(VEC.INF.jj))
				if(length(COl.MAIN.Test       [COl.MAIN.Test       ==PValue.J.err])>0) if(INF.TT==-Inf) CHANGE.INF..JJ[RR.inf,"PVALUE.CORR"]= min(as.numeric(VEC.INF.jj))
		}	}
		TABLE.test.OUT..JJ[TABLE.test.OUT..JJ[,COL.J.pvalue]==INF.TT,COL.J.pvalue]= CHANGE.INF..JJ[,"PVALUE.CORR"]
}	}
	
####################################################### Calculate Softwares (Test.S)
#######################################################
COL..SAVE2..JJ= c()
for(test_run in test_run..VEC..JJ) for(CASE in Models.Unique.VEC..JJ) { ## test_run=1; CASE=Models.Unique.VEC..JJ[1]
	########
	if(CASE=="Lima" ) VEC.TEST.USE= Models.Lima.VEC..JJ
	if(CASE=="edgeR") VEC.TEST.USE= Models.edgeR.VEC..JJ
	if(CASE=="DESeq") VEC.TEST.USE= Models.DESeq.VEC..JJ
	########
	COl.TESTXX= paste(TXT.Test.JoinT..JJ,test_run,".",CASE,sep="");   COl.Software= paste(TXT.Test.MAIN..JJ,test_run,".S",sep="")
	COL..SAVE2..JJ= c(COL..SAVE2..JJ, COl.TESTXX)
	########
	TABLE.test.OUT..JJ[,COl.TESTXX]= NA;  for(Table.Num in VEC.TEST.USE) TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,paste(TXT.Test.Algortitms..JJ,test_run,".",Table.Num,sep="")]),COl.TESTXX]=1
	########
	TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COl.TESTXX]),COl.Software]= TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COl.TESTXX]),COl.Software] + 1 
}

####################################################### Calculate values.all (PValue.All, FDR.All, logFC.All)    ## TABLE.test.OUT..JJ..ORG= TABLE.test.OUT..JJ;  ##  TABLE.test.OUT..JJ= TABLE.test.OUT..JJ..ORG
#######################################################
if(length(length(test_run..VEC..JJ))==1) {
	COl.OUTP.OOOO= paste(unique(c(COl.MAIN.Test,COL.J.RUN.PValue.VEC)),Use.Col.Max.Mean..JJ,sep="");    COl.INPU.OOOO= paste(TXT.Test.MAIN..JJ,test_run,".",unique(c(COl.MAIN.Test, COL.J.RUN.PValue.VEC)),sep="");  #print("jaja");  print(COl.OUTP.OOOO);  print(COl.INPU.OOOO)
	########
	if(nrow(TABLE.test.OUT..JJ)>0) TABLE.test.OUT..JJ[,COl.OUTP.OOOO]= TABLE.test.OUT..JJ[,COl.INPU.OOOO]
} else {
	if(length(COl.format.log2.MM)>0) for(CC.all in unique(c(COl.MAIN.Test, COL.J.RUN.PValue.VEC))) {  ## CC.all= COl.MAIN.Test
		#######
		COL.J.pvalue= paste(CC.all,Use.Col.Max.Mean..JJ,sep="");   COl.both.MM= COl.format.both.MM[grep(CC.all,COl.format.both.MM,fixed=TRUE)];  
		if(length(test_run..VEC..JJ)!=length(COl.both.MM)) stop("KAOS stopping --> review this function -- 999")
		#######
		if(length(COl.both.MM)>0) for(COL.J.TEMP in COl.both.MM) {
			#######  
    		if(COL.J.TEMP==COl.both.MM[1]) TABLE.test.OUT..JJ[,COL.J.pvalue]= TABLE.test.OUT..JJ[,COL.J.TEMP] else {
    		 	 TABLE.test.OUT..JJ[ is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]),COL.J.pvalue]= 
    		 	 TABLE.test.OUT..JJ[ is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]),COL.J.TEMP  ]
    				if(length(COl.format.pvalue.MM[COl.format.pvalue.MM==COL.J.TEMP])>0)
    					TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]) &     as.numeric(TABLE.test.OUT..JJ[,COL.J.pvalue])< as.numeric(TABLE.test.OUT..JJ[,COL.J.TEMP]),COL.J.pvalue]=
						TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]) &     as.numeric(TABLE.test.OUT..JJ[,COL.J.pvalue])< as.numeric(TABLE.test.OUT..JJ[,COL.J.TEMP]),COL.J.TEMP  ]
					if(length(COl.format.log2.MM[COl.format.log2.MM==COL.J.TEMP])>0)
    					TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]) & abs(as.numeric(TABLE.test.OUT..JJ[,COL.J.pvalue]))< abs(as.numeric(TABLE.test.OUT..JJ[,COL.J.TEMP])),COL.J.pvalue]=
						TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,COL.J.pvalue]) & !is.na(TABLE.test.OUT..JJ[,COL.J.TEMP]) & abs(as.numeric(TABLE.test.OUT..JJ[,COL.J.pvalue]))< abs(as.numeric(TABLE.test.OUT..JJ[,COL.J.TEMP])),COL.J.TEMP  ]
}	}	}	}

####################################################### format all columns 
#######################################################
COl.format.log2.MM  = c(COl.format.log2.MM  , paste(COl.MAIN.Test       ,Use.Col.Max.Mean..JJ,sep=""));  if(length(COl.format.log2.MM  )>1) COl.format.log2.MM  = unique(COl.format.log2.MM  )
COl.format.pvalue.MM= c(COl.format.pvalue.MM, paste(COL.J.RUN.PValue.VEC,Use.Col.Max.Mean..JJ,sep=""));  if(length(COl.format.pvalue.MM)>1) COl.format.pvalue.MM= unique(COl.format.pvalue.MM)
#######
if(Format.output==1){
   #if(length(COl.format.log2.MM)>0) for(CC.format in COl.format.log2.MM) TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,CC.format]),CC.format]= ceiling(as.numeric(TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,CC.format]),CC.format])*100)/100
   #if(length(COl.format.log2   )>0) for(CC.format in COl.format.log2   ) TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,CC.format]),CC.format]= ceiling(as.numeric(TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,CC.format]),CC.format])*100)/100
	if(length(COl.format.log2.MM)>0) for(CC.format in COl.format.log2.MM) TABLE.test.OUT..JJ[,CC.format]= as.numeric(TABLE.test.OUT..JJ[,CC.format])
	if(length(COl.format.log2   )>0) for(CC.format in COl.format.log2   ) TABLE.test.OUT..JJ[,CC.format]= as.numeric(TABLE.test.OUT..JJ[,CC.format])
}
if(Format.output==2) {
	#print(COl.format.pvalue.MM);  print(COl.format.pvalue);   print(COl.format.log2.MM);  print(COl.format.log2)
	#if(length(COl.format.log2)>0) for(CC.format in COl.format.log2) TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,CC.format]),CC.format]= as.numeric(format(as.numeric(TABLE.test.OUT..JJ[!is.na(TABLE.test.OUT..JJ[,CC.format]),CC.format],digits = 1, nsmall = 3)))
	if(length(COl.format.log2)>0) for(CC.format in COl.format.log2) TABLE.test.OUT..JJ[,CC.format]= as.numeric(TABLE.test.OUT..JJ[,CC.format])
}
########
TABLE.test.OUT..JJ= TABLE.test.OUT..JJ[order(as.numeric(TABLE.test.OUT..JJ[,paste(COl.MAIN.Test,Use.Col.Max.Mean..JJ,sep="")]),decreasing=TRUE),]
########
TABLE.test.OUT..JJ[,COL..SAVE1..JJ[grep("##",COL..SAVE1..JJ,fixed=TRUE)]]= "###"
########
TABLE.test.OUT..JJ= TABLE.test.OUT..JJ[,c(COL..SAVE1..JJ,COL..SAVE2..JJ)]; 

####################################################### format all columns
#######################################################
}   ## if(nrow(TABLE.test.ALL..JJ)<=0)

#######################################################
#######################################################
TXT.Main.filters..FF         <<- TXT.Main.filters..JJ
COL.SAVE..TABLE..pvlues..FF  <<- Col.test..pvlues.DD
COL.SAVE..TABLE.test.NEW..FF <<- COL..SAVE1..JJ
return(TABLE.test.OUT..JJ)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################



#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..JOIN.Algorithms.Percetage= function(TABLE.test.NEW..PP, test_run..VEC..PP, print.JOIN.Percetage..JJ=c(1,0)[1] ){

################################################################################################################
################################################################################################################
########
if(print.JOIN.Percetage..JJ>0) print(paste("############ FFF.RNAseq..JOIN.Algorithms.Percetage       -->  test=", paste(test_run..VEC..PP, collapse=","),"       rows=", nrow(TABLE.test.NEW..PP)  ))
########
TXT.Test.Algortitms..PP="T";      TXT.Test.MAIN..PP="Test";      TXT.Test.JoinT..PP="TEST"

######################## 
## Nota kaos: need to run main input file, we need (RNAseq..Models.Alg..Unique.VEC, RNAseq..Models.Alg..Lima.VEC, RNAseq..Models.Alg..edgeR.VEC, RNAseq..Models.Alg..DESeq.VEC)
################
Models.Algorithms.VEC..PP= c(RNAseq..Models.Alg..Lima.VEC, RNAseq..Models.Alg..edgeR.VEC, RNAseq..Models.Alg..DESeq.VEC)
Models.Unique.VEC..PP    = RNAseq..Models.Alg..Unique.VEC

#####################################################################                                
conta.ALL=0; 
if(nrow(TABLE.test.NEW..PP)<=0){
	COl.USE.00..PP= c(Models.Algorithms.VEC..PP,"##1","##1",Models.Unique.VEC..PP)
	TABLE.ALL..PER= as.data.frame(array(NA,c(0,length(COl.USE.00..PP))),stringsFactors=F); colnames(TABLE.ALL..PER)= paste("####",c(1:length(COl.USE.00..PP)),sep="")
	########
} else for(test_run in test_run..VEC..PP) {
	########
	for(CASE in c("A","S")) {  ## CASE="A"
		########
		if(CASE=="A"){ Table..VEC.USE= Models.Algorithms.VEC..PP;  TXT.test=TXT.Test.Algortitms..PP }
		if(CASE=="S"){ Table..VEC.USE= Models.Unique.VEC..PP;      TXT.test=TXT.Test.JoinT..PP      }
		########
		TABLE.PER.SOFTWARES= as.data.frame(array(NA,c(length(Table..VEC.USE),length(Table..VEC.USE))),stringsFactors=F); colnames(TABLE.PER.SOFTWARES)= rownames(TABLE.PER.SOFTWARES)= paste(TXT.test,test_run,".",Table..VEC.USE,sep="")
		if(CASE=="A") TABLE.PER.00= TABLE.PER.SOFTWARES[,c(1:length(Models.Unique.VEC..PP))]
		########
		for(Table.Num1 in Table..VEC.USE) for(Table.Num2 in Table..VEC.USE) {  ### Table.Num1=1; Table.Num2= 1
			COL.T.Num1= paste(TXT.test,test_run,".",Table.Num1,sep="");		COL.T.Num2= paste(TXT.test,test_run,".",Table.Num2,sep="")
			DEnominador.DD= length(TABLE.test.NEW..PP[!is.na(TABLE.test.NEW..PP[,COL.T.Num1]),COL.T.Num1]);  #stop()
			if(DEnominador.DD<=0) TABLE.PER.SOFTWARES[COL.T.Num1,COL.T.Num2]= 0 else
				TABLE.PER.SOFTWARES[COL.T.Num1,COL.T.Num2]= paste(100*length(TABLE.test.NEW..PP[!is.na(TABLE.test.NEW..PP[,COL.T.Num1]) & !is.na(TABLE.test.NEW..PP[,COL.T.Num2]),COL.T.Num1])/length(TABLE.test.NEW..PP[!is.na(TABLE.test.NEW..PP[,COL.T.Num1]),COL.T.Num1]),"%",sep="")
			if(COL.T.Num1==COL.T.Num2) TABLE.PER.SOFTWARES[COL.T.Num1,COL.T.Num2]= paste("N=",DEnominador.DD)
		}
		if(CASE=="A")  TABLE.PER..A= TABLE.PER.SOFTWARES
		if(CASE=="S"){ TABLE.PER..S= TABLE.PER.00;    TABLE.PER..S[c(3:(2+length(Table..VEC.USE))),c(1:length(Table..VEC.USE))]= TABLE.PER.SOFTWARES;  TABLE.PER..S[2,c(1:length(Models.Unique.VEC..PP))]= Models.Unique.VEC..PP  }
	}
	########
	AFFY_TABLE.CC= TABLE.PER..A[,c(1:2)];  AFFY_TABLE.CC[,c(1:2)]= "##";  AFFY_TABLE.CC[c(3:(2+length(Models.Unique.VEC..PP))),2]= Models.Unique.VEC..PP  
	AFFY_TABLE= cbind(TABLE.PER..A, AFFY_TABLE.CC, TABLE.PER..S)
	########
	COLNAMES.PER1= paste("Test.",Models.Algorithms.VEC..PP,sep="");  COLNAMES.PER2= paste("TEST.",Models.Unique.VEC..PP,sep="");   COLNAMES.BOTH= c(COLNAMES.PER1,"##N1","##N2",COLNAMES.PER2)
	########
	AFFY_TABLE.00= AFFY_TABLE[c(1:3),];    AFFY_TABLE.00[c(1:2),]= "#####";   rownames(AFFY_TABLE.00)= c("##A","##B","##C");     
	AFFY_TABLE.00[3,]= colnames(AFFY_TABLE.00)= colnames(AFFY_TABLE)= COLNAMES.BOTH;    
	AFFY_TABLE.00[3,]= sub("Test.","",AFFY_TABLE.00[3,],fixed=TRUE);    AFFY_TABLE.00[3,]= sub("TEST.","",AFFY_TABLE.00[3,],fixed=TRUE) 
	########
	if(conta.ALL==0){ conta.ALL=1; TABLE.ALL..PER= AFFY_TABLE[0,] }
	TABLE.ALL..PER= rbind(TABLE.ALL..PER, AFFY_TABLE.00[2:3,], AFFY_TABLE, AFFY_TABLE.00[1,])
	########
	colnames(TABLE.ALL..PER)= paste("####",c(1:ncol(TABLE.ALL..PER)),sep="")
};
#######################################################
return(TABLE.ALL..PER)
}	
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..JOIN.Algorithms..VEN.DIAGRAM= function(TABLE.VENN.DIAGRAM, test_run..VEC..VV, TXT.Main.filters..NN="", TXT.Main.Title1..NN="", TXT.Main.Title2..NN="", print.VEN.DIAGRAM..NN=c(1,0)[1], Plot.ONLY.Cases..NN=c() ){

## edgeR.VEC..NN= c("edgeR.ltr1","edgeR.qlf1","edgeR.ltr2","edgeR.qlf2"); DESeq.VEC..NN= c("DESeq1","DESeq2");  Lima.VEC..NN= c("Lima1","Lima2","Lima3-Voom","Lima4-Voom")
## TABLE.VENN.DIAGRAM= TABLE.test.NEW;  test_run..VEC..VV= RNAseq..test_run..VEC;     TXT.Test.Algortitms..NN=TXT.Test.Algortitms;    TXT.Test.MAIN..NN= TXT.Test.MAIN;   TXT.Test.JoinT..NN=TXT.Test.JoinT

################################################################################################################
################################################################################################################
if(print.VEN.DIAGRAM..NN>0) print(paste("############ FFF.RNAseq..JOIN.Algorithms..VEN.DIAGRAM    -->  test=", paste(test_run..VEC..VV, collapse=","),"       rows=", nrow(TABLE.VENN.DIAGRAM)  ))
########
TXT.Test.Algortitms..NN="T";   TXT.Test.MAIN..NN="Test";   TXT.Test.JoinT..NN="TEST";

#######################################################
#######################################################
## Nota kaos: need to run main input file, we need (RNAseq..Models.Alg..Unique.VEC, RNAseq..Models.Alg..Lima.VEC, RNAseq..Models.Alg..edgeR.VEC, RNAseq..Models.Alg..DESeq.VEC)
################
Lima.VEC..NN  = RNAseq..Models.Alg..Lima.VEC;			edgeR.VEC..NN = RNAseq..Models.Alg..edgeR.VEC
DESeq.VEC..NN = RNAseq..Models.Alg..DESeq.VEC;			Models.Unique.VEC..VV= RNAseq..Models.Alg..Unique.VEC

############################################################## 
Plot.Cases.ORG.VEC..NN= c("Soft",Models.Unique.VEC..VV)
if(length(Plot.ONLY.Cases..NN)<=0) Plot.Cases.USE.VEC..NN= Plot.Cases.ORG.VEC..NN else Plot.Cases.USE.VEC..NN= Plot.ONLY.Cases..NN
############################
if(nrow(TABLE.VENN.DIAGRAM)>0){
	##########################
	if(length(Plot.ONLY.Cases..NN)<=0) par(mfrow=c(2,2)) #else par(mfrow=c(3,2))
	##########################
	for(test_run in test_run..VEC..VV) {
		############################
		COL.Test2.S..VV= paste(TXT.Test.MAIN..NN,test_run,".A",sep="")
		TABLE.VENN..USE= TABLE.VENN.DIAGRAM[!is.na(TABLE.VENN.DIAGRAM[,COL.Test2.S..VV]) & as.integer(TABLE.VENN.DIAGRAM[,COL.Test2.S..VV])>0,]
		#######
		TXT.Main.filters..NN.USE= paste(" ==> ",nrow(TABLE.VENN.DIAGRAM))
		if(length(TXT.Main.filters..NN)>0) if(TXT.Main.filters..NN[1]!="") TXT.Main.filters..NN.USE= paste(" ==> ",nrow(TABLE.VENN.DIAGRAM)," ==>  ",TXT.Main.filters..NN)
		#######
		MAIN.TITLE.USE1..NN= paste("Test =",test_run, TXT.Main.filters..NN.USE)
		MAIN.TITLE.USE2..NN= paste(TXT.Main.Title2..NN,";  ",TXT.Main.filters..NN, sep="");  if(TXT.Main.Title2..NN=="") MAIN.TITLE.USE2..NN= TXT.Main.filters..NN
		##########################
		conta.plot..NN=0
		if(nrow(TABLE.VENN..USE)>0 & length(Plot.Cases.USE.VEC..NN)>0) for(CASE.jj in Plot.Cases.USE.VEC..NN) {  ## CASE.jj="A"	
			############
			TXT.test= TXT.Test.Algortitms..NN;     MAIN.TITLE..NN=c()
			if(CASE.jj=="Soft.Go"){ VEC.TEST.USE= Models.Unique.VEC..VV;   TXT.test=TXT.Test.JoinT..NN }
			if(CASE.jj=="Soft"   ){ VEC.TEST.USE= Models.Unique.VEC..VV;   if(TXT.Main.Title1..NN[1]!="") MAIN.TITLE..NN= TXT.Main.Title1..NN;     TXT.test=TXT.Test.JoinT..NN }
			if(CASE.jj=="Lima"   ){ VEC.TEST.USE= Lima.VEC..NN 	}
			if(CASE.jj=="edgeR"  ){ VEC.TEST.USE= edgeR.VEC..NN;           if(TXT.Main.Title2..NN[1]!="") MAIN.TITLE..NN= TXT.Main.Title2..NN	}
			if(CASE.jj=="DESeq"  ){ VEC.TEST.USE= DESeq.VEC..NN;   	      MAIN.TITLE..NN= MAIN.TITLE.USE1..NN    								}
			########
			Venn.Table= as.data.frame(array(NA,c(nrow(TABLE.VENN..USE),length(VEC.TEST.USE))),stringsFactors=F); colnames(Venn.Table)= VEC.TEST.USE;   rownames(Venn.Table)= c(1:nrow(TABLE.VENN..USE))
			########
			Venn.Table[,VEC.TEST.USE]= 0;  for(Table.Num in VEC.TEST.USE) Venn.Table[!is.na(TABLE.VENN..USE[,paste(TXT.test,test_run,".",Table.Num,sep="")]),Table.Num]=1
			########################
			Venn.Table.C= vennCounts(Venn.Table)
			########################
			if(length(VEC.TEST.USE)>5) stop(" ERROR --> maximum are 5 to plot VEN.DIAGRAM --> restrictions from function (vennDiagram)")
			COUNTS..COLOURS= c("black","red" ,"blue"  ,"green3")[1:length(VEC.TEST.USE)]
			CIRLCE..COLOURS= c("red"  ,"blue","green3","black" )[1:length(VEC.TEST.USE)]
			########################
			if(length(MAIN.TITLE..NN)<=0){ vennDiagram (Venn.Table.C, include="both", counts.col= COUNTS..COLOURS, circle.col= CIRLCE..COLOURS, cex = 0.65)
			} else                         vennDiagram (Venn.Table.C, include="both", counts.col= COUNTS..COLOURS, circle.col= CIRLCE..COLOURS, cex = 0.65, main= MAIN.TITLE..NN, cex.main=0.75) 
			conta.plot..NN= conta.plot..NN+1
			if(length(Plot.ONLY.Cases..NN)>0 & conta.plot..NN==1) if(length(grep("gene enrichment",MAIN.TITLE..NN,fixed=TRUE))>0) title(sub = MAIN.TITLE.USE2..NN, cex.sub=0.8) 
			if(length(Plot.ONLY.Cases..NN)>0 & conta.plot..NN==1) title(sub = MAIN.TITLE.USE2..NN, cex.sub=0.8)                         
	}	}
	##########################
	##GroupA <- rownames(Venn.Table..A[Venn.Table..A[,1]==1,]);    GroupA= rownames(Venn.Table..A[c( 1:30),])
	##GroupB <- rownames(Venn.Table..A[Venn.Table..A[,2]==1,]);    GroupB= rownames(Venn.Table..A[c(11:20),])
	##GroupC <- rownames(Venn.Table..A[Venn.Table..A[,3]==1,]);    GroupC= rownames(Venn.Table..A[c(21:30),])
	##GroupD <- rownames(Venn.Table..A[Venn.Table..A[,1]==1,]);    GroupD= rownames(Venn.Table..A[c( 1:20),])
	##GroupE <- rownames(Venn.Table..A[Venn.Table..A[,2]==1,]);    GroupE= rownames(Venn.Table..A[c( 5:15),])
	##GroupF <- rownames(Venn.Table..A[Venn.Table..A[,3]==1,]);    GroupF= rownames(Venn.Table..A[c( 1:25),])
	## venn(list(GrpA=GroupA,GrpB=GroupB,GrpC=GroupC,GrpD=GroupD,GrpE=GroupE,GrpF=GroupF))
}
##############################
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..JOIN.Results.goana.Kegga= function(TABLE.TOGO..KK, TEST.run..KK, print.JOIN.path.kk=c(1,0)[1]) {

## { TABLE.TOGO..KK= TABLE.SAVE.TOGO;  TEST.run..KK= test_RUN.Model;   print.JOIN.path.kk=c(1,0)[1]

############################################################################################################  
if(nrow(TABLE.TOGO..KK)>0) PAths.Unique.VEC..JJ= unique(TABLE.TOGO..KK[,"RawPro.gene"]) else PAths.Unique.VEC..JJ= c()
############                      
if(print.JOIN.path.kk>0) print(paste("############ FFF.RNAseq..JOIN.Results.goana.Kegga   --> paths =", length(PAths.Unique.VEC..JJ),"       Table=", nrow(TABLE.TOGO..KK),"      ",date()  ))  

######################################################
COl..UP..kk= c("Up.All"  ,"P.Up.All"  ,paste("Test",TEST.run..KK,c(".Up"  ,".P.Up"  ),sep=""));
COl.DOWN.kk= c("Down.All","P.Down.All",paste("Test",TEST.run..KK,c(".Down",".P.Down"),sep=""));  
COl.Gene.kk= c("DE.All"  ,"P.DE.All"  ,paste("Test",TEST.run..KK,c(".DE"  ,".P.DE"  ),sep=""));
############
COl..Lima.kk =c();  if(length(RNAseq..Models.Alg..Lima.VEC )>0) COl..Lima.kk = paste("T",TEST.run..KK,".",FFF.RNAseq..JOIN..Get.Columns.Ids(RNAseq..Models.Alg..Lima.VEC , 0),sep="")
COl..edgeR.kk=c();  if(length(RNAseq..Models.Alg..edgeR.VEC)>0) COl..edgeR.kk= paste("T",TEST.run..KK,".",FFF.RNAseq..JOIN..Get.Columns.Ids(RNAseq..Models.Alg..edgeR.VEC, 0),sep="")
COl..DESeq.kk=c();  if(length(RNAseq..Models.Alg..DESeq.VEC)>0) COl..DESeq.kk= paste("T",TEST.run..KK,".",FFF.RNAseq..JOIN..Get.Columns.Ids(RNAseq..Models.Alg..DESeq.VEC, 0),sep="")
############
COl.Algorithms.kk= c(COl..Lima.kk,COl..edgeR.kk,COl..DESeq.kk);   if(length(COl.Algorithms.kk)<=0) stop("MAIN ERROR ---> length(COl.Algorithms.kk)<=0")
############
COl.SOFT..up..kk= paste(COl.Algorithms.kk," "  ,sep="")
COl.SOFT.down.kk= paste(COl.Algorithms.kk,"  " ,sep="")
COl.SOFT..GN..kk= paste(COl.Algorithms.kk,"   ",sep="")
############
COl.Sum.SOft.kk= c("##down",COl.SOFT.down.kk,"##up",COl.SOFT..up..kk,"##geneN",COl.SOFT..GN..kk)
############
COl.Delete..kk= c(paste("Test",TEST.run..KK,".",c("S","A","Up","Down","DE","P.Down","P.Up","P.DE"),sep=""), paste("##T",TEST.run..KK,sep=""), COl.Algorithms.kk, "##TT","##End","N","Method","UP.DOWN")

######################################################
COl.INPUTS..kk= colnames(TABLE.TOGO..KK);   TABLE.JOIN..KK= TABLE.TOGO..KK
############
if(nrow(TABLE.TOGO..KK)>0) {
	conta.test.kk=0;
	for(Paths.kk in PAths.Unique.VEC..JJ){
		TABLE.ONE.KK= TABLE.TOGO..KK[TABLE.TOGO..KK[,"RawPro.gene"]==Paths.kk,];
		############
		TABLE.ONE.UP..KK = TABLE.ONE.KK[TABLE.ONE.KK[,"UP.DOWN"]=="up"       ,];  if(nrow(TABLE.ONE.UP..KK)>1) stop(paste(" kaOS --> ERROR in paths --> nrow(TABLE.ONE.UP..KK)>1    -->", nrow(TABLE.ONE.UP..KK)))
		TABLE.ONE.do..KK = TABLE.ONE.KK[TABLE.ONE.KK[,"UP.DOWN"]=="down"     ,];  if(nrow(TABLE.ONE.do..KK)>1) stop(paste(" kaOS --> ERROR in paths --> nrow(TABLE.ONE.do..KK)>1    -->", nrow(TABLE.ONE.do..KK)))
		TABLE.ONE.gN..KK = TABLE.ONE.KK[TABLE.ONE.KK[,"UP.DOWN"]=="geneN"    ,];  if(nrow(TABLE.ONE.gN..KK)>1) stop(paste(" kaOS --> ERROR in paths --> nrow(TABLE.ONE.gN..KK)>1    -->", nrow(TABLE.ONE.gN..KK)))
		TABLE.Gene.L..KK = TABLE.ONE.KK[TABLE.ONE.KK[,"UP.DOWN"]=="Gene-List",];  if(nrow(TABLE.Gene.L..KK)>1) stop(paste(" kaOS --> ERROR in paths --> nrow(TABLE.Gene.L..KK)>1    -->", nrow(TABLE.Gene.L..KK)))
		############
		HH.kk= (nrow(TABLE.Gene.L..KK)+nrow(TABLE.ONE.UP..KK)+nrow(TABLE.ONE.do..KK)+nrow(TABLE.ONE.gN..KK));  if(HH.kk!=nrow(TABLE.ONE.KK)) stop(paste(" kaOS --> ERROR in join.paths --> nrow(TABLE.ONE.KK)!=sum()     -->", nrow(TABLE.ONE.KK),"!=",HH.kk))
		conta.test.kk=conta.test.kk + HH.kk
		####
		if(nrow(TABLE.Gene.L..KK)>0 & nrow(TABLE.Gene.L..KK)!=nrow(TABLE.ONE.KK)) stop(paste(" kaOS --> ERROR in join.paths --> nrow(TABLE.Gene.L..KK)!=nrow(TABLE.ONE.KK)    -->", nrow(TABLE.Gene.L..KK),"!=",nrow(TABLE.ONE.KK)))
		############ 
		TABLE.ONE.JOIN..KK= TABLE.ONE.KK[1,];   TABLE.ONE.JOIN..KK[1,c(COl..UP..kk,COl.DOWN.kk,COl.Gene.kk,COl.Sum.SOft.kk)]= NA
		############
		#if(nrow(TABLE.Gene.L..KK)==1){ print(TABLE.Gene.L..KK);  print(c(COl..UP..kk,COl.DOWN.kk,COl.Gene.kk)) }
		if(nrow(TABLE.Gene.L..KK)==1) TABLE.ONE.JOIN..KK[1,c("pvalue.A",COl..UP..kk,COl.DOWN.kk,COl.Gene.kk)]= TABLE.Gene.L..KK[1,c("pvalue.A",COl..UP..kk,COl.DOWN.kk,COl.Gene.kk)]
		############
		if(nrow(TABLE.ONE.UP..KK)==1) TABLE.ONE.JOIN..KK[1,COl..UP..kk]= TABLE.ONE.UP..KK[1,COl..UP..kk]
		if(nrow(TABLE.ONE.do..KK)==1) TABLE.ONE.JOIN..KK[1,COl.DOWN.kk]= TABLE.ONE.do..KK[1,COl.DOWN.kk];
		if(nrow(TABLE.ONE.gN..KK)==1) TABLE.ONE.JOIN..KK[1,COl.Gene.kk]= TABLE.ONE.gN..KK[1,COl.Gene.kk]
		############
		#Method.kkk = unique(TABLE.ONE.KK[order(TABLE.ONE.KK[,"Method" ]),"Method" ]);   TABLE.ONE.JOIN..KK[1,"Method" ]= paste(Method.kkk ,collapse=";");   
		#UP.DOWN.kkk= unique(TABLE.ONE.KK[order(TABLE.ONE.KK[,"UP.DOWN"]),"UP.DOWN"]);   TABLE.ONE.JOIN..KK[1,"UP.DOWN"]= paste(UP.DOWN.kkk,collapse=";");   
		Ont....kkk = unique(TABLE.ONE.KK[order(TABLE.ONE.KK[,"Ont"    ]),"Ont"    ]);   Ont....kkk= Ont....kkk[Ont....kkk!="goana2" & Ont....kkk!="kegga1" & Ont....kkk!="kegga2"];  if(length(Ont....kkk)<=0) Ont....kkk= ".";   TABLE.ONE.JOIN..KK[1,"Ont"    ]= paste(Ont....kkk ,collapse=";");
		############
		if(nrow(TABLE.Gene.L..KK)<=0) {
			   VEC.pvalues..KK= c(TABLE.ONE.UP..KK[1,"P.Up.All"],TABLE.ONE.do..KK[1,"P.Down.All"],TABLE.ONE.gN..KK[1,"P.DE.All"]);  VEC.pvalues..KK= VEC.pvalues..KK[!is.na(VEC.pvalues..KK)];  if(length(VEC.pvalues..KK)<=0) VEC.pvalues..KK= -1
			   TABLE.ONE.JOIN..KK[1,"pvalue.A"]= min(as.numeric(VEC.pvalues..KK)) 
		} 
		############
		if(nrow(TABLE.ONE.UP..KK)==1) TABLE.ONE.JOIN..KK[1,COl.SOFT..up..kk]= TABLE.ONE.UP..KK[1,COl.Algorithms.kk]
		if(nrow(TABLE.ONE.do..KK)==1) TABLE.ONE.JOIN..KK[1,COl.SOFT.down.kk]= TABLE.ONE.do..KK[1,COl.Algorithms.kk]
		if(nrow(TABLE.ONE.gN..KK)==1) TABLE.ONE.JOIN..KK[1,COl.SOFT..GN..kk]= TABLE.ONE.gN..KK[1,COl.Algorithms.kk]
		############
		if(Paths.kk==PAths.Unique.VEC..JJ[1]) TABLE.JOIN..KK= TABLE.ONE.JOIN..KK else TABLE.JOIN..KK= rbind(TABLE.JOIN..KK, TABLE.ONE.JOIN..KK)
	}
	############
	TABLE.JOIN..KK[,c("##up","##down","##geneN")]= "##";
	############
	if(conta.test.kk       !=  nrow(TABLE.TOGO..KK      )) stop(paste(" kaOS --> ERROR in paths --> nrow(TABLE.TOGO..KK)!=     conta.test.kk             -->", nrow(TABLE.ONE.KK),"!=",conta.test.kk               ))
	if(nrow(TABLE.JOIN..KK)!=length(PAths.Unique.VEC..JJ)) stop(paste(" kaOS --> ERROR in paths --> nrow(TABLE.TOGO..KK)!=length(PAths.Unique.VEC..JJ)   -->", nrow(TABLE.ONE.KK),"!=",length(PAths.Unique.VEC..JJ)))
	if(print.JOIN.path.kk>0) print(paste("               ---> perfect --> ",nrow(TABLE.JOIN..KK),"      ",date()  ))  
}
############
COl.Out..kk= c(COl.INPUTS..kk,COl.Sum.SOft.kk);   for(Col.k in COl.Delete..kk) COl.Out..kk= COl.Out..kk[COl.Out..kk!=Col.k];   TABLE.JOIN..KK= TABLE.JOIN..KK[,COl.Out..kk];     
TABLE.JOIN..KK[,"##End"]="###"

####################################
return(TABLE.JOIN..KK)
}
######################################################################################################################################################### 
#########################################################################################################################################################
#########################################################################################################################################################


######################################################################################################################################################### 
#########################################################################################################################################################
#########################################################################################################################################################
FFFF..Pvalue.TABLE.Genes.list= function(TABLE.Genes...LLL, TABLE.COMPL...LLL, TEST.run..KK, Use.Col.Max.Mean..LL= c(".Max",".Mean",".Min")[1], MIN.logFC...LLL, MAX.PValue...LLL, MAX.FDR...LLL, print.pavlue.ll= c(1,2,0)[1] ) {

############################################# 
UNA.YES.llll= c(0,1,2,-1)[4];    MIN.num.genes.ll= 3;  MAIn.COLMUNS.LL= c("P.Up","P.Down","Up","Down","P.DE","DE")
##################
COL.logFC..LL= paste("logFC" ,Use.Col.Max.Mean..LL,sep="")
COL.PValu..LL= paste("PValue",Use.Col.Max.Mean..LL,sep="")
COL.FDR....LL= paste("FDR"   ,Use.Col.Max.Mean..LL,sep="")
#########
if(nrow(TABLE.Genes...LLL)>0) {
	##########
	TABLE.Filter...LLL= TABLE.COMPL...LLL
   #if(MIN.logFC...LLL  >0                      ) TABLE.Filter...LLL= TABLE.Filter...LLL[abs(as.numeric(TABLE.Filter...LLL[,COL.logFC..LL]))>= MIN.logFC...LLL ,]
    if(MAX.PValue...LLL >0 & MAX.PValue...LLL <1) TABLE.Filter...LLL= TABLE.Filter...LLL[    as.numeric(TABLE.Filter...LLL[,COL.PValu..LL]) <= MAX.PValue...LLL,]
	if(MAX.FDR...LLL    >0 & MAX.FDR...LLL    <1) TABLE.Filter...LLL= TABLE.Filter...LLL[    as.numeric(TABLE.Filter...LLL[,COL.FDR....LL]) <= MAX.FDR...LLL   ,]
	##########
	TABLE.Genes...LLL[,c(paste(MAIn.COLMUNS.LL,".All",sep=""))]= NA     ## ,paste("T",TEST.run..KK,".",MAIn.COLMUNS.LL,sep="")
	##########
	for(RR.l in c(1:nrow(TABLE.Genes...LLL))) { 
		PVALUE.VEC.ll=c(1);    GENES.VEC.ll=c(0);
		for(CASE.ll in c("UP","DOWN","GeneN")){  ## RR.l=1
			##########
			NN.LL=  as.integer(TABLE.Genes...LLL[RR.l,"Ngenes.GoTo"]);    PVALUE= 1
			if(NN.LL>0) {
				GENES..VEC..LL= unique(unlist(strsplit(TABLE.Genes...LLL[RR.l,"GeneID.GoTo"], ",", fixed=TRUE)))
				if(length(GENES..VEC..LL)!=NN.LL) stop("ERROR -- length(GENES..VEC..LL)!=NN.LL")
			}
			if(NN.LL>=MIN.num.genes.ll & NN.LL>1) {
				##########
				AFF.YES.ll=0;  
				if(CASE.ll=="UP"   ) for(Gene.ll in GENES..VEC..LL) if(nrow(TABLE.Filter...LLL[TABLE.Filter...LLL[,"RawPro.gene"]==Gene.ll &     as.numeric(TABLE.Filter...LLL[,COL.logFC..LL]) >=  MIN.logFC...LLL,])>0) AFF.YES.ll= AFF.YES.ll + 1;
				if(CASE.ll=="DOWN" ) for(Gene.ll in GENES..VEC..LL) if(nrow(TABLE.Filter...LLL[TABLE.Filter...LLL[,"RawPro.gene"]==Gene.ll &     as.numeric(TABLE.Filter...LLL[,COL.logFC..LL]) <= -MIN.logFC...LLL,])>0) AFF.YES.ll= AFF.YES.ll + 1; 
				if(CASE.ll=="GeneN") for(Gene.ll in GENES..VEC..LL) if(nrow(TABLE.Filter...LLL[TABLE.Filter...LLL[,"RawPro.gene"]==Gene.ll & abs(as.numeric(TABLE.Filter...LLL[,COL.logFC..LL]))>=  MIN.logFC...LLL,])>0) AFF.YES.ll= AFF.YES.ll + 1;
				##########
				UNA.YES.lll= UNA.YES.llll;    if(UNA.YES.llll==-1) UNA.YES.lll= max(c(2,ceiling(as.integer(NN.LL)*.01)))
				UNA.YES.ll= min(c(UNA.YES.lll,NN.LL));     if(UNA.YES.ll>NN.LL) stop("ERROR -- fisher test UNA");  if(AFF.YES.ll>NN.LL) stop("ERROR -- fisher test  AFF")
				##########
				FISHER.MAT.ll= rbind( c(UNA.YES.ll, (NN.LL-UNA.YES.ll)), c(AFF.YES.ll,(NN.LL-AFF.YES.ll)));  if(print.pavlue.ll>1) print(FISHER.MAT.ll)
				########## 
				PVALUE.ll= fisher.test(FISHER.MAT.ll)$p.value;
				PVALUE.VEC.ll=c(PVALUE.VEC.ll,PVALUE.ll);   GENES.VEC.ll=c(GENES.VEC.ll,AFF.YES.ll);
				##########
				if(CASE.ll=="UP"   ) {
					TABLE.Genes...LLL[RR.l,c(    "Up.All",  paste("T",TEST.run..KK,  ".Up"  ,sep=""))[1]]= AFF.YES.ll
					TABLE.Genes...LLL[RR.l,c(  "P.Up.All",  paste("T",TEST.run..KK,".P.Up"  ,sep=""))[1]]= PVALUE.ll
				}
				if(CASE.ll=="DOWN" ) {
					TABLE.Genes...LLL[RR.l,c(  "Down.All",  paste("T",TEST.run..KK,  ".Down",sep=""))[1]]= AFF.YES.ll
					TABLE.Genes...LLL[RR.l,c("P.Down.All",  paste("T",TEST.run..KK,".P.Down",sep=""))[1]]= PVALUE.ll
				}
				if(CASE.ll=="GeneN") {
					TABLE.Genes...LLL[RR.l,c(    "DE.All",  paste("T",TEST.run..KK,  ".DE"  ,sep=""))[1]]= AFF.YES.ll
					TABLE.Genes...LLL[RR.l,c(  "P.DE.All",  paste("T",TEST.run..KK,".P.DE"  ,sep=""))[1]]= PVALUE.ll
				}
				##########
				PVALUE.Format.ll= as.numeric(format(as.numeric(PVALUE.ll),digits = 1, nsmall = 5));
				if(print.pavlue.ll>0) print(paste("  Ngenes=",NN.LL ,"   Yes=",AFF.YES.ll ,"     pvalue=", PVALUE.Format.ll,"      ",CASE.ll,"    rr=",RR.l)) 
		}	}	
		#TABLE.Genes...LLL[RR.l,"pvalue.A"]= as.numeric(format(min(as.numeric(PVALUE.VEC.ll)),digits = 1, nsmall = 4))
		TABLE.Genes...LLL[RR.l,"pvalue.A"]= min(as.numeric(PVALUE.VEC.ll))
		TABLE.Genes...LLL[RR.l,"genes.A" ]= max(as.numeric(GENES.VEC.ll ))
}	}
#########
return(TABLE.Genes...LLL)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF..TABLE.TOGO..Divide.genes.Columns= function(TABLE.TOGO.Inp.CSV..PP, RNAseq..MAX.characters.saving.PPP= RNAseq..MAX.characters.saving.CSV ) {

COl.SAVINGS.CVS=colnames(TABLE.TOGO.Inp.CSV..PP);  for(COL.de in c("genes.GoTo","GeneID.GoTo")) COl.SAVINGS.CVS= COl.SAVINGS.CVS[COl.SAVINGS.CVS!=COL.de]
#########
if(nrow(TABLE.TOGO.Inp.CSV..PP)>0) {
	TABLE.TOGO.Inp.CSV..PP[ is.na(TABLE.TOGO.Inp.CSV..PP[,"Ngenes.GoTo"]),"genes.GoTo"]=""
	TABLE.TOGO.Inp.CSV..PP[!is.na(TABLE.TOGO.Inp.CSV..PP[,"Ngenes.GoTo"]) & TABLE.TOGO.Inp.CSV..PP[,"Ngenes.GoTo"]==0,"genes.GoTo"]=""
	#########
	TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]= nchar(TABLE.TOGO.Inp.CSV..PP[,"genes.GoTo"]);    ###TABLE.TOGO.Inp.CSV..PP[is.na(TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]),]
	################################
	         TABLE.TOGO.Inp.CSV..PP[,"genes.GoTo1"]= substr(TABLE.TOGO.Inp.CSV..PP[,"genes.GoTo"], 1, RNAseq..MAX.characters.saving.PPP )
	         if(length( TABLE.TOGO.Inp.CSV..PP[TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]>(1*RNAseq..MAX.characters.saving.PPP),"Ngenes.GoTo" ])>0)
	                    TABLE.TOGO.Inp.CSV..PP[TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]>(1*RNAseq..MAX.characters.saving.PPP), "genes.GoTo2"]= substr(
	                    TABLE.TOGO.Inp.CSV..PP[TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]>(1*RNAseq..MAX.characters.saving.PPP), "genes.GoTo" ], ((1*RNAseq..MAX.characters.saving.PPP)-30), (2*RNAseq..MAX.characters.saving.PPP))
	         if(length( TABLE.TOGO.Inp.CSV..PP[TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]>(2*RNAseq..MAX.characters.saving.PPP),"Ngenes.GoTo" ])>0)	                    
	                    TABLE.TOGO.Inp.CSV..PP[TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]>(2*RNAseq..MAX.characters.saving.PPP), "genes.GoTo3"]= substr(
	                    TABLE.TOGO.Inp.CSV..PP[TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]>(2*RNAseq..MAX.characters.saving.PPP), "genes.GoTo" ], ((2*RNAseq..MAX.characters.saving.PPP)-30), (3*RNAseq..MAX.characters.saving.PPP))
	ERROR.mas.TOGO.CSV= TABLE.TOGO.Inp.CSV..PP[TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]>(3*RNAseq..MAX.characters.saving.PPP),]
	if(nrow(ERROR.mas.TOGO.CSV)>0) stop(paste("MAIn ERROR --> ERROR --> characters more than 3*RNAseq..MAX.characters.saving.CVS == rows=",nrow(ERROR.mas.TOGO.CSV)))
	#print(max(TABLE.TOGO.Inp.CSV..PP[,"XXX.nchar"]))
}
TABLE.TOGO.Inp.CSV..PP= TABLE.TOGO.Inp.CSV..PP[,COl.SAVINGS.CVS]
#########
return(TABLE.TOGO.Inp.CSV..PP)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq..Path.analysis..Load.MAIN.GENE.PATH.files= function(DIR_Annotations.Organism.GGG, TABLEs.INP.GGG, Output.Kaos.or.Org.GGG= c(1,2)[1] ){

#### DIR_Annotations.Organism.GGG=DIR_Annotations.Organism;    TABLEs.INP.GGG=TABLEs.ALL.ALL.Plot;    Output.Kaos.or.Org.GGG= c(1,2)[1]

################################################################################################
TXT.REMOVE.KEGG.rr="error";
if(DIR_Annotations.Organism.GGG=="Homo_sapiens"     ){ SPECIES.GOGO=  "Hs";   SPECIES.GO.keg= "hsa";   RNAseq..Organism.gene_inf..ff= "Homo_sapiens.gene_info";   		FILE.GO.ORG..GGG= "goa_human.gaf";   TXT.REMOVE.KEGG.rr= " - Homo sapiens (Human)"     }
if(DIR_Annotations.Organism.GGG=="Mus_musculus"     ){ SPECIES.GOGO=  "Mm";   SPECIES.GO.keg= "mmu";   RNAseq..Organism.gene_inf..ff= "Mus_musculus.gene_info";   		FILE.GO.ORG..GGG= "mgi.gaf";         TXT.REMOVE.KEGG.rr= " - Mus musculus (mouse)"    }
if(DIR_Annotations.Organism.GGG=="Rattus_norvegicus"){ SPECIES.GOGO=  "Rn";   SPECIES.GO.keg= "rno";   RNAseq..Organism.gene_inf..ff= "Rattus_norvegicus.gene_info";   	FILE.GO.ORG..GGG= "rgd.gaf";         TXT.REMOVE.KEGG.rr= " - Rattus norvegicus (Rat)" }
if(TXT.REMOVE.KEGG.rr=="error") stop("MAIN ERROR --->  TXT.REMOVE.KEGG.rr==error")
########
TABLEs.GENES.GOGO= unique(TABLEs.INP.GGG[,c("Raw.geneID","gene.PLOT")]);   length(unique(TABLEs.GENES.GOGO[,"Raw.geneID"]));  length(unique(TABLEs.GENES.GOGO[,"gene.PLOT"]));   dim(TABLEs.GENES.GOGO) 

################################################ Files to load {
################################################
DIR.GO.ORG..GGG= paste(DIR_RNAseq..Annot.Genes,DIR_Annotations.Organism.GGG,"/",RNAseq..Version..Gene.info,sep="")

################ Anno
HGMD.ANNO= read.delim( paste(DIR.GO.ORG..GGG,"/",RNAseq..Organism.gene_inf..ff,sep=""), header=TRUE, stringsAsFactors=F);    	  print(paste(" Loading GeneID data base --> Version=",RNAseq..Version..Gene.info,"      file=", RNAseq..Organism.gene_inf..ff))  

################ Go
go_ORG.MATRIX.GGG= read.delim( paste(DIR.GO.ORG..GGG,"/",FILE.GO.ORG..GGG,sep=""), header=FALSE, stringsAsFactors=F);    	print(paste(" Loading     GO data base --> Version=",RNAseq..Version..Gene.info,"      file=", FILE.GO.ORG..GGG));  print("")
go_USE.MATRIX.GGG= unique(go_ORG.MATRIX.GGG[,c("V3","V5")]);  colnames(go_USE.MATRIX.GGG)= c("Gene","PathwayID")
########
goana.Pathway.GGG = goana(unique(TABLEs.INP.GGG[,"Raw.geneID"]), species=SPECIES.GOGO)
goana.Pathway.GGG[,"PathwayID"]= rownames(goana.Pathway.GGG);     goana.Pathway.GGG= unique(goana.Pathway.GGG[,c("PathwayID","Term")]);       colnames(goana.Pathway.GGG)= c("PathwayID","Description");   ## head(goana.Pathway.GGG);  tail(goana.Pathway.GGG);  dim(goana.Pathway.GGG)

################ KEGG
GeneKEGGLinks.ORG..GGG  = getGeneKEGGLinks   (species.KEGG = SPECIES.GO.keg)
getKEGGPathway.ORG...GGG= getKEGGPathwayNames(species.KEGG = SPECIES.GO.keg, remove.qualifier=TRUE)   ## remove.qualifier=TRUE, the species qualifier will be removed from the pathway names
getKEGGPathway.ORG...GGG[,"Description"]= gsub(TXT.REMOVE.KEGG.rr,"",getKEGGPathway.ORG...GGG[,"Description"], fixed=TRUE) 
#######
if(nrow(getKEGGPathway.ORG...GGG)>0) getKEGGPathway.ORG...GGG[,"PathwayID"]= paste("path:",getKEGGPathway.ORG...GGG[,"PathwayID"],sep="")

################################################ GO (annotation of genes) {
################################################
go_USE.MATRIX.GGG[,"MATCH"]= match( toupper(go_USE.MATRIX.GGG[,"Gene"]), toupper(HGMD.ANNO[,"Symbol"]) );           		GO.A..Paths.gg= length(unique(go_USE.MATRIX.GGG [,"PathwayID"]));    GO.A.Genes.gg= length(unique(go_USE.MATRIX.GGG[,"Gene"])); 
go_USE.Remo1.GGG= go_USE.MATRIX.GGG[ is.na(go_USE.MATRIX.GGG[,"MATCH"]),];                                         			GO.R1.Genes.gg= length(unique(go_USE.Remo1.GGG[,"Gene"      ]));     
go_USE.GENES.GGG = go_USE.MATRIX.GGG[!is.na(go_USE.MATRIX.GGG[,"MATCH"]),];                                    	    		GO.G..Paths.gg= length(unique(go_USE.GENES.GGG [,"PathwayID" ]));
go_USE.GENES.GGG[,c("GeneID","Symbol")]= HGMD.ANNO[go_USE.GENES.GGG[,"MATCH"],c("GeneID","Symbol")]
ERROR.MATCH1.RR= go_USE.GENES.GGG[toupper(go_USE.GENES.GGG[,"Gene"])!=toupper(go_USE.GENES.GGG[,"Symbol"]),];  				if(nrow(ERROR.MATCH1.RR)>0) stop("MAIN ERROR ---> nrow(ERROR.MATCH1.RR)>0")
########
go_USE.GENES.GGG[,"MATCH"]= match( toupper(go_USE.GENES.GGG[,"PathwayID"]), toupper(goana.Pathway.GGG[,"PathwayID"]));
go_USE.Remo2.GGG= go_USE.GENES.GGG[ is.na(go_USE.GENES.GGG[,"MATCH"]),];                                    				GO.R2.Genes.gg= length(unique(go_USE.Remo2.GGG[,"GeneID"   ]));     
go_USE.PATHS.GGG= go_USE.GENES.GGG[!is.na(go_USE.GENES.GGG[,"MATCH"]),];                                    				GO.P..Paths.gg= length(unique(go_USE.PATHS.GGG[,"PathwayID"]));
go_USE.PATHS.GGG[,c("PathwayID3","Description")]= goana.Pathway.GGG[go_USE.PATHS.GGG[,"MATCH"],c("PathwayID","Description")]
ERROR.MATCH2.RR= go_USE.PATHS.GGG[toupper(go_USE.PATHS.GGG[,"PathwayID"])!=toupper(go_USE.PATHS.GGG[,"PathwayID3"]),];  	if(nrow(ERROR.MATCH2.RR)>0) stop("MAIN ERROR ---> nrow(ERROR.MATCH2.RR)>0")
########
go_USE.PATHS.GGG[,"MATCH"]= match(go_USE.PATHS.GGG[,"GeneID"], TABLEs.GENES.GOGO[,"Raw.geneID"]);
go_USE.Remo3.GGG= go_USE.PATHS.GGG[ is.na(go_USE.PATHS.GGG[,"MATCH"]),];                                    				GO.R3.Genes.gg= length(unique(go_USE.Remo3.GGG[,"GeneID"   ])); 
go_USE.CLEAN.GGG= go_USE.PATHS.GGG[!is.na(go_USE.PATHS.GGG[,"MATCH"]),];                               						GO.C..Paths.gg= length(unique(go_USE.CLEAN.GGG[,"PathwayID"]));
########
go_USE.CLEAN.GGG[,c("GeneID3","gene.PLOT")]= TABLEs.GENES.GOGO[go_USE.CLEAN.GGG[,"MATCH"],c("Raw.geneID","gene.PLOT")]
ERROR.MATCH3.RR= go_USE.CLEAN.GGG[toupper(go_USE.CLEAN.GGG[,"GeneID"])!=toupper(go_USE.CLEAN.GGG[,"GeneID3"  ]),];  	if(nrow(ERROR.MATCH3.RR)>0) stop (paste("MAIN ERROR ---> nrow(ERROR.MATCH3.RR)>0 ---> ",nrow(ERROR.MATCH3.RR),"  of", nrow(go_USE.CLEAN.GGG) ))
ERROR.MATCH4.RR= go_USE.CLEAN.GGG[toupper(go_USE.CLEAN.GGG[, "Gene" ])!=toupper(go_USE.CLEAN.GGG[,"gene.PLOT"]),];  	if(nrow(ERROR.MATCH4.RR)>0) print(paste("MAIN ERROR ---> nrow(ERROR.MATCH4.RR)>0 ---> ",nrow(ERROR.MATCH4.RR),"  of", nrow(go_USE.CLEAN.GGG) ))
########
print(paste(" GO original        ---> new=", nrow(go_USE.MATRIX.GGG),"     paths=",GO.A..Paths.gg,"     genes =",GO.A.Genes.gg ));
print(paste(" GO matching GeneID ---> new=", nrow(go_USE.GENES.GGG ),"     paths=",GO.G..Paths.gg,"     remove=",nrow(go_USE.Remo1.GGG),"rows;    genes=",GO.R1.Genes.gg,"of",GO.A.Genes.gg,"    paths=", (GO.A..Paths.gg-GO.G..Paths.gg) ));
print(paste(" GO matching Terms  ---> new=", nrow(go_USE.PATHS.GGG ),"     paths=",GO.P..Paths.gg,"     remove=",nrow(go_USE.Remo2.GGG),"rows;    genes=",GO.R2.Genes.gg,"of",GO.A.Genes.gg,"    paths=", (GO.G..Paths.gg-GO.P..Paths.gg) ));
print(paste(" GO matching TABLEs ---> new=", nrow(go_USE.CLEAN.GGG ),"     paths=",GO.C..Paths.gg,"     remove=",nrow(go_USE.Remo3.GGG),"rows;    genes=",GO.R3.Genes.gg,"of",GO.A.Genes.gg,"    paths=", (GO.P..Paths.gg-GO.C..Paths.gg) ));  print("") 
########
go_USE.GENES.GGG= unique(go_USE.GENES.GGG[,c("GeneID","PathwayID","Gene"                          )]);     ## head(go_USE.GENES.GGG);  tail(go_USE.GENES.GGG);   dim(go_USE.GENES.GGG)
go_USE.PATHS.GGG= unique(go_USE.PATHS.GGG[,c("GeneID","PathwayID","Gene",            "Description")]);     ## head(go_USE.PATHS.GGG);  tail(go_USE.PATHS.GGG);   dim(go_USE.PATHS.GGG)
go_USE.CLEAN.GGG= unique(go_USE.CLEAN.GGG[,c("GeneID","PathwayID","Gene","gene.PLOT","Description")]);     ## head(go_USE.CLEAN.GGG);  tail(go_USE.CLEAN.GGG);   dim(go_USE.CLEAN.GGG)
########
######## table(ERROR.MATCH4.RR[,"Gene"]) 

################################################ KEGG (annotation of genes) {
################################################
GeneKEGGLinks.ORG..GGG[,"MATCH"]= match( toupper(GeneKEGGLinks.ORG..GGG[,"GeneID"]), toupper(HGMD.ANNO[,"GeneID"]) );           				KEGG.A..Paths.gg= length(unique(GeneKEGGLinks.ORG..GGG[,"PathwayID"]));    KEGG.A.Genes.gg= length(unique(GeneKEGGLinks.ORG..GGG[,"GeneID"]));
GeneKEGGLinks.Remo1.GGG= GeneKEGGLinks.ORG..GGG[ is.na(GeneKEGGLinks.ORG..GGG[,"MATCH"]),];                                    	 				KEGG.R1.Genes.gg= length(unique(GeneKEGGLinks.Remo1.GGG[,"GeneID"   ]));     
GeneKEGGLinks.GENES.GGG= GeneKEGGLinks.ORG..GGG[!is.na(GeneKEGGLinks.ORG..GGG[,"MATCH"]),];                                    					KEGG.G..Paths.gg= length(unique(GeneKEGGLinks.GENES.GGG[,"PathwayID"]));
GeneKEGGLinks.GENES.GGG[,c("GeneID2","Gene")]= HGMD.ANNO[GeneKEGGLinks.GENES.GGG[,"MATCH"],c("GeneID","Symbol")]
ERROR.MATCH5.RR= GeneKEGGLinks.GENES.GGG[toupper(GeneKEGGLinks.GENES.GGG[,"GeneID"])!=toupper(GeneKEGGLinks.GENES.GGG[,"GeneID2"]),];  			if(nrow(ERROR.MATCH5.RR)>0) stop("MAIN ERROR ---> nrow(ERROR.MATCH5.RR)>0")
########
GeneKEGGLinks.GENES.GGG[,"MATCH"]= match( toupper(GeneKEGGLinks.GENES.GGG[,"PathwayID"]), toupper(getKEGGPathway.ORG...GGG[,"PathwayID"]));
GeneKEGGLinks.Remo2.GGG= GeneKEGGLinks.GENES.GGG[ is.na(GeneKEGGLinks.GENES.GGG[,"MATCH"]),];                                    				KEGG.R2.Genes.gg= length(unique(GeneKEGGLinks.Remo2.GGG[,"GeneID"   ]));     
GeneKEGGLinks.PATHS.GGG= GeneKEGGLinks.GENES.GGG[!is.na(GeneKEGGLinks.GENES.GGG[,"MATCH"]),];                                    				KEGG.P..Paths.gg= length(unique(GeneKEGGLinks.PATHS.GGG[,"PathwayID"]));
GeneKEGGLinks.PATHS.GGG[,c("PathwayID3","Description")]= getKEGGPathway.ORG...GGG[GeneKEGGLinks.PATHS.GGG[,"MATCH"],c("PathwayID","Description")]
ERROR.MATCH6.RR= GeneKEGGLinks.PATHS.GGG[toupper(GeneKEGGLinks.PATHS.GGG[,"PathwayID"])!=toupper(GeneKEGGLinks.PATHS.GGG[,"PathwayID3"]),];  	if(nrow(ERROR.MATCH6.RR)>0) stop("MAIN ERROR ---> nrow(ERROR.MATCH6.RR)>0")
########
GeneKEGGLinks.PATHS.GGG[,"MATCH"]= match(GeneKEGGLinks.PATHS.GGG[,"GeneID"], TABLEs.GENES.GOGO[,"Raw.geneID"]);
GeneKEGGLinks.Remo3.GGG= GeneKEGGLinks.PATHS.GGG[ is.na(GeneKEGGLinks.PATHS.GGG[,"MATCH"]),];                                    				KEGG.R3.Genes.gg= length(unique(GeneKEGGLinks.Remo3.GGG[,"GeneID" ])); 
GeneKEGGLinks.CLEAN.GGG= GeneKEGGLinks.PATHS.GGG[!is.na(GeneKEGGLinks.PATHS.GGG[,"MATCH"]),];                               					KEGG.C..Paths.gg= length(unique(GeneKEGGLinks.CLEAN.GGG[,"PathwayID"]));
GeneKEGGLinks.CLEAN.GGG[,c("GeneID3","gene.PLOT")]= TABLEs.GENES.GOGO[GeneKEGGLinks.CLEAN.GGG[,"MATCH"],c("Raw.geneID","gene.PLOT")]
ERROR.MATCH7.RR= GeneKEGGLinks.CLEAN.GGG[toupper(GeneKEGGLinks.CLEAN.GGG[,"GeneID"])!=toupper(GeneKEGGLinks.CLEAN.GGG[,"GeneID3"  ]),];  		if(nrow(ERROR.MATCH7.RR)>0) stop(paste("MAIN ERROR ---> nrow(ERROR.MATCH7.RR)>0 ---> ",nrow(ERROR.MATCH7.RR),"  of", nrow(GeneKEGGLinks.CLEAN.GGG) ))
ERROR.MATCH8.RR= GeneKEGGLinks.CLEAN.GGG[toupper(GeneKEGGLinks.CLEAN.GGG[, "Gene" ])!=toupper(GeneKEGGLinks.CLEAN.GGG[,"gene.PLOT"]),];  		if(nrow(ERROR.MATCH8.RR)>0) print(paste("MAIN ERROR ---> nrow(ERROR.MATCH8.RR)>0 ---> ",nrow(ERROR.MATCH8.RR),"  of", nrow(GeneKEGGLinks.CLEAN.GGG) ))
########
print(paste(" KEGG original        ---> new=", nrow(GeneKEGGLinks.ORG..GGG ),"     paths=",KEGG.A..Paths.gg,"      genes=",KEGG.A.Genes.gg ));
print(paste(" KEGG matching GeneID ---> new=", nrow(GeneKEGGLinks.GENES.GGG),"     paths=",KEGG.G..Paths.gg,"     remove=",nrow(GeneKEGGLinks.Remo1.GGG),"rows;    genes=",KEGG.R1.Genes.gg,"of",KEGG.A.Genes.gg,"    paths=", (KEGG.A..Paths.gg-KEGG.G..Paths.gg) ));
print(paste(" KEGG matching Terms  ---> new=", nrow(GeneKEGGLinks.PATHS.GGG),"     paths=",KEGG.P..Paths.gg,"     remove=",nrow(GeneKEGGLinks.Remo2.GGG),"rows;    genes=",KEGG.R2.Genes.gg,"of",KEGG.A.Genes.gg,"    paths=", (KEGG.G..Paths.gg-KEGG.P..Paths.gg) ));
print(paste(" KEGG matching TABLEs ---> new=", nrow(GeneKEGGLinks.CLEAN.GGG),"     paths=",KEGG.C..Paths.gg,"     remove=",nrow(GeneKEGGLinks.Remo3.GGG),"rows;    genes=",KEGG.R3.Genes.gg,"of",KEGG.A.Genes.gg,"    paths=", (KEGG.P..Paths.gg-KEGG.C..Paths.gg) ));  print("") 
########
GeneKEGGLinks.GENES.GGG= unique(GeneKEGGLinks.GENES.GGG[,c("GeneID","PathwayID","Gene"                          )]);        ## head(GeneKEGGLinks.GENES.GGG);  tail(GeneKEGGLinks.GENES.GGG);   dim(GeneKEGGLinks.GENES.GGG)
GeneKEGGLinks.PATHS.GGG= unique(GeneKEGGLinks.PATHS.GGG[,c("GeneID","PathwayID","Gene",            "Description")]);        ## head(GeneKEGGLinks.PATHS.GGG);  tail(GeneKEGGLinks.PATHS.GGG);   dim(GeneKEGGLinks.PATHS.GGG)
GeneKEGGLinks.CLEAN.GGG= unique(GeneKEGGLinks.CLEAN.GGG[,c("GeneID","PathwayID","Gene","gene.PLOT","Description")]);     	## head(GeneKEGGLinks.CLEAN.GGG);  tail(GeneKEGGLinks.CLEAN.GGG);   dim(GeneKEGGLinks.CLEAN.GGG)

################################################ JOIN (annotation of genes) {
################################################
GeneJOIN.GENES.GGG= rbind(go_USE.GENES.GGG,GeneKEGGLinks.GENES.GGG);   ## head(GeneJOIN.GENES.GGG);  tail(GeneJOIN.GENES.GGG);   dim(GeneJOIN.GENES.GGG)
GeneJOIN.PATHS.GGG= rbind(go_USE.PATHS.GGG,GeneKEGGLinks.PATHS.GGG);   ## head(GeneJOIN.PATHS.GGG);  tail(GeneJOIN.PATHS.GGG);   dim(GeneJOIN.PATHS.GGG)
GeneJOIN.CLEAN.GGG= rbind(go_USE.CLEAN.GGG,GeneKEGGLinks.CLEAN.GGG);   ## head(GeneJOIN.CLEAN.GGG);  tail(GeneJOIN.CLEAN.GGG);   dim(GeneJOIN.CLEAN.GGG)
########
GeneKAOS.GENES.GGG= GeneJOIN.GENES.GGG;   GeneKAOS.GENES.GGG[,"PathwayID"]= gsub("path:","locoK:", GeneKAOS.GENES.GGG[,"PathwayID"], fixed=TRUE);   GeneKAOS.GENES.GGG[,"PathwayID"]= gsub("GO:","locoG:", GeneKAOS.GENES.GGG[,"PathwayID"], fixed=TRUE);
GeneKAOS.PATHS.GGG= GeneJOIN.PATHS.GGG;   GeneKAOS.PATHS.GGG[,"PathwayID"]= gsub("path:","locoK:", GeneKAOS.PATHS.GGG[,"PathwayID"], fixed=TRUE);   GeneKAOS.PATHS.GGG[,"PathwayID"]= gsub("GO:","locoG:", GeneKAOS.PATHS.GGG[,"PathwayID"], fixed=TRUE);
GeneKAOS.CLEAN.GGG= GeneJOIN.CLEAN.GGG;   GeneKAOS.CLEAN.GGG[,"PathwayID"]= gsub("path:","locoK:", GeneKAOS.CLEAN.GGG[,"PathwayID"], fixed=TRUE);   GeneKAOS.CLEAN.GGG[,"PathwayID"]= gsub("GO:","locoG:", GeneKAOS.CLEAN.GGG[,"PathwayID"], fixed=TRUE);
########
if(length(grep("loco",GeneKAOS.GENES.GGG[,"PathwayID"],fixed=TRUE))!=nrow(GeneKAOS.GENES.GGG))  stop(paste("main ERROR   --> length(grep(loco,GeneKAOS.GENES.GGG))!=nrow(GeneKAOS.GENES.GGG)"))
if(length(grep("loco",GeneKAOS.PATHS.GGG[,"PathwayID"],fixed=TRUE))!=nrow(GeneKAOS.PATHS.GGG))  stop(paste("main ERROR   --> length(grep(loco,GeneKAOS.PATHS.GGG))!=nrow(GeneKAOS.PATHS.GGG)"))
if(length(grep("loco",GeneKAOS.CLEAN.GGG[,"PathwayID"],fixed=TRUE))!=nrow(GeneKAOS.CLEAN.GGG))  stop(paste("main ERROR   --> length(grep(loco,GeneKAOS.CLEAN.GGG))!=nrow(GeneKAOS.CLEAN.GGG)"))
########
## head(GeneKAOS.GENES.GGG);  tail(GeneKAOS.GENES.GGG);   dim(GeneKAOS.GENES.GGG)
## head(GeneKAOS.PATHS.GGG);  tail(GeneKAOS.PATHS.GGG);   dim(GeneKAOS.PATHS.GGG)
## head(GeneKAOS.CLEAN.GGG);  tail(GeneKAOS.CLEAN.GGG);   dim(GeneKAOS.CLEAN.GGG)

################################################################################################    
if(Output.Kaos.or.Org.GGG==1){
	Go.KEGG.GeneLinks..GENES..FFF <<- GeneKAOS.GENES.GGG
	Go.KEGG.GeneLinks..PATHS..FFF <<- GeneKAOS.PATHS.GGG
	Go.KEGG.GeneLinks..CLEAN..FFF <<- GeneKAOS.CLEAN.GGG
} else {
	Go.KEGG.GeneLinks..GENES..FFF <<- GeneKEGGLinks.GENES.GGG
	Go.KEGG.GeneLinks..PATHS..FFF <<- GeneKEGGLinks.PATHS.GGG
	Go.KEGG.GeneLinks..CLEAN..FFF <<- GeneKEGGLinks.CLEAN.GGG
}
#Go.KEGG.GeneLinks..MAIN.GENES..FFF <<- GeneJOIN.GENES.GGG;		##Go.KEGG.GeneLinks..MAIN.GENES..FFF <<- GeneKEGGLinks.GENES.GGG
 Go.KEGG.GeneLinks..MAIN.GENES..FFF <<- GeneJOIN.PATHS.GGG
#Go.KEGG.GeneLinks..MAIN.GENES..FFF <<- GeneJOIN.CLEAN.GGG
################
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


