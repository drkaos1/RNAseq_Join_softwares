
#########################################################################################################################################################  
#########################################################################################################################################################
######################################################################################################################################################### 
FFF.RNAseq..Filter.Targets..MAKE.test= function(Project.RNA..run.NN, test_run..NN, Targets.INP..NN, print_test.NN=c(1,0)[1], TXT.JOIN.Samples..tt="/") {

### Project.RNA..run.NN="Talal..P2.Hanni";  test_run..NN=4;   Targets.INP..NN=Targets; print_test.NN=1;  TXT.JOIN.Samples..tt="/"

####################################################################################
### kaOs --> Always use "Aff,UnA"  --> reason, it change the sign for log results logFC (order of AFF,UNA made by Desq)

####################################################################################
print(paste(" --> Test design:  (test=",test_run..NN,")",sep=""));

###################################
if(nrow(Targets.INP..NN)>0) {
	###############
	COL.Patient_number.NN = COL.for.RM.Sampels.IDs= "Patient_number"; 	    COL.Tisssue.libType.NN= "Tissue.Column";   ### ejemplo: libType = c("Tisssue","single-end", "paired-end")  
	RM.Sampels.IDs..VEC..NN= c();       COL.Print..Extra.NN= c();  			Test.VEC..OUT.NN= c("Aff","UnA")
	
	#######################################################################################################################################
	#######################################################################################################################################
	Targets.INP..NN[,"Test"]= "";    if(test_run..NN==0) Targets.INP..NN[,"Test"]= "remove samples";       test_run..NN= paste(test_run..NN)
	
	####################################################################################################################################### 
	####################################################################################################################################### Talal    
	
	############################################# Talal..P20..Qian..N3 (KSA.2024) 
	############################################# 
	if(Project.RNA..run.NN=="Example..P1") {
		########
		RM.Sampels.IDs..VEC..NN=c();		COL.Print..Extra.NN= c("Patient_number.G1");	
		########
		if(test_run..NN=="1" | test_run..NN=="1R" | test_run..NN=="1RR"){
			Targets.INP..NN[Targets.INP..NN[,"Patient_number.G1"]=="B","Test"]="KO";					Test.VEC..OUT.NN= c("KO","WT")
			Targets.INP..NN[Targets.INP..NN[,"Patient_number.G1"]=="A","Test"]="WT"
			if(test_run..NN=="1R") RM.Sampels.IDs..VEC..NN= c()
		}	
	}
	
	####################################################################################################################################### 
	####################################################################################################################################### Talal    
	
	
	#################################################################################### 
	Targets.INP..NN= Targets.INP..NN[Targets.INP..NN[,"Test"]!="",];
	#########
	Test.VEC..NN= unique(Targets.INP..NN[,"Test"]);  									if(length(Test.VEC..NN)!=2){ print("");  print(Test.VEC..NN);   stop("MAIN ERROR ---> test1 --> length(Test.VEC..NN)!=2")  }
	for(CC.gg in Test.VEC..OUT.NN) Test.VEC..NN= Test.VEC..NN[Test.VEC..NN!=CC.gg];  	if(length(Test.VEC..NN)!=0){ print("");  print(Test.VEC..NN);   stop("MAIN ERROR ---> test2 --> length(Test.VEC..NN)!=0")  }
	#########
	Targets.INP..NN[,"Patient_number.RUN.kaOs"]= Targets.INP..NN[,COL.Patient_number.NN]
	#########
	RM.Sampels.IDs..VEC..YES= c();     ##print(RM.Sampels.IDs..VEC..NN);  print(COL.for.RM.Sampels.IDs);  print("")
	if(nrow(Targets.INP..NN)>0) if(length(RM.Sampels.IDs..VEC..NN)>0 & length(COL.for.RM.Sampels.IDs)>0) {
		for(sam.del in RM.Sampels.IDs..VEC..NN) {
			if(nrow(Targets.INP..NN[Targets.INP..NN[,COL.for.RM.Sampels.IDs]==sam.del,])>0) RM.Sampels.IDs..VEC..YES= c(RM.Sampels.IDs..VEC..YES, sam.del)
			Targets.INP..NN= Targets.INP..NN[Targets.INP..NN[,COL.for.RM.Sampels.IDs]!=sam.del,]
	}	}
	if(length(RM.Sampels.IDs..VEC..YES)>0) print(paste(" --> Removing samples for test  -->", paste(RM.Sampels.IDs..VEC..YES, collapse=", ")))
	#########
	if(nrow(Targets.INP..NN)>0){ Targets.INP..NN= Targets.INP..NN[order(Targets.INP..NN[,COL.Patient_number.NN]),]; Targets.INP..NN= Targets.INP..NN[order(Targets.INP..NN[,"Test"], decreasing = FALSE),] }
	#########
	PRINT..COL.FF= c(COL.Patient_number.NN,"Test",COL.Tisssue.libType.NN,COL.Print..Extra.NN)
	#########
	if(nrow(Targets.INP..NN)>0) TEST.test.nn= unique(Targets.INP..NN[,"Test"]) else TEST.test.nn=0
	if(length(TEST.test.nn)<=1) {
		 print(paste("ERROR --> Project.RNA..run or test_run not defined -->",Project.RNA..run.NN, "      test_run=", test_run..NN))
		 if( nrow(Targets.INP..NN)<=0) print(paste(" ERROR -->   nrow( Targets.INP ) =",   nrow(Targets.INP..NN)))
		 if(length(TEST.test.nn  )<=1) print(paste(" ERROR --> unique( test ) ="       , length(TEST.test.nn   )))
		 print("");  print(Targets.INP..NN[,PRINT..COL.FF]);  print(table(Targets.INP..NN[,"Test"]))
		 print("");  stop("kaOs is stopping")
	}
	#########
	Running.Reverce..NN= 0
	if(nrow(Targets.INP..NN)>0){                            Targets.INP..NN= Targets.INP..NN[order(Targets.INP..NN[,"Test"], decreasing=FALSE),]
		if(Targets.INP..NN[1,"Test"]!=Test.VEC..OUT.NN[1]){ Targets.INP..NN= Targets.INP..NN[order(Targets.INP..NN[,"Test"], decreasing=TRUE ),];  Running.Reverce..NN= 1 }
		if(Targets.INP..NN[1,"Test"]!=Test.VEC..OUT.NN[1]) stop("MAIN ERROR  --> Targets.INP..NN[1,Test]!=Test.VEC..OUT.NN[1]")
	}
	#########
	if(print_test.NN){ 
		print(""); print(Targets.INP..NN[,PRINT..COL.FF]); 
		if(Running.Reverce..NN!=0){ print(paste(" NOTE kaOS --> WARNING --> Running Reverse (Reverse order in Test Matrix)--> ",paste(Test.VEC..OUT.NN, collapse=" vs ")));  print("");  stop("KAOS is stooping --> REVERSE does not work --> change name of test") }
		print(table(Targets.INP..NN[,"Test"]));
	}	
}

##############
if(nrow(Targets.INP..NN)>0) RNA.SEQ.Test.VEC..Pipe   <<- Test.VEC..OUT.NN
if(nrow(Targets.INP..NN)>0) COL.Tisssue.libType...FF <<- COL.Tisssue.libType.NN
return(Targets.INP..NN)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################



#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq...Make.Ratio.Meth1..Targets= function(Targets.INP..ff, Sam.Ratio.AFF1..ff, Sam.Ratio.AFF2..ff, Sam.Ratio.UNA1..ff, Sam.Ratio.UNA2..ff, 
                                                 COL.OUTPUTS..ff= c("Sample.Identifier","Patient_number"), TXT.JOIN.Samples..ff="/" ) {

####### Targets.INP..ff=Targets.INP..NN;    Sam.Ratio.AFF1..ff=Samples.G1.tt;   Sam.Ratio.AFF2..ff=Samples.G3.tt;   Sam.Ratio.UNA1..ff=Samples.G4.tt;   Sam.Ratio.UNA2..ff=Samples.G6.tt;   COL.OUTPUTS..ff=COl.Targets.OUT.tt;  TXT.JOIN.Samples..ff="/"

################################################
if(length(COL.OUTPUTS..ff)!=2) stop(paste("MAIN ERROR   -->   length(COL.OUTPUTS..ff)!=2    -->",length(COL.OUTPUTS..ff)))	
########
if(length(Sam.Ratio.AFF1..ff)!=length(Sam.Ratio.AFF2..ff)) stop(paste("MAIN ERROR --> length(samples.1a) != length(samples.1a)  --> Sam.Ratio.1"))	
if(length(Sam.Ratio.UNA1..ff)!=length(Sam.Ratio.UNA2..ff)) stop(paste("MAIN ERROR --> length(samples.2a) != length(samples.2b)  --> Sam.Ratio.2"))
########
if(length(Sam.Ratio.AFF1..ff)<=0) stop(paste("MAIN ERROR --> length(samples.1) <=0  -->",length(Sam.Ratio.AFF1..ff)))
if(length(Sam.Ratio.UNA1..ff)<=0) stop(paste("MAIN ERROR --> length(samples.1) <=0  -->",length(Sam.Ratio.AFF1..ff)))
########
Sam.Ratio.AFF..ff=paste(Sam.Ratio.AFF1..ff,TXT.JOIN.Samples..ff,Sam.Ratio.AFF2..ff,sep="")
Sam.Ratio.UNF..ff=paste(Sam.Ratio.UNA1..ff,TXT.JOIN.Samples..ff,Sam.Ratio.UNA2..ff,sep="")
########	
Targets.INP..ff.AFF= Targets.INP..ff[c(1:length(Sam.Ratio.AFF1..ff)),c(1:3)];    colnames(Targets.INP..ff.AFF)= c(COL.OUTPUTS..ff, "Test")
Targets.INP..ff.UNA= Targets.INP..ff[c(1:length(Sam.Ratio.UNA1..ff)),c(1:3)];    colnames(Targets.INP..ff.UNA)= c(COL.OUTPUTS..ff, "Test")
########
##Targets.INP..ff.AFF[,"Test"]="Aff";		                Targets.INP..ff.AFF[,COL.OUTPUTS..ff[1]]= Sam.Ratio.AFF..ff;		Targets.INP..ff.AFF[,COL.OUTPUTS..ff[2]]= Sam.Ratio.AFF..ff
##Targets.INP..ff.UNA[,"Test"]="UnA";		                Targets.INP..ff.UNA[,COL.OUTPUTS..ff[1]]= Sam.Ratio.UNF..ff;		Targets.INP..ff.UNA[,COL.OUTPUTS..ff[2]]= Sam.Ratio.UNF..ff
########
Targets.INP..ff.AFF[,"Test"]=RNA.SEQ.Test.VEC..Pipe[1];		Targets.INP..ff.AFF[,COL.OUTPUTS..ff[1]]= Sam.Ratio.AFF..ff;		Targets.INP..ff.AFF[,COL.OUTPUTS..ff[2]]= Sam.Ratio.AFF..ff
Targets.INP..ff.UNA[,"Test"]=RNA.SEQ.Test.VEC..Pipe[2];		Targets.INP..ff.UNA[,COL.OUTPUTS..ff[1]]= Sam.Ratio.UNF..ff;		Targets.INP..ff.UNA[,COL.OUTPUTS..ff[2]]= Sam.Ratio.UNF..ff
########
Targets.INP..ff= rbind(Targets.INP..ff.AFF,Targets.INP..ff.UNA);

################################################
MAX.Sam.jj= nrow(Targets.INP..ff)
########
Sam.Ratio..Samples.MAT..NN= as.data.frame(array(NA,c(1,MAX.Sam.jj)),stringsFactors=F);  colnames(Sam.Ratio..Samples.MAT..NN)= paste("SAM.R_",c(1:MAX.Sam.jj),sep="");  rownames(Sam.Ratio..Samples.MAT..NN)= 1
########
Sam.Ratio..Samples.MAT..NN[1,c(1:MAX.Sam.jj)]= Targets.INP..ff[,COL.OUTPUTS..ff[1]] 

################################################
Sam.Ratio..Samples.MAT..FF <<- Sam.Ratio..Samples.MAT..NN
return(Targets.INP..ff)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################


#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
FFF.RNAseq...Make.Ratio.Meth2..Targets= function(Targets.INP..ff, Sam.Ratio.AFF1..ff, Sam.Ratio.AFF2..ff, Sam.Ratio.UNA1..ff, Sam.Ratio.UNA2..ff, 
                                                 COL.OUTPUTS..ff= c("Sample.Identifier","Patient_number"), Gropup.Division.Name..NN=c("/G1","/G4") ) {

####### Targets.INP..ff=Targets.INP..NN;    Sam.Ratio.AFF1..ff=Samples.G1.ff;   Sam.Ratio.AFF2..ff=Samples.G3.ff;   Sam.Ratio.UNA1..ff=Samples.G4.ff;   Sam.Ratio.UNA2..ff=Samples.G6.ff;   COL.OUTPUTS..ff=COl.Targets.OUT.ff;  Gropup.Division.Name..NN=c("/G1","/G4")

################################################
if(length(COL.OUTPUTS..ff         )!=2) stop(paste("MAIN ERROR   -->   length(COL.OUTPUTS..ff     )!=2    -->",length(COL.OUTPUTS..ff         )))	
if(length(Gropup.Division.Name..NN)!=2) stop(paste("MAIN ERROR   -->   length(Gropup.Division.Name)!=2    -->",length(Gropup.Division.Name..NN)))
########
if(length(Sam.Ratio.AFF1..ff)<=0) stop(paste("MAIN ERROR --> length(samples.AFF1) <=0  -->",length(Sam.Ratio.AFF1..ff)))
if(length(Sam.Ratio.UNA1..ff)<=0) stop(paste("MAIN ERROR --> length(samples.UNA1) <=0  -->",length(Sam.Ratio.UNA1..ff)))
if(length(Sam.Ratio.AFF2..ff)<=0) stop(paste("MAIN ERROR --> length(samples.AFF2) <=0  -->",length(Sam.Ratio.AFF2..ff)))
if(length(Sam.Ratio.UNA2..ff)<=0) stop(paste("MAIN ERROR --> length(samples.UNA2) <=0  -->",length(Sam.Ratio.UNA2..ff)))
########
Sam.Ratio.AFF..ff=paste(Sam.Ratio.AFF1..ff,Gropup.Division.Name..NN[1],sep="")
Sam.Ratio.UNF..ff=paste(Sam.Ratio.UNA1..ff,Gropup.Division.Name..NN[2],sep="")
########	
Targets.INP..ff.AFF= Targets.INP..ff[c(1:length(Sam.Ratio.AFF..ff)),c(1:3)];    colnames(Targets.INP..ff.AFF)= c(COL.OUTPUTS..ff, "Test")
Targets.INP..ff.UNA= Targets.INP..ff[c(1:length(Sam.Ratio.UNF..ff)),c(1:3)];    colnames(Targets.INP..ff.UNA)= c(COL.OUTPUTS..ff, "Test")
########
##Targets.INP..ff.AFF[,"Test"]="Aff";		                Targets.INP..ff.AFF[,COL.OUTPUTS..ff[1]]= Sam.Ratio.AFF..ff;		Targets.INP..ff.AFF[,COL.OUTPUTS..ff[2]]= Sam.Ratio.AFF..ff
##Targets.INP..ff.UNA[,"Test"]="UnA";		                Targets.INP..ff.UNA[,COL.OUTPUTS..ff[1]]= Sam.Ratio.UNF..ff;		Targets.INP..ff.UNA[,COL.OUTPUTS..ff[2]]= Sam.Ratio.UNF..ff
########
Targets.INP..ff.AFF[,"Test"]=RNA.SEQ.Test.VEC..Pipe[1];		Targets.INP..ff.AFF[,COL.OUTPUTS..ff[1]]= Sam.Ratio.AFF..ff;		Targets.INP..ff.AFF[,COL.OUTPUTS..ff[2]]= Sam.Ratio.AFF..ff
Targets.INP..ff.UNA[,"Test"]=RNA.SEQ.Test.VEC..Pipe[2];		Targets.INP..ff.UNA[,COL.OUTPUTS..ff[1]]= Sam.Ratio.UNF..ff;		Targets.INP..ff.UNA[,COL.OUTPUTS..ff[2]]= Sam.Ratio.UNF..ff
########
Targets.INP..ff= rbind(Targets.INP..ff.AFF,Targets.INP..ff.UNA);

################################################
MAX.Sam.jj= max(c(length(Sam.Ratio.AFF1..ff), length(Sam.Ratio.AFF2..ff), length(Sam.Ratio.UNA1..ff), length(Sam.Ratio.UNA2..ff), 2))
########
Sam.Ratio..Samples.MAT..NN= as.data.frame(array(NA,c(5,MAX.Sam.jj)),stringsFactors=F);  colnames(Sam.Ratio..Samples.MAT..NN)= paste("SAM.R_",c(1:MAX.Sam.jj),sep="");  
rownames(Sam.Ratio..Samples.MAT..NN)= c(1:MAX.Sam.jj)
########
Sam.Ratio..Samples.MAT..NN[1,c(1:length(Sam.Ratio.AFF1..ff))]= Sam.Ratio.AFF1..ff
Sam.Ratio..Samples.MAT..NN[2,c(1:length(Sam.Ratio.AFF2..ff))]= Sam.Ratio.AFF2..ff
Sam.Ratio..Samples.MAT..NN[3,c(1:length(Sam.Ratio.UNA1..ff))]= Sam.Ratio.UNA1..ff
Sam.Ratio..Samples.MAT..NN[4,c(1:length(Sam.Ratio.UNA2..ff))]= Sam.Ratio.UNA2..ff
Sam.Ratio..Samples.MAT..NN[5,c(1:2)]= Gropup.Division.Name..NN
for(CC.tt in c(1:MAX.Sam.jj)) Sam.Ratio..Samples.MAT..NN[is.na(Sam.Ratio..Samples.MAT..NN[,CC.tt]),CC.tt]="none"

################################################
Sam.Ratio..Samples.MAT..FF <<- Sam.Ratio..Samples.MAT..NN
return(Targets.INP..ff)
}
#########################################################################################################################################################
#########################################################################################################################################################
#########################################################################################################################################################
	
	
	
	
	
	
	
	
	
	
	